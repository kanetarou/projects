#pragma once

#define GAMEOVER_X 457
#define GAMEOVER_Y 81


// �������ߐ錾
bool GameOverInit(void);
void GameOverScene(void);
void GameOverDraw(void);



extern int GameOverCtr;
extern int GameOverImage;
