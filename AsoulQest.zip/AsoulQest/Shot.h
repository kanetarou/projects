#pragma once

#define SHOT_MAX 100	// �e�̍ő吔
#define SHOT_X 24 / 2	// �e�̉��̑傫��
#define SHOT_Y 12		// �e�̏c�̑傫��
#define SHOT_IMAGE_MAX 2// �e�̍ő�`�搔

// �e�̍\����	
struct ENEMY_SHOT
{
	bool flag;
	POS pos;
	POS size;
	POS offsetSize;
	int speed;
	DIR dir;
	int animCnt;
	int life;
	int lifeMax;
};

// �������ߐ錾	
void ShotInit(void);
void ShotControl(void);
void CreateShot(POS playerPos, DIR playerDir);
void shotDraw(void);
void DeletShot(int index);
void shotIndexDraw(int index);
void EnemyShotIndexDraw(int index);
void EnemyCreateShot(POS enemyPos,DIR enemyDir);
void EnemyDeletShot(int index);
void EnemyShotControl(POS playerPos);
bool ShotHitCheck(int index);
bool HomingShotY(POS player, CHARACTER *shot);
bool HomingShotX(POS player, CHARACTER *shot);
bool HomingShotXY(POS player, CHARACTER *shot);

extern int shotImage[2];
extern int eShotImage[2];