#include "DxLib.h"
#include "main.h"
#include "Init.h"
#include "Shot.h"
#include "Stage.h"
#include "Game.h"
#include "Playerh.h"
#include "Enemy.h"
#include "KeyCheck.h"

CHARACTER shot[SHOT_MAX];		// ��ڲ԰�̒e
CHARACTER eShot[SHOT_MAX];		// �G�̒e
int shotImage[SHOT_IMAGE_MAX];	// ��ڲ԰�̒e�̕`��
int eShotImage[SHOT_IMAGE_MAX]; // �G�̒e�̕`��
bool shotFlag;					// �e�̏��
int shotTimer ;					// ��ڲ԰�̒e�̶���
int eShotTimer;					// �G�̒e�̶���

// �e�̏�����
void ShotInit(void)
{
	for (int y = 0; y < SHOT_MAX; y++)
	{
		shot[y].size.x = SHOT_X;
		shot[y].size.y = SHOT_Y;
		shot[y].offsetSize.x = shot[y].size.x / 2;
		shot[y].offsetSize.y = shot[y].size.y / 2;
		shot[y].pos.x = PL_POS_X;
		shot[y].pos.y = PL_POS_Y;
		shot[y].animCnt = 0;
		shot[y].moveSpeed = 8;
		shot[y].life = 0;
		shot[y].lifeMax = 100;
		shot[y].moveDir = DIR_DOWN;

		// �G�̒e�̏�����
		eShot[y].size.x = SHOT_X;
		eShot[y].size.y = SHOT_Y;
		eShot[y].offsetSize.x = eShot[y].size.x / 2;
		eShot[y].offsetSize.y = eShot[y].size.y / 2;
		eShot[y].pos.x = 0;
		eShot[y].pos.y = 0;
		eShot[y].animCnt = 0;
		eShot[y].moveSpeed = 3;
		
		eShot[y].lifeMax = 100;
		eShot[y].life = eShot[y].lifeMax;
		eShot[y].moveDir = DIR_DOWN;

	}
	shotTimer = 0;
	eShotTimer = 0;
	shotFlag = false;
}

// ���@�̒e
void ShotControl(void)
{
	for (int s = 0; s < SHOT_MAX; s++)
	{
		// �����Ă���e��T��
		if (shot[s].life > 0)
		{
			switch (shot[s].moveDir)
			{
			case DIR_UP:
				shot[s].pos.y -= shot[s].moveSpeed;
				shot[s].life--;
				break;
			case DIR_DOWN:
				shot[s].pos.y += shot[s].moveSpeed;
				shot[s].life--;
				break;
			case DIR_RIGHT:
				shot[s].pos.x += shot[s].moveSpeed;
				shot[s].life--;
				break;
			case DIR_LEFT:
				shot[s].pos.x -= shot[s].moveSpeed;
				shot[s].life--;
				break;
			default:
				break;
			}
			shot[s].animCnt++;

			EnemyHitCheck(shot[s].pos, shot[s].size, shot[s].life, s);
			AddCharOrder(CHARA_TYPE_SHOT, s, shot[s].pos.y);
		}
	}
	
}


// �e�𐶐�
void CreateShot(POS playerPos, DIR playerDir)
{
	for (int s = 0; s < SHOT_MAX; s++)
	{
		if (shot[s].life <= 0 && shotTimer == 0 )
		{
			shot[s].pos = playerPos;
			shot[s].moveDir = playerDir;
			shot[s].life = shot[s].lifeMax;
			shotTimer = 1;
			break;
		}
	}
	if (shotTimer != 0)
	{
		shotTimer++;
		if (shotTimer >= 8)
		{
			shotTimer = 0;
			//DeletShot();
		}
	}
}


// �e���폜
void DeletShot(int index)
{
	shot[index].life = 0;
}

// �e��`��
void shotDraw(void)
{
	
	for (int s = 0; s < SHOT_MAX; s++)
	{
		int animCnt = ((shot[s].animCnt / 10) % 2);
		if (shot[s].life > 0)
		{
			DrawGraph(shot[s].pos.x + mapPos.x, shot[s].pos.y + mapPos.y, shotImage[animCnt], true);
		}
	}
}
// �e��`��
void shotIndexDraw(int index)
{

	for (int s = 0; s < SHOT_MAX; s++)
	{
		int animCnt = ((shot[index].animCnt / 10) % 2);
		if (shot[index].life > 0)
		{
			DrawGraph(shot[index].pos.x - shot[index].offsetSize.x + mapPos.x, shot[index].pos.y - shot[index].offsetSize.y + mapPos.y, shotImage[animCnt], true);
		}
	}
}
// ----------------------------------------------------�G�̒e------------------------------------------------------------------------------


// �G�̒e�̺��۰�
void EnemyShotControl(POS playerPos)
{
	for (int s = 0; s < SHOT_MAX; s++)
	{
		// �����Ă���e��T��
		if (eShot[s].life > 0)
		{
			switch (eShot[s].moveDir)
			{
			case DIR_UP:
				eShot[s].pos.y -= eShot[s].moveSpeed;
				eShot[s].life--;
				break;
			case DIR_DOWN:
				eShot[s].pos.y += eShot[s].moveSpeed;
				eShot[s].life--;
				break;
			case DIR_RIGHT:
				eShot[s].pos.x += eShot[s].moveSpeed;
				eShot[s].life--;
				break;
			case DIR_LEFT:
				eShot[s].pos.x -= eShot[s].moveSpeed;
				eShot[s].life--;
				break;
			default:
				break;
			}

			eShot[s].animCnt++;

			HomingShotXY(playerPos, &eShot[s]);

		EnemyShotHitCheck(eShot[s].pos, eShot[s].offsetSize, eShot[s].life, s);

		AddCharOrder(CHARA_TYPE_ESHOT, s, eShot[s].pos.y);
	}
	}
}

// �c��
bool HomingShotY(POS player, CHARACTER *shot)
{
	for (int y = 0; y < SHOT_MAX; y++)
	{
		int diffY = player.y - (*shot).pos.y;
		(*shot).moveSpeed = 2;

		if (diffY >= 0)
		{
			(*shot).moveSpeed = diffY < (*shot).moveSpeed ? diffY : (*shot).moveSpeed;
			(*shot).pos.y += (*shot).moveSpeed;
			(*shot).moveDir = DIR_DOWN;
		}
		else
		{
			(*shot).moveSpeed = diffY > -(*shot).moveSpeed ? -diffY : (*shot).moveSpeed;
			(*shot).pos.y -= (*shot).moveSpeed;
			(*shot).moveDir = DIR_UP;
		}


		return (*shot).moveSpeed;
	}
}
// ����
bool HomingShotX(POS player, CHARACTER *shot)
{
	for (int y = 0; y < SHOT_MAX; y++)
	{
		// ����
		int diffX = player.x - (*shot).pos.x;
		(*shot).moveSpeed = 2;
		if (diffX >= 0)
		{
			(*shot).moveSpeed = diffX < (*shot).moveSpeed ? diffX : (*shot).moveSpeed;
			(*shot).pos.x += (*shot).moveSpeed;
			(*shot).moveDir = DIR_RIGHT;

		}
		else
		{
			(*shot).moveSpeed = diffX > -(*shot).moveSpeed ? -diffX : (*shot).moveSpeed;
			(*shot).pos.x -= (*shot).moveSpeed;
			(*shot).moveDir = DIR_LEFT;
		}
		return (*shot).moveSpeed;
	}
}
// �΂�
bool HomingShotXY(POS player,CHARACTER *shot)
{
	for (int y = 0; y < SHOT_MAX; y++)
	{
		int diffX = player.x - (*shot).pos.x;
		int diffY = player.y - (*shot).pos.y;
		(*shot).moveSpeed = 2;

		if (abs(diffX) <= abs(diffY))
		{
			(*shot).moveSpeed = HomingShotY(player,shot);
		}
		else
		{
			(*shot).moveSpeed = HomingShotX(player,shot);
		}

		return (*shot).moveSpeed;
	}
}
// �G�̒e�𐶐�
void EnemyCreateShot(POS enemyPos, DIR enemyDir)
{
	for (int s = 0; s < SHOT_MAX; s++)
	{

		if (eShot[s].life <= 0 && eShotTimer == 0)
		{
			eShot[s].pos = enemyPos;
			eShot[s].moveDir = enemyDir;
			eShot[s].life = eShot[s].lifeMax;
			eShotTimer = 1;
			break;
		}


	}
	// �G�̒e�̏o����ύX
	if (eShotTimer != 0)
	{
		eShotTimer++;
		if (eShotTimer >= 30)
		{
			eShotTimer = 0;
		}
	}
	// �޽�̒e�̏o����ύX
	if (stageID == STAGE_ID_3)
	{
		if (eShotTimer != 0)
		{
			eShotTimer++;
			if (eShotTimer >=12)
			{
				eShotTimer = 0;
			}
		}
	}
}


// �G�̒e���폜
void EnemyDeletShot(int index)
{
	eShot[index].life = 0;
}

// �e��`��
void EnemyShotIndexDraw(int index)
{
	int animCnt = ((eShot[index].animCnt / 10) % 2);
	if (eShot[index].life > 0)
	{
		DrawGraph(eShot[index].pos.x - eShot[index].offsetSize.x + mapPos.x, eShot[index].pos.y - eShot[index].offsetSize.y + mapPos.y, eShotImage[animCnt], true);
	}
}

// �G�̒e�Ǝ��@�̒e�Ƃ̔���
bool ShotHitCheck(int index)
{
	bool rtnFlag = false;

	for (int x = 0; x < SHOT_MAX; x++)
	{
		/*enemy[x].life = enemyMaster[ENEMY_TYPE_MAX].lifeMax;*/
		if (eShot[x].life > 0 && shot[x].life > 0)
		{
			if ((shot[x].pos.x + shot[x].size.x / 2 > eShot[x].pos.x - eShot[x].size.x / 2) &&
				(shot[x].pos.x - shot[x].size.x / 2 <= eShot[x].pos.x + eShot[x].size.x / 2) &&
				(shot[x].pos.y + shot[x].size.y / 2 > eShot[x].pos.y - eShot[x].size.y / 2) &&
				(shot[x].pos.y - shot[x].size.y / 2 <= eShot[x].pos.y + eShot[x].size.y / 2))
			{

				EnemyDeletShot(x);
				DeletShot(index);
				rtnFlag = true;
				
			}
		}
	}
	return rtnFlag;
}