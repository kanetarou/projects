#pragma once

#define FADE_SPEED 5			// ̪��ނ̽�߰��

extern int bright;
extern bool PFlag;
extern bool fadeInFlag;
extern bool fadeOutFlag;

void Pause(void);
void FadeIn(void);
void FadeOut(void);
void EffectInit(void);
void FadeInit(void);