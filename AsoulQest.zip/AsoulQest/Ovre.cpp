#include "DxLib.h"
#include "main.h"
#include "Title.h"
#include "Game.h"
#include "Ovre.h"
#include "KeyCheck.h"
#include "Effect.h"


int GameOverCtr;
int GameOverImage;
// �ްѵ��ް��ʂ̏�����
bool GameOverInit(void)
{
	bool rtnFlag = true;

	GameOverCtr = 0;
	bright = 0;

	scnID = SCN_ID_GAMEOVER;
	return  rtnFlag;
}

// �ްѵ��ް��ʏ���
void GameOverScene(void)
{
	FadeIn();
	GameOverCtr++;

	GameOverDraw();
	// ̪��ޱ��
	if (keyDownTrigger[KEY_ID_SPACE])
	{
		TitleInit();
	}
}

// �ްѵ��ް��݂̕`��
void GameOverDraw(void)
{
	ClsDrawScreen();
	DrawFormatString(0, 0, GetColor(255, 0, 0), "GameOvreCounter = %d", GameOverCtr);
	
	DrawGraph((SCREEN_SIZE_X - GAMEOVER_X) / 2, (SCREEN_SIZE_Y - GAMEOVER_Y) / 2, GameOverImage, true);
	SetDrawBright(bright, bright, bright);
	ScreenFlip();
}