#include "DxLib.h"
#include "main.h"
#include "Game.h"
#include "Init.h"
#include "Title.h"
#include "Over.h"
#include "Stage.h"
#include "KeyCheck.h"
#include "Playerh.h"
#include "Enemy.h"
#include "Shot.h"
#include "Effect.h"

int playerImage[PL_MAX];		// ��ڲ԰�̉摜
int plCnt;						// ��ڲ԰�̶���

CHARACTER player;				// ��ڲ԰
POS indexPos;					// ϯ�ߔz��̍��W
bool animFlag;					// ��Ұ��ݗp���׸�
bool tenmetsuFlag;				// ��ڲ԰�̓_�ŏ��
bool hitFlag;					// �����蔻����׸�
int bombImage[3];				// ��ڲ԰�̔����׸�
bool invisibleFlag;				// ��ڲ԰�̖��G�׸�
int invisibleCount;				// ���G���ԗp�̶���

// ��ڲ԰�̏�����
void PlayerInit(void)
{
	POS playerOffsetPos;
	//player.charType = ;
	player.moveDir = DIR_DOWN;
	player.size.x = PL_SIZE_X;
	player.size.y = PL_SIZE_Y;

	player.offsetSize.x = player.size.x / 2;
	player.offsetSize.y = player.size.y / 2;

	player.pos.x = PL_POS_X;
	player.pos.y = PL_POS_Y;

	player.moveSpeed = PLAYER_SPEED_NOMAL;

	player.lifeMax = PL_LIFE_MAX;
	player.life = player.lifeMax;

	player.animCnt = 0;
	plCnt = 0;
	playerOffsetPos.x = -480;
	playerOffsetPos.y = -680;

	StageInit(playerOffsetPos);
	animFlag = false;
	hitFlag = false;
	tenmetsuFlag = false;
	invisibleFlag = false;
}


// ��ڲ԰�̺��۰�
POS PlayerControl(void)
{

	POS playerPosCopy = player.pos;
	POS playerHitCheck = playerPosCopy;
	POS returnValue = player.pos;					// �֐��̖߂�l�i�[�̈�
	player.animCnt++;

	// ��ڲ԰�̈ړ�
	if (CheckHitKey(KEY_INPUT_UP))
	{
		animFlag = true;
		player.moveDir = DIR_UP;
		
	}
	if (CheckHitKey(KEY_INPUT_DOWN))
	{
		animFlag = true;
		player.moveDir = DIR_DOWN;
	}
	if (CheckHitKey(KEY_INPUT_RIGHT))
	{
		animFlag = true;
		player.moveDir = DIR_RIGHT;
	}
	if (CheckHitKey(KEY_INPUT_LEFT))
	{
		animFlag = true;
		player.moveDir = DIR_LEFT;
	}

	
	
	//POS playerPosOffset = playerPosBack;

	// ��ڲ԰�̈ړ�����
	if (animFlag == true)
	{
		switch (player.moveDir)
		{
		case DIR_UP:
			playerPosCopy.y -= player.moveSpeed;
			playerHitCheck.y = playerPosCopy.y - player.offsetSize.y;
			if (IsPass(playerHitCheck))
			{
				player.pos = playerPosCopy;
				
				if (0 < -mapPos.y && MAP_SCR > player.pos.y + mapPos.y)
				{
					mapPos.y += player.moveSpeed;
				}
				
			}
			break;
		case DIR_DOWN:
			playerPosCopy.y += player.moveSpeed;
			playerHitCheck.y = playerPosCopy.y + player.offsetSize.y;
			if (IsPass(playerHitCheck))
			{
				player.pos = playerPosCopy;
				if (stageID == STAGE_ID_START)
				{
					if ((MAP_Y * CHIP_SIZE_Y) - SCREEN_SIZE_Y > -mapPos.y &&
						SCREEN_SIZE_Y - MAP_SCR < player.pos.y + mapPos.y)
					{
						mapPos.y -= player.moveSpeed;
					}
				}
				else if (stageID == STAGE_ID_2)
				{
					if ((MAP_2_Y * CHIP_SIZE_Y) - SCREEN_SIZE_Y >= -mapPos.y &&
						SCREEN_SIZE_Y - MAP_SCR <= player.pos.y + mapPos.y)
					{
						mapPos.y -= player.moveSpeed;
					}
				}
				else if (stageID == STAGE_ID_3)
				{
					if ((27 * CHIP_SIZE_Y) - SCREEN_SIZE_Y >= -mapPos.y &&
						SCREEN_SIZE_Y - MAP_SCR <= player.pos.y + mapPos.y)
					{
						mapPos.y -= player.moveSpeed;
					}
				}
				
			}
			break;
		case DIR_RIGHT:
			playerPosCopy.x += player.moveSpeed;
			playerHitCheck.x = playerPosCopy.x + player.offsetSize.x;
			if (IsPass(playerHitCheck))
			{
				player.pos = playerPosCopy;
				if (stageID == STAGE_ID_START)
				{
					if ((MAP_X * CHIP_SIZE_X) - SCREEN_SIZE_X > -mapPos.x  &&
						SCREEN_SIZE_X - MAP_SCR < player.pos.x + mapPos.x)
					{
						mapPos.x -= player.moveSpeed;
					}
				}
				else if (stageID == STAGE_ID_2)
				{
					if ((MAP_2_X * CHIP_SIZE_X) - SCREEN_SIZE_X >= -mapPos.x  &&
						SCREEN_SIZE_X - MAP_SCR <= player.pos.x + mapPos.x)
					{
						mapPos.x -= player.moveSpeed;
					}
				}
				else if (stageID == STAGE_ID_3)
				{
					if ((27 * CHIP_SIZE_X) - SCREEN_SIZE_X >= -mapPos.x  &&
						SCREEN_SIZE_X - MAP_SCR <= player.pos.x + mapPos.x)
					{
						mapPos.x -= player.moveSpeed;
					}
				}
			}
			break;
		case DIR_LEFT:
			playerPosCopy.x -= player.moveSpeed;
			playerHitCheck.x = playerPosCopy.x - player.offsetSize.x;
			if (IsPass(playerHitCheck))
			{
				player.pos = playerPosCopy;
				
				if (0 < -mapPos.x && MAP_SCR > player.pos.x + mapPos.x)
				{
					mapPos.x += player.moveSpeed;
				}
			}
			break;
		default:
			break;
		}
		player.animCnt++;
		animFlag = false;
	}
	// �ð��3�œG�����񂾂珉����
	Delete2(player.life);
	
	// L���۰ق������Ēe�𐶐�
	if ((keyNew[KEY_ID_SHOT]))
	{
		CreateShot(player.pos, player.moveDir);
	}

	// ���̏���������ڲ԰�̽�߰���޳�
	if (GetEvent(player.pos) == EVENT_ID_NUMA)
	{
		player.moveSpeed = PLAYER_SPEED_LOW;
	}
	else
	{
		player.moveSpeed = PLAYER_SPEED_NOMAL;
	}
	// Z����������ڲ԰�̽�߰�ޱ���
	if (keyNew[KEY_ID_SPEEDUP])
	{
		player.moveSpeed = PLAYER_SPEED_HIGH;
	}
	// ��ڲ԰��ײ̂�0�ɂȂ�����ްѵ��ް��݂Ɉڍs
	if (player.life == 0 && !fadeOutFlag)
	{
		fadeOutFlag = false;
		fadeInFlag = true;
	}
	if (bright <= 0 && fadeInFlag)
	{
		fadeInFlag = false;
		GameOverInit();
	}
	Invisible();
	AddCharOrder(CHARA_TYPE_PLAYER, 0, player.pos.y);
	return returnValue;
}


// �G����ڲ԰�̓����蔻��
bool PlayerHitCheck(POS ePos, POS eSize, int eLife)
{
	bool rtnFlag = false;
	
	int tmp = (ePos.x - player.pos.x) * (ePos.x - player.pos.x) + (ePos.y - player.pos.y) * (ePos.y - player.pos.y);
	
	if (player.life > 0 && eLife != 0 && invisibleFlag == false)
	{
		if (tmp <= (player.size.x / 2) * (eSize.x / 2) + (player.size.y / 2) * (eSize.y / 2) )
		{
			player.life--;
			invisibleFlag = true;
			rtnFlag = true;
		}
	}
	return rtnFlag;
}

// �G�̒e�Ǝ��@�̓����蔻��
bool EnemyShotHitCheck(POS eShotPos, POS eShotSize, int eShotLife,int index)
{
	bool rtnFlag = false;
	//int tmp;

	for (int x = 0; x < GET_ENEMY; x++)
	{
		/*for (int y = 0; y < SHOT_MAX; y++)
		{*/
			/*enemy[x].life = enemyMaster[ENEMY_TYPE_MAX].lifeMax;*/
			if (eShotLife > 0 && player.life > 0)
			{
				//tmp = (eShotPos.x - player.pos.x) * (eShotPos.x - player.pos.x) + (eShotPos.y - player.pos.y) * (eShotPos.y - player.pos.y);

				/*if (tmp <= (enemyMaster[enemy[x].charType].size.x / 2) * (sSize.x / 2) + (enemyMaster[enemy[x].charType].size.y / 2) * (sSize.y / 2))
				{*/
				if ((player.pos.x + player.size.x / 2 > eShotPos.x - eShotSize.x) &&
					(player.pos.x - player.size.x / 2 <= eShotPos.x + eShotSize.x) &&
					(player.pos.y + player.size.y / 2 > eShotPos.y - eShotSize.y) &&
					(player.pos.y - player.size.y / 2 <= eShotPos.y + eShotSize.y))
				{
					EnemyDeletShot(index);
					if (invisibleFlag == false)
					{
						player.life--;
						rtnFlag = true;
						invisibleFlag = true;
					}
				}
			}
		//}
	}
	return rtnFlag;
}

// ��ڲ԰�̕\��
bool PlayerDraw(void)
{
	bool rtnFlag = false;
		int tmpAnimID = player.moveDir * PL_X + ((player.animCnt / 10) % PL_X);
		int tmpAnimBomb = ((player.animCnt / 30) % 3);
		// ��ڲ԰�̕\��
		if (player.life > 0 && (invisibleCount/15)%2 == 0 )
		{
			DrawGraph(player.pos.x - player.offsetSize.x + mapPos.x, player.pos.y - player.offsetSize.y + mapPos.y,
					  playerImage[tmpAnimID], true);
		}
		
		if (player.life <= 0)
			{
				DrawGraph(player.pos.x - player.offsetSize.x + mapPos.x, player.pos.y - player.offsetSize.y + mapPos.y,
						  bombImage[tmpAnimBomb], true);
			}
	
	POS indexPos;
	indexPos = PosToIndex(player.pos);
	DrawFormatString(30, 30, GetColor(255, 255, 255), "playerPos = ( %d , %d )",player.pos.x, player.pos.y);
	DrawFormatString(30, 45, GetColor(255, 255, 255), "mapPos	 = ( %d , %d )",mapPos.x ,mapPos.y);
	DrawFormatString(30, 60, GetColor(255, 255, 255), "MAP = ( %d , %d )", indexPos.x,indexPos.y);
	DrawFormatString(300, 0, GetColor(255,0,0), "PL_LIFE = %d", player.life);
	DrawBox(player.pos.x - player.offsetSize.x + mapPos.x,
			player.pos.y - player.offsetSize.y + mapPos.y,
			player.pos.x + player.offsetSize.x + mapPos.x,
			player.pos.y + player.offsetSize.y + mapPos.y, GetColor(255, 255, 0), false);

	/*DrawBox(player.pos.x - 40 + mapPos.x,
		player.pos.y - 30 + mapPos.y,
		player.pos.x - 40 + mapPos.x,
		player.pos.y - 30  + mapPos.y,
		GetColor(0, 255, 255), false);*/


	DrawBox(player.pos.x - 22 + mapPos.x,
		player.pos.y - 30 + mapPos.y,
		player.pos.x - 22 +15 *  player.life + mapPos.x,
		player.pos.y - 10 - 30 + mapPos.y,
		GetColor(0, 255 ,255), true);

	DrawBox(player.pos.x - 22 + mapPos.x,
		player.pos.y - 30 + mapPos.y,
		player.pos.x - 22 + 15 * player.lifeMax + mapPos.x,
		player.pos.y - 10 - 30 + mapPos.y,
		GetColor(255, 255, 255), false);

	return rtnFlag;
}

void Invisible(void)//���G���
{
	if (invisibleFlag == true)
	{
		invisibleCount++;
		if (invisibleCount > 120)
		{
			invisibleFlag = false;
			invisibleCount = 0;
		}
	}
}


