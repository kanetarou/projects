#pragma once


// file�̍\����
struct FILE_DATA
{
	int data1;
	int hiScore;
};

// ��׸�����߂̍\����
enum CHARA_TYPE
{
	CHARA_TYPE_PLAYER,
	CHARA_TYPE_ENEMY,
	CHARA_TYPE_ENEMY2,
	CHARA_TYPE_SHOT,
	CHARA_TYPE_ESHOT,
	CHARA_TYPE_BOSS_SHOT,
	CHARA_TYPE_MAX,
};

// ��ׂ̕\���Ǘ��p
struct DRAW_ORDER
{
	CHARA_TYPE charaType;
	int index;
	int y;
};

#define FONT_MAX 26	// �p���̍ő吔
#define NUMBER_MAX 11 // �����̍ő吔


#define S 19		//���
#define C 3
#define O 15
#define R 18
#define E 5

#define H 8
#define I 9

// �������ߐ錾
bool GameInit(void);
bool GameScene(void);
void GameDraw(void);
void DrawScr(void);
void AddScr(int a);
void DrawScore(void);
bool SaveData(void);
bool LaodData(void);
void OrderInit(void);
void AddCharOrder(CHARA_TYPE charaType, int index, int y);
void NumberDraw(int baseX, int baseY);


void Draw( int score);

extern int bright;
extern int mapImage;
extern int fontImage[FONT_MAX];
extern int nmbImage[NUMBER_MAX];
extern FILE_DATA fileData;
extern int gameCtr;