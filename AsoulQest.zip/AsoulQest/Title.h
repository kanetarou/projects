#pragma once

// �������ߐ錾
bool TitleInit(void);
void TitleScene(void);
void TitleDraw(void);


extern int tImag;
extern int titleCtr;
extern int titleImage;
extern int HsKeyImage;