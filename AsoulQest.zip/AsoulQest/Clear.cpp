#include "DxLib.h"
#include "main.h"
#include "Game.h"
#include "Title.h"
#include "Over.h"
#include "Stage.h"
#include "KeyCheck.h"
#include "Playerh.h"
#include "Shot.h"
#include "Enemy.h"
#include "Effect.h"
#include "Clear.h"

int clearImage;
int clearCnt;
// �ر�̏�����
void ClearInit(void)
{
	clearCnt = 0;
	bright = 0;
	scnID = SCN_ID_CLEAR;
}
// �ر���
void ClearScene(void)
{
	FadeIn();
	clearCnt++;
	ClearDraw();
	// ̪��ޱ��
	if (keyDownTrigger[KEY_ID_SPACE] == 1 && !fadeOutFlag)
	{
		//fadeOutFlag = false;
		fadeInFlag = true;
	}
	// ��ײĂ�0�ɂȂ�����ްѼ�݂Ɉڍs
	if (bright <= 0 && fadeInFlag)
	{
		fadeInFlag = false;
		TitleInit();
	}
	
}
// �ر��ʂ̕`��
void ClearDraw(void)
{
	ClsDrawScreen();

	DrawGraph(0, 0, clearImage, true);
	DrawFormatString(0, 0, GetColor(255, 255, 255), "ClearCounter = %d", clearCnt);
	DrawString(SCREEN_SIZE_X / 2-200, SCREEN_SIZE_Y / 2 - 300, "�N���A���߂łƂ��I",GetColor(255,255,255));
	DrawFormatString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2 + 100, GetColor(255, 255, 255), "�ō��L�^ = %d", fileData.hiScore);
	SetDrawBright(bright, bright, bright);
	ScreenFlip();
}