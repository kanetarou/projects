#include <time.h>
#include "DxLib.h"
#include "main.h"
#include "Init.h"
#include "Game.h"
#include "Stage.h"
#include "Title.h"
#include "Over.h"
#include "Effect.h"
#include "KeyCheck.h"
#include "Enemy.h"
#include "Shot.h"
#include "Playerh.h"
#include "Clear.h"

CHARACTER enemyMaster[ENEMY_TYPE_MAX];			// �G�̑S�̊Ǘ��p�ϐ�
CHARACTER enemy[GET_ENEMY];						// �G�̍ő吔
int enemyImage[ENEMY_TYPE_MAX][ENEMY_MAX];		// �G�̉摜
//POS enemyPosCopy;
//POS enemyHitCheck;
int enemyCnt;
int eCnt;
int eShotCnt;
// �G�̏�����
void EnemyInit(void)
{
	/*for (int y = 0; y < GET_ENEMY; y++)
	{
		enemyPosCopy = enemy[y].pos;
		enemyHitCheck = enemyPosCopy;
	}*/
	// �ײт̏����� 
	//enemyMaster[ENEMY_TYPE_SLIME].charType = ENEMY_TYPE_SLIME;
	//enemyMaster[ENEMY_TYPE_SLIME].pos.x = 100;
	//enemyMaster[ENEMY_TYPE_SLIME].pos.y = 150;
	//enemyMaster[ENEMY_TYPE_SLIME].moveSpeed = 2;
	//enemyMaster[ENEMY_TYPE_SLIME].size.x = ENEMY_SIZE_X;
	//enemyMaster[ENEMY_TYPE_SLIME].size.y = ENEMY_SIZE_Y;
	//enemyMaster[ENEMY_TYPE_SLIME].offsetSize.x = enemyMaster[ENEMY_TYPE_SLIME].size.x/2;
	//enemyMaster[ENEMY_TYPE_SLIME].offsetSize.y = enemyMaster[ENEMY_TYPE_SLIME].size.y/2;
	//enemyMaster[ENEMY_TYPE_SLIME].lifeMax = 3;
	//enemyMaster[ENEMY_TYPE_SLIME].life = enemyMaster[ENEMY_TYPE_SLIME].lifeMax;
	//
	//enemyMaster[ENEMY_TYPE_SLIME].point = 20;

	//// �I�̏�����
	//enemyMaster[ENEMY_TYPE_BEE].charType = ENEMY_TYPE_BEE;
	//enemyMaster[ENEMY_TYPE_BEE].pos.x = 100;
	//enemyMaster[ENEMY_TYPE_BEE].pos.y = 150;
	//enemyMaster[ENEMY_TYPE_BEE].moveSpeed = 2;
	//enemyMaster[ENEMY_TYPE_BEE].size.x = ENEMY_SIZE_X;
	//enemyMaster[ENEMY_TYPE_BEE].size.y = ENEMY_SIZE_Y;
	//enemyMaster[ENEMY_TYPE_BEE].offsetSize.x = enemyMaster[ENEMY_TYPE_BEE].size.x/2;
	//enemyMaster[ENEMY_TYPE_BEE].offsetSize.y = enemyMaster[ENEMY_TYPE_BEE].size.y/2;
	//enemyMaster[ENEMY_TYPE_BEE].life = 3;
	//enemyMaster[ENEMY_TYPE_BEE].lifeMax = 3;
	//enemyMaster[ENEMY_TYPE_BEE].point = 20;

	//// ���̏�����
	//enemyMaster[ENEMY_TYPE_FLAME].charType = ENEMY_TYPE_FLAME;
	//enemyMaster[ENEMY_TYPE_FLAME].pos.x = 100;
	//enemyMaster[ENEMY_TYPE_FLAME].pos.y = 150;
	//enemyMaster[ENEMY_TYPE_FLAME].moveSpeed = 2;
	//enemyMaster[ENEMY_TYPE_FLAME].size.x = ENEMY_SIZE_X;
	//enemyMaster[ENEMY_TYPE_FLAME].size.y = ENEMY_SIZE_Y;
	//enemyMaster[ENEMY_TYPE_FLAME].offsetSize.x = enemyMaster[ENEMY_TYPE_FLAME].size.x/2;
	//enemyMaster[ENEMY_TYPE_FLAME].offsetSize.y = enemyMaster[ENEMY_TYPE_FLAME].size.y/2;
	//enemyMaster[ENEMY_TYPE_FLAME].life = 3;
	//enemyMaster[ENEMY_TYPE_FLAME].lifeMax = 3;
	//enemyMaster[ENEMY_TYPE_FLAME].point = 20;

	//// ����׺�݂̏�����
	//enemyMaster[ENEMY_TYPE_R_DRAGON].charType = ENEMY_TYPE_R_DRAGON;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].pos.x = 100;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].pos.y = 150;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].moveSpeed = 2;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].size.x = ENEMY_SIZE_X;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].size.y = ENEMY_SIZE_Y;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].offsetSize.x = enemyMaster[ENEMY_TYPE_R_DRAGON].size.x/2;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].offsetSize.y = enemyMaster[ENEMY_TYPE_R_DRAGON].size.y/2;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].life = 3;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].lifeMax = 3;
	//enemyMaster[ENEMY_TYPE_R_DRAGON].point = 20;
	
	// �G���G�̏�����
	for (int y = 0; y < ENEMY_TYPE_MAX; y++)
	{
		enemyMaster[y].charType = y;
		enemyMaster[y].pos.x = 100;
		enemyMaster[y].pos.y = 150;
		enemyMaster[y].moveSpeed = 0;
		enemyMaster[y].size.x = ENEMY_SIZE_X;
		enemyMaster[y].size.y = ENEMY_SIZE_Y;
		enemyMaster[y].offsetSize.x = enemyMaster[y].size.x / 2;
		enemyMaster[y].offsetSize.y = enemyMaster[y].size.y / 2;
		enemyMaster[y].lifeMax = 3;
		enemyMaster[y].life = enemyMaster[y].lifeMax;
		enemyMaster[y].point = 20;
	}
	enemyMaster[ENEMY_TYPE_R_DRAGON].pos.x = GetRand(CHIP_SIZE_X * MAP_X - 1);
	enemyMaster[ENEMY_TYPE_R_DRAGON].pos.y = GetRand(CHIP_SIZE_Y * MAP_Y - 1);


	// ����׺�݂̏�����
	enemyMaster[ENEMY_TYPE_M_DORAGON].charType = ENEMY_TYPE_M_DORAGON;
	enemyMaster[ENEMY_TYPE_M_DORAGON].pos.x = 100;
	enemyMaster[ENEMY_TYPE_M_DORAGON].pos.y = 150;
	enemyMaster[ENEMY_TYPE_M_DORAGON].moveSpeed = 2;
	enemyMaster[ENEMY_TYPE_M_DORAGON].size.x = DORAGON_X;
	enemyMaster[ENEMY_TYPE_M_DORAGON].size.y = DORAGON_Y;
	enemyMaster[ENEMY_TYPE_M_DORAGON].offsetSize.x = enemyMaster[ENEMY_TYPE_M_DORAGON].size.x / 2;
	enemyMaster[ENEMY_TYPE_M_DORAGON].offsetSize.y = enemyMaster[ENEMY_TYPE_M_DORAGON].size.y / 2;
	enemyMaster[ENEMY_TYPE_M_DORAGON].lifeMax = 5;
	enemyMaster[ENEMY_TYPE_M_DORAGON].life = enemyMaster[ENEMY_TYPE_M_DORAGON].lifeMax;
	enemyMaster[ENEMY_TYPE_M_DORAGON].point = 50;

	// �޽�̏�����
	enemyMaster[ENEMY_TYPE_BOSS].charType = ENEMY_TYPE_BOSS;
	enemyMaster[ENEMY_TYPE_BOSS].pos.x = 420;
	enemyMaster[ENEMY_TYPE_BOSS].pos.y = 450;
	enemyMaster[ENEMY_TYPE_BOSS].moveSpeed = 0;
	enemyMaster[ENEMY_TYPE_BOSS].size.x = BOSS_X;
	enemyMaster[ENEMY_TYPE_BOSS].size.y = BOSS_Y;
	enemyMaster[ENEMY_TYPE_BOSS].offsetSize.x = enemyMaster[ENEMY_TYPE_BOSS].size.x / 2;
	enemyMaster[ENEMY_TYPE_BOSS].offsetSize.y = enemyMaster[ENEMY_TYPE_BOSS].size.y / 2;
	enemyMaster[ENEMY_TYPE_BOSS].lifeMax = 50;
	enemyMaster[ENEMY_TYPE_BOSS].life = enemyMaster[ENEMY_TYPE_BOSS].lifeMax;
	enemyMaster[ENEMY_TYPE_BOSS].point = 300;

	// �G�̐��ƈʒu������тɐ���
	for (int s = 0; s < GET_ENEMY; s++)
	{
		enemy[s] = enemyMaster[GetRand(ENEMY_TYPE_MAX - 3)];
		enemy[s].pos.x = GetRand(CHIP_SIZE_X * MAP_X - 1);
		enemy[s].pos.y = GetRand(CHIP_SIZE_Y * MAP_Y - 1);
	}
	enemy[enemyMaster[ENEMY_TYPE_M_DORAGON].charType] = enemyMaster[ENEMY_TYPE_M_DORAGON];

	enemyCnt = 0;
	eCnt = 0;
	eShotCnt = 0;
}
// �޽�̏�����
void BossInit(void)
{
	enemy[0] = enemyMaster[ENEMY_TYPE_BOSS];
	enemy[0].charType = ENEMY_TYPE_BOSS;

	enemy[0].lifeMax = 25;
	enemy[0].life = enemy[0].lifeMax;
	enemy[0].size.x = BOSS_X;
	enemy[0].size.y = BOSS_Y;
	enemy[0].offsetSize.x = enemy[0].size.x / 2;
	enemy[0].offsetSize.y = enemy[0].size.y / 2;
}
// �G�̈ړ�
void EnemyControl(POS playerPos)
{
	// �G�̈ړ��𒲐�
	// �G�̎�ނ��Ƃɓ����ύX
	// �ײс@X���W�𒲐�
	// �I�@�@Y���W�𒲐�
	// ���@�@XY���W�𒲐�
	// ����׺�݁@X���W�𒲐�
	// ����׺�݁@Y���W�𒲐�
	//	��BOSS�@�@�������Ȃ�
	
	for (int y = 0; y < GET_ENEMY; y++)
	{
		if (enemy[y].life > 0)
		{
			if (enemyCnt < 64)
			{
				switch (enemy[y].charType)
				{
					// �ײт̈ړ�
				case ENEMY_TYPE_SLIME:
					if (enemyMoveX(&enemy[y], playerPos) == 0)
					{
						enemyMoveY(&enemy[y], playerPos);
					}
					break;
					// �I�̈ړ�
				case ENEMY_TYPE_BEE:
					enemyMoveXY(&enemy[y], playerPos);
					if (enemyMoveY(&enemy[y], playerPos) == 0)
					{
						enemyMoveX(&enemy[y], playerPos);
					}
					break;
					// ���̈ړ�
				case ENEMY_TYPE_FLAME:
					enemyMoveXY(&enemy[y], playerPos);
					break;
					// ����׺�݂̈ړ�
				case ENEMY_TYPE_R_DRAGON:
					if (enemyMoveX(&enemy[y], playerPos) == 0)
					{
						enemyMoveY(&enemy[y], playerPos);
					}
					break;
					// ����׺�݂̈ړ�
				case ENEMY_TYPE_M_DORAGON:
					if (enemyMoveY(&enemy[y], playerPos) == 0)
					{
						enemyMoveX(&enemy[y], playerPos);
					}
					break;
					// �޽�̈ړ�
				case ENEMY_TYPE_BOSS:
					enemyMoveXY(&enemy[y], playerPos);
					break;
				default:
					//AST();
					break;
				}
			}
			// �G����������Ƃ������e�𐶐�
			EnemyCreateShot(enemy[y].pos, enemy[y].moveDir);
		}
		else	// ����ł���G�𐶐�
		{
			eCnt++;
			if (stageID == STAGE_ID_START)
			{
				if(eCnt >= 150)
				{
					CreateEnemy(y);
					
					eCnt = 0;
				}
				//CreateEnemy(y);
			}
		}
		 
		
		//	�G�����Ԋu�ɓ����������
		if (enemyCnt > 128)
		{
			enemyCnt = 0;
		}

		/*if (stageID == STAGE_ID_3)
		{
			if (enemy[0].life == 0)
			{
				ClearInit();
			}
		}*/

		PlayerHitCheck(enemy[y].pos, enemy[y].offsetSize, enemy[y].life);

		// �\������ς���
		AddCharOrder(CHARA_TYPE_ENEMY, y, enemy[y].pos.y);
		AddCharOrder(CHARA_TYPE_ENEMY2, y, enemy[0].pos.y);
		
		
	}
	eShotCnt++;
	enemyCnt++;
}
//void BossControl2(POS playerPos)
//{
//	for (int y = 0; y < GET_ENEMY; y++)
//	{
//		if (enemy[0].life > 0)
//		{
//			// �G����������Ƃ������e�𐶐�
//			EnemyCreateShot(enemy[0].pos, enemy[0].moveDir);
//
//			enemyMoveXY(&enemy[0], playerPos);
//
//			// �G�Ǝ��@�̓����蔻��
//			PlayerHitCheck(enemy[0].pos, enemy[0].offsetSize, enemy[0].life);
//
//			AddCharOrder(CHARA_TYPE_ENEMY2, y, enemy[0].pos.y);
//			EnemyShotControl(playerPos);
//		}
//		if (stageID == STAGE_ID_START)
//		{
//			enemy[0].life = 0;
//		}
//		else if (stageID == STAGE_ID_2)
//		{
//			enemy[0].life = 0;
//		}
//		else if (stageID == STAGE_ID_3)
//		{
//			enemy[0].life = enemy[0].lifeMax;
//		}
//	}
//}

// �ð��3�œG�����@�����񂾂珉����
void Delete2(int pLife)
{
	if (stageID == STAGE_ID_3)
	{
		if (enemy[0].life == 0)
		{
			ClearInit();
		}
		else if (pLife == 0)
		{
			GameOverInit();
		}
	}
}
// �޽�̕\��
void BossDraw2(void)
{
	int tmpAnimID;
	int tmpMix;
	tmpAnimID = (enemy[0].animCnt / 15) % 4;
	tmpMix = tmpAnimID + (enemy[0].moveDir * 4);

	if (enemy[0].life > 0 && stageID == STAGE_ID_3)
	{
		DrawGraph(enemy[0].pos.x - enemy[0].offsetSize.x + mapPos.x,
			enemy[0].pos.y - enemy[0].offsetSize.y + mapPos.y,
			enemyImage[enemy[0].charType][tmpMix], true);

		DrawBox(enemy[0].pos.x - 50 + mapPos.x,
			enemy[0].pos.y - 65 + mapPos.y,
			enemy[0].pos.x - 50 + 4 * enemy[0].life + mapPos.x,
			enemy[0].pos.y - 45 - 30 + mapPos.y,
			GetColor(255, 0, 0), true);

		DrawBox(enemy[0].pos.x - 50 + mapPos.x,
			enemy[0].pos.y - 65 + mapPos.y,
			enemy[0].pos.x - 50 + 4 * enemy[0].lifeMax + mapPos.x,
			enemy[0].pos.y - 45 - 30 + mapPos.y,
			GetColor(255, 255, 255), false);

		/*DrawBox(enemy[0].pos.x - enemy[0].offsetSize.x + mapPos.x,
			enemy[0].pos.y - enemy[0].offsetSize.y + mapPos.y,
			enemy[0].pos.x + enemy[0].offsetSize.x + mapPos.x,
			enemy[0].pos.y + enemy[0].offsetSize.y + mapPos.y, GetColor(255, 255, 255), false);*/
	}
	else
	{

	}
	// �̗͂̕\��
	DrawFormatString(enemy[0].pos.x + 50 + mapPos.x, enemy[0].pos.y + mapPos.y, GetColor(0, 255, 255), "%d", enemy[0].life);

	//DrawBox(enemy[0].pos.x - 40 + mapPos.x,
	//		enemy[0].pos.y - 70 + mapPos.y,
	//		enemy[0].pos.x - 40 + mapPos.x,
	//		enemy[0].pos.y - 70  + mapPos.y,
	//	GetColor(0, 255, 255), false);

	/*DrawBox(enemy[0].pos.x - 40 + mapPos.x,
			enemy[0].pos.y - 70 + mapPos.y,
			enemy[0].pos.x + 40 * enemy[0].life / enemy[0].lifeMax + mapPos.x,
			enemy[0].pos.y - 10 - 70 + mapPos.y,
		GetColor(0, 255, 255), true);*/
}


// �e�ƓG�̓����蔻��
bool EnemyHitCheck(POS sPos, POS sSize,int sLife ,int index)
{
	bool rtnFlag = false;

		for (int x = 0; x < GET_ENEMY; x++)
		{
			if (sLife > 0 && enemy[x].life > 0)
			{
				if ((enemy[x].pos.x + enemyMaster[enemy[x].charType].size.x / 2 > sPos.x - sSize.x) &&
					(enemy[x].pos.x - enemyMaster[enemy[x].charType].size.x / 2 <= sPos.x + sSize.x) &&
					(enemy[x].pos.y + enemyMaster[enemy[x].charType].size.y / 2 > sPos.y - sSize.y) &&
					(enemy[x].pos.y - enemyMaster[enemy[x].charType].size.y / 2 <= sPos.y + sSize.y))
				{

					DeletShot(index);

					enemy[x].life--;
					rtnFlag = true;
					if (enemy[x].life == 0)
					{
						AddScr(enemy[x].point);
						Draw(enemy[x].point);
					}
				}
			}
			
	}
	return rtnFlag;
}
	

// �c��
bool enemyMoveY(CHARACTER *enemy1, POS player)
{
	
	// �c��
	int diffY = player.y - (*enemy1).pos.y;
	(*enemy1).moveSpeed = 2;
	
		POS enemyPosCopy = (*enemy1).pos;
		POS enemyHitCheck = enemyPosCopy;
		if (diffY >= 0)
		{
			(*enemy1).moveSpeed = diffY < (*enemy1).moveSpeed ? diffY : (*enemy1).moveSpeed;
			(*enemy1).pos.y += (*enemy1).moveSpeed;
			(*enemy1).moveDir = DIR_DOWN;
		}
		else
		{
			(*enemy1).moveSpeed = diffY > -(*enemy1).moveSpeed ? -diffY : (*enemy1).moveSpeed;
			(*enemy1).pos.y -= (*enemy1).moveSpeed;
			(*enemy1).moveDir = DIR_UP;
		}
		
	
	return (*enemy1).moveSpeed;

}
// ����
bool enemyMoveX(CHARACTER *enemy1,POS player)
{
	POS enemyPosCopy = (*enemy1).pos;
	POS enemyHitCheck = enemyPosCopy;
	// ����
	int diffX = player.x - (*enemy1).pos.x;
	(*enemy1).moveSpeed = 2;
	if (diffX >= 0)
	{
		(*enemy1).moveSpeed = diffX < (*enemy1).moveSpeed ? diffX : (*enemy1).moveSpeed;
		(*enemy1).pos.x += (*enemy1).moveSpeed;
		(*enemy1).moveDir = DIR_RIGHT;
		/*enemyHitCheck.x = enemyPosCopy.x + (*enemy1).offsetSize.x;
		if (EnemyIsPass(enemyHitCheck))
		{
			(*enemy1).pos = enemyPosCopy;
		}*/
	}
	else
	{
		(*enemy1).moveSpeed = diffX > -(*enemy1).moveSpeed ? -diffX : (*enemy1).moveSpeed;
		(*enemy1).pos.x -= (*enemy1).moveSpeed;
		(*enemy1).moveDir = DIR_LEFT;
		/*enemyHitCheck.x = enemyPosCopy.x - (*enemy1).offsetSize.x;
		if (EnemyIsPass(enemyHitCheck))
		{
			(*enemy1).pos = enemyPosCopy;
		}*/
	}

	
	return (*enemy1).moveSpeed;
}
// �c��
bool enemyMoveXY(CHARACTER *enemy, POS player)
{
	int diffX = player.x - (*enemy).pos.x;
	int diffY = player.y - (*enemy).pos.y;
	(*enemy).moveSpeed = 2;
	if (abs(diffX) <= abs(diffY))
	{
		(*enemy).moveSpeed = enemyMoveY( enemy, player);
	}
	else
	{
		(*enemy).moveSpeed = enemyMoveX(enemy, player);
	}
	return (*enemy).moveSpeed;
}

// �G�̕`��
void EnemyDraw(void)
{
	for (int y = 0; y < GET_ENEMY; y++)
	{
		if (enemy[y].life > 0)
		{
			int tmpAnimID;

			tmpAnimID = (enemy[y].animCnt / 15) % 4;
			// �G�̕\��
			DrawGraph(enemy[y].pos.x - enemyMaster[enemy[y].charType].offsetSize.x + mapPos.x, enemy[y].pos.y - enemyMaster[enemy[y].charType].offsetSize.y + mapPos.y,
				enemyImage[enemy[y].charType][tmpAnimID + (enemy[y].moveDir * 4)], true);

			DrawBox(enemy[y].pos.x - enemy[y].size.x + mapPos.x,
					enemy[y].pos.y - enemy[y].size.y + mapPos.y,
					enemy[y].pos.x + enemy[y].size.x + mapPos.x,
					enemy[y].pos.y + enemy[y].size.y + mapPos.y, GetColor(255, 255, 255), false);
		}
		else if(enemy[y].life == 0 || stageID == STAGE_ID_2)
		{

		}
			
	}
		/*POS indexPos;
		indexPos = PosToIndex(enemy[y].pos);*/
}
// �G�̕`��
void EnemyOrderDraw(int index)
{
	enemy[index].animCnt++;
	if (enemy[index].life > 0 && stageID == STAGE_ID_START)
	{
		int tmpAnimID;
		int tmpMix;
		tmpAnimID = (enemy[index].animCnt / 15) % 4;
		tmpMix = tmpAnimID + (enemy[index].moveDir * 4);

		DrawGraph(enemy[index].pos.x - enemy[enemy[index].charType].offsetSize.x + mapPos.x,
			enemy[index].pos.y - enemy[enemy[index].charType].offsetSize.y + mapPos.y,
			enemyImage[enemy[index].charType][tmpMix], true);



		POS indexPos;
		indexPos = PosToIndex(enemy[index].pos);


		/*DrawBox(enemy[index].pos.x - enemy[index].offsetSize.x + mapPos.x,
				enemy[index].pos.y - enemy[index].offsetSize.y + mapPos.y,
				enemy[index].pos.x + enemy[index].offsetSize.x + mapPos.x,
				enemy[index].pos.y + enemy[index].offsetSize.y + mapPos.y, GetColor(255, 255, 255), false);*/
		// �̗͂̕\��
		DrawBox(enemy[index].pos.x - 15 + mapPos.x,
			enemy[index].pos.y - 20 + mapPos.y,
			enemy[index].pos.x - 15 + 10 * enemy[index].life + mapPos.x,
			enemy[index].pos.y - 30 + mapPos.y,
			GetColor(255, 0, 0), true);

		DrawBox(enemy[index].pos.x - 15 + mapPos.x,
			enemy[index].pos.y - 20 + mapPos.y,
			enemy[index].pos.x - 15 + 10 * enemy[index].lifeMax + mapPos.x,
			enemy[index].pos.y - 30 + mapPos.y,
			GetColor(255, 255, 255), false);

		DrawFormatString(enemy[index].pos.x + 20+ mapPos.x,
			enemy[index].pos.y - 20 + mapPos.y, 
			GetColor(0, 0, 255), "%d",
			enemy[index].life);
		// �̗��ް�̕\��
		/*DrawBox(enemy[index].pos.x + mapPos.x, enemy[index].pos.y - 20 + mapPos.y, enemy[index].pos.x + mapPos.x, enemy[index].pos.y + 20 + mapPos.y, GetColor(0, 255, 255), false);
		DrawBox(enemy[index].pos.x + mapPos.x, enemy[index].pos.y - 20 + mapPos.y, enemy[index].pos.x + 20 * enemy[index].life / enemy[index].lifeMax + mapPos.x, enemy[index].pos.y + 20 + mapPos.y, GetColor(0, 255, 255), true);*/
		
	}
}
// �G�̐���
void CreateEnemy(int index)
{
	// �G�̐��ƈʒu������тɐ���
	for (int y = 0; y < MAP_Y; y++)
	{
		for (int x = 0; x < MAP_X; x++)
		{
			//map[y][x] = STAGE_ID_START;

			if (map[y][x] == 34)
			{
				//enemy[index].pos = { GetRand(CHIP_SIZE_X * MAP_X - 1), GetRand(CHIP_SIZE_Y * MAP_Y - 1) };
				enemy[index].life = enemy[index].lifeMax;
				enemy[index].pos = { 300,1070 };
			}
		}
		
	}
}
// �G�̍폜
void DeleteEnemy(void)
{
	for (int y = 0; y < GET_ENEMY; y++)
	{
		enemy[y].life = 0;
	}
}