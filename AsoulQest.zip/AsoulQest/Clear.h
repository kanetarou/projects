#pragma once

void ClearInit(void);
void ClearScene(void);
void ClearDraw(void);

extern int clearImage;
