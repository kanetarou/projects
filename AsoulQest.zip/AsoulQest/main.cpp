/*-------------------------------------------------

		AsoulQest

		2019.09.26  ���q�@�ɑ��Y
		��o���@11 / 15  17:00�܂�

---------------------------------------------------*/
#include "DxLib.h"
#include "main.h"
#include "Game.h"
#include "Title.h"
#include "Over.h"
#include "Stage.h"
#include "KeyCheck.h"
#include "Playerh.h"
#include "Shot.h"
#include "Enemy.h"
#include "Effect.h"
#include "Clear.h"
SCN_ID scnID;


// Ҳ�ٰ��
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	
	//System�̏�����
	if (!SysInit())
	{
		return false;
	}
	
	//�Q�[�����[�v
	//-------------------------------------------------------
	while (ProcessMessage() == 0 && CheckHitKey(KEY_INPUT_ESCAPE) == 0)
	{
		FadeInit();
		OrderInit();
		KeyCheck();
		
		switch (scnID)
		{
			// ���ټ��
		case SCN_ID_TITLE:
			TitleScene();
			break;
			// �ްѼ��
		case SCN_ID_GAME:
			GameScene();
			break;
			// �ްѵ��ް���
		case SCN_ID_GAMEOVER:
			GameOverScene();
			break;
			// �ر���
		case SCN_ID_CLEAR:
			ClearScene();
			break;
		default:
			AST();
			break;
		}
	}
	DxLib_End();
	return 0;
	
}


// ���т̏�����
bool SysInit(void)
{
	bool rtnFlag = true;

	// ���я���
	SetWindowText("1916010_���q�ɑ��Y");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);			// 800*600�ޯāA65536�F���[�h�ɐݒ�(SysInit)

	ChangeWindowMode(true);									// true:window  false:�ٽ�ذ�(SysInit)
	if (DxLib_Init() == -1)									// (SysInit)
	{
		AST();
		return false;
	}
	SetDrawScreen(DX_SCREEN_BACK);

	// �֐��̌Ăяo��
	
	EffectInit();
	//GameInit();
	//PlayerInit();
	ShotInit();
	//BossInit();
	//EnemyInit();
	AutoMaze();
	ClearInit();
	// ���̐F�𓧉߂���
	SetTransColor(255, 0, 255); 

	// ���ى�ʂ̕`��
	titleImage = LoadGraph("image/title.bmp");
	if (titleImage == -1)
	{
		AST();
		rtnFlag = false;
	}
	// ���ى�ʂ̕`��
	tImag = LoadGraph("image/sougen.png");
	if (tImag == -1)
	{
		AST();
		rtnFlag = false;
	}

	// ���ķ��̕`��
	HsKeyImage = LoadGraph("image/HitStartKey.png");
	if (HsKeyImage == -1)
	{
		AST();
		rtnFlag = false;
	}

	// GameOver�̕`��
	GameOverImage = LoadGraph("image/GameOver.png");
	if (GameOverImage == -1)
	{
		AST();
		rtnFlag = false;
	}


	// �ر���
	clearImage = LoadGraph("image/clear.png");
	if (clearImage == -1)
	{
		AST();
		rtnFlag = false;
	}
	
	// ϯ�߂̕`��
	if (LoadDivGraph("image/map.bmp", CHIP_MAX, CHIP_X, CHIP_Y, CHIP_SIZE_X, CHIP_SIZE_Y,
		&chipImage[0]) == -1)
	{
		AST();
		rtnFlag = false;
	}
	// ��ڲ԰�̕`��
	if (LoadDivGraph("image/player.bmp", PL_MAX, PL_X, PL_Y, PL_SIZE_X,
		PL_SIZE_Y, &playerImage[0]) == -1)
	{
		AST();
		rtnFlag = false;
	}
	// ���@�̔����̕`��		
	if(LoadDivGraph("image/bakuha.bmp", 3, 3, 1, PL_SIZE_X,
		PL_SIZE_Y, &bombImage[0]) == -1)
	{
		AST();
		rtnFlag = false;
	}

	// �G�̕`��
	const char *fileList[4] =
	{
		{ "image/enemy0.bmp" },
		{ "image/enemy1.bmp" },
		{ "image/enemy2.bmp" },
		{ "image/enemy3.bmp" },

	};
	for (int y = 0; y < 4; y++)
	{
		if (LoadDivGraph(fileList[y], ENEMY_MAX, ENEMY_CHIP_X, ENEMY_CHIP_Y, 96 / 4, 128 / 4, &enemyImage[y][0]) == -1)
		{
			AST();
			rtnFlag = false;
		}
	}


	// BOSS
	if (LoadDivGraph("image/enemy5.bmp", ENEMY_MAX, ENEMY_CHIP_X, ENEMY_CHIP_Y, BOSS_X, BOSS_Y, &enemyImage[ENEMY_TYPE_BOSS][0]) == -1)
	{
		AST();
		rtnFlag = false;
	}
	// BLUE DRAGON 
	if (LoadDivGraph("image/enemy9.bmp", ENEMY_MAX, ENEMY_CHIP_X, ENEMY_CHIP_Y, DORAGON_X, DORAGON_Y, &enemyImage[ENEMY_TYPE_M_DORAGON][0]) == -1)
	{
		AST();
		rtnFlag = false;
	}

	
	// ���̕`��
	if (LoadDivGraph("image/shot.bmp", SHOT_IMAGE_MAX, 2, 1, SHOT_X, SHOT_Y, &shotImage[0]) == -1)
	{
		AST();
		rtnFlag = false;
	}

	// �G�̒e
	if (LoadDivGraph("image/bullet.bmp", SHOT_IMAGE_MAX, 2, 1, SHOT_X, SHOT_Y, &eShotImage[0]) == -1)
	{
		AST();
		rtnFlag = false;
	}
	// A-Z�̕`��
	if (LoadDivGraph("image/font16pix.png", FONT_MAX, FONT_MAX, 1, 432 / 26, 16, &fontImage[0]) == -1)
	{
		AST();
		rtnFlag = false;
	}
	// �����̕`��
	if (LoadDivGraph("image/number16pix.png", NUMBER_MAX, NUMBER_MAX, 1, 16, 16, &nmbImage[0]) == -1)
	{
		AST();
		rtnFlag = false;
	}

	// �ްѼ�݂�т���
	TitleInit();
	
	return rtnFlag;
}
