/*-------------------------------------------------

		AsoulQest

		2019.09.26  ���q�@�ɑ��Y

---------------------------------------------------*/
#include "DxLib.h"
#include "file.h"




//// �ړ����̷�ؽ�
//const int KeyList = 
//{
//	// ��			�E					��				��
//	{ KEY_INPUT_W,	KEY_INPUT_D,		KEY_INPUT_S,	KEY_INPUT_A },		
//};



int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	
	
	//�Q�[�����[�v
	//-------------------------------------------------------
	while (ProcessMessage() == 0 && CheckHitKey(KEY_INPUT_ESCAPE) == 0)
	{
		
	
	}

	// ���я���
	SetWindowText("KANEKO");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);			// 800*600�ޯāA65536�F���[�h�ɐݒ�(SysInit)

	ChangeWindowMode(true);									// true:window  false:�ٽ�ذ�(SysInit)
	if (DxLib_Init() == -1)									// (SysInit)
	{
		return false;
	}
	SetDrawScreen(DX_SCREEN_BACK);
	DxLib_End();
	return 0;

}




