#include "DxLib.h"


