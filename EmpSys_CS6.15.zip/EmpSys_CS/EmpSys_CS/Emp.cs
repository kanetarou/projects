﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//-----------------システム共通情報保持-----------------------

//● 各クラスから呼び出される
//● ログイン情報を扱うプロパティを持つ

namespace EmpSys_CS
{
    internal class Emp
    {
        public String Id { get; set; }       //社員情報ID
        public String Name { get; set; }     //社員情報ユーザー名  
        public String Phone { get; set; }   //社員情報電話番号
        public String Post { get; set; }    //郵便番号
        public String Address { get; set; } //住所
        public String Mail { get; set; }    //メールアドレス

       
        
    }
}
