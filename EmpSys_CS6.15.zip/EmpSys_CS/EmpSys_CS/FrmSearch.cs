﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmSearch : FrmEmp
    {
        public FrmSearch()
        {
            InitializeComponent();
        }

        private void FrmSearch_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
            textBox2.BackColor = SystemColors.Window;

            textBox3.ReadOnly = true;
            textBox3.BackColor = SystemColors.Window;

            textBox4.ReadOnly = true;
            textBox4.BackColor = SystemColors.Window;

            textBox5.ReadOnly = true;
            textBox5.BackColor = SystemColors.Window;

            textBox6.ReadOnly = true;
            textBox6.BackColor = SystemColors.Window;
        }

        public override void BtnExecute_Click(object sender, EventArgs e)
        {
            try
            {
                DBAccess db = new DBAccess();
                Emp emp;
                emp = db.GetEmp(textBox1.Text);

                if(emp != null)
                {
                    textBox1.Text = emp.Id;
                    textBox2.Text = emp.Name;
                    textBox3.Text = emp.Phone;
                    textBox4.Text = emp.Post;
                    textBox5.Text = emp.Address;
                    textBox6.Text = emp.Mail;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生");
            }
        }
    }
}
