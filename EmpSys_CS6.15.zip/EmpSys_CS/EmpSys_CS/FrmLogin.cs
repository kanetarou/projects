﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmLogin : Form
    {
        static User user = new User();
        static FrmLogin frmLogin;
        //ログイン回数チェック変数
        int i;
        //認証ロック時のタイマー
        int tCnt;
        
        public FrmLogin()
        {
            InitializeComponent();
            frmLogin = this;
            txPas.PasswordChar = '●';
            txID.Focus();
            i = 0;
            tCnt = 60;
            
        }

        private void LoginBtn(object sender, EventArgs e)
        {
            try
            {
                DBAccess db = new DBAccess();
                user = db.GetUser(txID.Text, txPas.Text);

                //3回間違えると60秒間の認証ロック
                if (user != null)
                {
                    FrmMenu menu = new FrmMenu();
                    menu.Show();
                    this.Visible = false;
                    txID.Text = "";
                    txPas.Text = "";
                    i = 0;
                }
                else
                {
                    i += 1;

                    txID.Text = "";
                    txPas.Text = "";
                    switch(i)
                    {
                        case 1:
                            MessageBox.Show("IDかパスワードが間違っています\n※あと2回失敗するとロックがかかります", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        case 2:
                            MessageBox.Show("IDかパスワードが間違っています\n※あと1回失敗するとロックがかかります", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        default:
                            break;
                    }
                    
                }
                if(i >= 3)
                {
                    MessageBox.Show("回数制限を超えました\n1分間ログインできません", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    button1.Enabled = false;
                    txID.Enabled = false;
                    txPas.Enabled = false;
                    //タイマー作動
                    timer1.Enabled = true;
                    i = 0;
                }

                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void EndBtn(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public String GetUser()
        {
            if (user != null)
            {
                return user.LogName;
            }
            else
            {
                return "null";
            }
        }

        public string GetAdmin()
        {
            if (user != null)
            {
                return user.LogAdmin;
            }
            else
            {
                return "null";
            }
        }

        //タイマー関数
        private void Tick_Timer(object sender, EventArgs e)
        {
            timer1 = new System.Windows.Forms.Timer();

            timer1.Tick += new EventHandler(CountDown);
            timer1.Interval = 1000;

            if (timer1.Enabled == true)
            {
                timer1.Start();
                label3.Visible = true;
            }
            else
            {
                tCnt = 60;
            }
        }

        private void CountDown(object sender, EventArgs e)
        {
            if(tCnt == 0)
            {
                timer1.Stop();
                button1.Enabled = true;
                txID.Enabled = true;
                txPas.Enabled = true;
                label3.Visible = false;
                
            }
            else if(tCnt > 0)
            {
                
                tCnt--;
                label3.Text = "残り" + tCnt.ToString() + "秒";
            }
        }
    }
}
