﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmMenu : Form
    {
        FrmLogin frmlog = new FrmLogin();
        FrmSearch frmS;

        DialogResult res;       //ショートカットキー用
        public FrmMenu()
        {
            InitializeComponent();
            button1.Focus();
        }

        //検索画面ボタン
        private void BtnSearch_click(object sender, EventArgs e)
        {
            //Searchクラスをインスタンス
            //検索画面の表示
            frmS = new FrmSearch();
            frmS.Show();
            this.Close();
        }

        //ログアウトボタン
        private void BtnLogout(object sender, EventArgs e)
        {
            frmlog.Show();
            this.Close();
        }

        //終了ボタン
        private void EndBtn(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //ログイン中のユーザー名
        private void UserName_Load(object sender, EventArgs e)
        {
            label5.Text = frmlog.GetUser() + "でログイン中";
        }

        //一覧画面ボタン
        private void BtnPage_Cliak(object sender, EventArgs e)
        {
                FrmList list = new FrmList();
                list.Show();
                this.Close();
        }

        //ショートカットキー設定
        private void GetKeyDown(object sender, KeyEventArgs e)
        {
            //一覧ページのショートカット
            if(e.KeyData == (Keys.P | Keys.Shift))
            {
                res = MessageBox.Show("一覧画面を開きますか？", "ショートカット", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (res == DialogResult.Yes)
                {
                    FrmList list = new FrmList();
                    list.Show();
                    this.Close();
                }
            }

            //検索画面のショートカット
            if (e.KeyData == (Keys.K | Keys.Shift))
            {
                res = MessageBox.Show("検索画面を開きますか？", "ショートカット", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (res == DialogResult.Yes)
                {
                    frmS = new FrmSearch();
                    frmS.Show();
                    this.Close();
                }
            }

            //ログアウトのショートカット
            if (e.KeyData == (Keys.R | Keys.Shift))
            {
                res = MessageBox.Show("ログアウトしますか？", "ショートカット", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (res == DialogResult.Yes)
                {
                    frmlog.Show();
                    this.Close();
                }
            }

            //終了のショートカット
            if (e.KeyData == (Keys.E | Keys.Shift))
            {
                res = MessageBox.Show("終了しますか？", "ショートカット", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (res == DialogResult.Yes)
                {
                    Application.Exit();
                }
            }
        }
    }
}
