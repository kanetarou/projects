﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmList : Form
    {
        Emp emp = new Emp();
        FrmMenu menu;

        FrmRegistration reg;            //登録フォーム

        FrmUpdate up;                   //更新フォーム

        FrmDelete del;                  //削除フォーム

        FrmLogin user = new FrmLogin();//権限を持っているか

        DialogResult re;                //メッセージ判断用変数

        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter sda;
        DataTable dt = new DataTable();

        public FrmList()
        {
            InitializeComponent();

            button5.TabIndex = 0;
            
            button4.Enabled = false;
            textBox1.Text = "System Log\r\n";
        }

        //メニュー画面の呼び出し
        private void BtnMenu_Click(object sender, EventArgs e)
        {
            menu = new FrmMenu();
            menu.Show();
            this.Close();
        }

        //登録画面の呼び出し
        private void BtnReg_Click(object sender, EventArgs e)
        {
            if (user.GetAdmin() == "0")
            {
                re = MessageBox.Show("権限がありません\nアカウントを切り替えますか?", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (re == DialogResult.Yes)
                {
                    MessageBox.Show("ログアウトします");
                    user.Show();
                    this.Close();
                }
            }
            else if (user.GetAdmin() == "1")
            {
                reg = new FrmRegistration();
                reg.Show();
                this.Close();
            }

        }

        //更新画面の呼び出し
        private void BtnUpData_Click(object sender, EventArgs e)
        {
            //選択中の行がある場合
            //その行のIDを取得

            if (user.GetAdmin() == "0")
            {
                re = MessageBox.Show("権限がありません\nアカウントを切り替えますか?", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (re == DialogResult.Yes)
                {
                    MessageBox.Show("ログアウトします");
                    user.Show();
                    this.Close();
                }
            }
            else if (user.GetAdmin() == "1")
            {
                for (int i = 0; i < dgv.RowCount; i++)
                {
                    if (dgv.Rows[i].Selected)
                    {//IDを取得する
                        emp.Id = dt.Rows[i][0].ToString();

                        up = new FrmUpdate(emp.Id);

                        up.Show();
                        this.Close();
                        break;
                    }
                }
            }

        }

        //削除画面の呼び出し
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            /*//選択中の行がある場合
            //その行のIDを取得

            //例　ケース
            //switch (dgv.RowCount)
            //{
            //    case 0:
            //        if (dgv.Rows[dgv.RowCount].Selected)
            //        {
            //            del = new FrmDelete();
            //            del.Show();
            //            this.Close();
            //        }
            //        break;
            //        case 1:

            //    default:
            //        //データを選択してから画面遷移させる
            //        MessageBox.Show("削除するデータを選択してください", "確認", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        break;
            //}*/
            if (user.GetAdmin() == "0")
            {
                re = MessageBox.Show("権限がありません\nアカウントを切り替えますか?", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (re == DialogResult.Yes)
                {
                    MessageBox.Show("ログアウトします");
                    user.Show();
                    this.Close();
                }
            }
            else if (user.GetAdmin() == "1")
            {
                for (int i = 0; i < dgv.RowCount; i++)
                {
                    if (dgv.Rows[i].Selected)
                    {   
                        //IDを取得する
                        emp.Id = dt.Rows[i][0].ToString();
                        del = new FrmDelete(emp.Id);
                        
                        del.Show();
                        this.Close();
                        break;
                    }
                }
            }
        }

        //ファイルを保存
        static public void File_Export(DataTable dt, string fPath)
        {
            int row = dt.Rows.Count;
            int col = dt.Columns.Count;


            StreamWriter fp = new StreamWriter(fPath, false, Encoding.UTF8);

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    fp.Write(dt.Rows[i][j].ToString() + ",");
                }
                fp.WriteLine();
            }

            fp.Close();
        }

        //ファイル保存
        private void BtnFile_Click(object sender, EventArgs e)
        {
            if (user.GetAdmin() == "0")
            {
                re = MessageBox.Show("権限がありません\nアカウントを切り替えますか?", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (re == DialogResult.Yes)
                {
                    MessageBox.Show("ログアウトします");
                    user.Show();
                    this.Close();
                }
            }
            else if (user.GetAdmin() == "1")
            {
                //名前をつけて保存
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.FileName = "新しい名前.csv";
                sfd.Filter = "CSVファイル(*.csv)|*.csv|TXTファイル(*.txt)|*.txt|すべてのファイル(*.*)|*.*";
                sfd.Title = "保存先のファイルを指定してください";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    File_Export(dt, sfd.FileName);
                    MessageBox.Show("保存しました");
                }
            }
        }

        //テーブルの表示
        private void button5_Click(object sender, EventArgs e)
        {
            if (user.GetAdmin() == "1")
            {
                // TODO: このコード行はデータを 'empSys_CSDBDataSet2.employee' テーブルに読み込みます。必要に応じて移動、または削除をしてください。
                this.employeeTableAdapter.Fill(this.empSys_CSDBDataSet2.employee);
                try
                {
                    con = new SqlConnection();
                    cmd = new SqlCommand();
                    sda = new SqlDataAdapter();


                    ConnectionStringSettings cs = ConfigurationManager.ConnectionStrings
                        ["EmpSys_CS.Properties.Settings.EmpSys_CSDBConnectionString"];
                    if (cs == null)
                    {
                        throw new Exception("データベースへの接続文字列が正しく設定されていません");
                    }
                    con.ConnectionString = cs.ConnectionString;
                    con.Open();
                    cmd.Connection = con;
                    cmd.CommandText = "SELECT * FROM employee";
                    sda.SelectCommand = cmd;
                    sda.Fill(dt);
                    dgv.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    con.Close();
                    con.Dispose();
                    cmd.Dispose();
                    sda.Dispose();
                    dt.Dispose();
                }
                button5.TabIndex++;

                //表示されているときだけ保存可能
                if (button5.TabIndex >= 1)
                {
                    button5.Enabled = false;
                    button4.Enabled = true;
                }
            }
            else if(user.GetAdmin() == "0")
            {
                re = MessageBox.Show("権限がありません\nアカウントを切り替えますか?", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (re == DialogResult.Yes)
                {
                    MessageBox.Show("ログアウトします");
                    user.Show();
                    this.Close();
                }
            }
        }

        //ログの表示
        public void textBox_log(string strId)
        {
            textBox1.Text += System.DateTime.Now.ToString() + " : " + user.GetUser() + "がID:" + strId + "\r\n";
        }
    }
}
