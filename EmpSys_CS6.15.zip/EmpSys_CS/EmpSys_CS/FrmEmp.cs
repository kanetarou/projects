﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmEmp : Form
    {
        public FrmEmp()
        {
            InitializeComponent();
        }

        public virtual void BtnExecute_Click(object sender, EventArgs e)
        {

        }

        protected void BtnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";

            textBox1.Focus();
        }

        protected virtual void BtnMenu_Click(object sender, EventArgs e)
        {
            FrmMenu menu = new FrmMenu();  
            menu.Show();
            this.Close();
        }

        private void BtnSearch_click(object sender, EventArgs e)
        {
            IdSearch();
        }

        public virtual void IdSearch()
        {
            try
            {
                DBAccess db = new DBAccess();
                Emp emp = db.GetEmp(textBox1.Text);

                textBox1.Text = emp.Id;
                textBox2.Text = emp.Name;
                textBox3.Text = emp.Phone;
                textBox4.Text = emp.Post;
                textBox5.Text = emp.Address;
                textBox6.Text = emp.Mail;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(),"例外発生");
                textBox1.Focus();
            }
        }

    }
}
