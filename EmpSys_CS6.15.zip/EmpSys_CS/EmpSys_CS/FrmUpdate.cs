﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmUpdate : FrmEmp
    {
        FrmList list = new FrmList();
        FrmLogin user = new FrmLogin();
        public FrmUpdate(string strId)
        {
            InitializeComponent();
            textBox1.Text = strId;
        }

        public override void BtnExecute_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("変更に間違いはありませんか?", "確認", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (re == DialogResult.OK)
            {

                try
                {
                    DBAccess db = new DBAccess();
                    Emp emp = new Emp();

                    emp.Id = textBox1.Text;
                    emp.Name = textBox2.Text;
                    emp.Phone = textBox3.Text;
                    emp.Post = textBox4.Text;
                    emp.Address = textBox5.Text;
                    emp.Mail = textBox6.Text;

                    db.UpdateEmp(emp);

                    list.textBox_log(emp.Id + "のデータを変更しました");
                    BtnClear_Click(this, System.EventArgs.Empty);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "例外発生");
                    textBox1.Focus();
                }
            }
        }

        private void BtnSearch_cl(object sender, EventArgs e)
        {
            try
            {
                DBAccess db = new DBAccess();
                Emp emp;
                emp = db.GetEmp(textBox1.Text);

                if (emp != null)
                {
                    textBox1.Text = emp.Id;
                    textBox2.Text = emp.Name;
                    textBox3.Text = emp.Phone;
                    textBox4.Text = emp.Post;
                    textBox5.Text = emp.Address;
                    textBox6.Text = emp.Mail;
                }
                else
                {
                    throw new Exception("できない");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生");
            }
        }

        protected override void BtnMenu_Click(object sender, EventArgs e)
        {
            list.Show();
            this.Close();
        }
    }
}
