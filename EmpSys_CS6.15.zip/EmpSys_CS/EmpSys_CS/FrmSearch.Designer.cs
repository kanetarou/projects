﻿namespace EmpSys_CS
{
    partial class FrmSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.empSysCSDBDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.empSys_CSDBDataSet = new EmpSys_CS.EmpSys_CSDBDataSet();
            ((System.ComponentModel.ISupportInitialize)(this.empSysCSDBDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empSys_CSDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Text = "検索";
            this.button1.Click += new System.EventHandler(this.BtnExecute_Click);
            // 
            // b
            // 
            this.b.Visible = false;
            // 
            // empSysCSDBDataSetBindingSource
            // 
            this.empSysCSDBDataSetBindingSource.DataSource = this.empSys_CSDBDataSet;
            this.empSysCSDBDataSetBindingSource.Position = 0;
            // 
            // empSys_CSDBDataSet
            // 
            this.empSys_CSDBDataSet.DataSetName = "EmpSys_CSDBDataSet";
            this.empSys_CSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // FrmSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(698, 450);
            this.Name = "FrmSearch";
            this.Text = "検索画面";
            this.Load += new System.EventHandler(this.FrmSearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.empSysCSDBDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empSys_CSDBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.BindingSource empSysCSDBDataSetBindingSource;
        private EmpSys_CSDBDataSet empSys_CSDBDataSet;
        protected System.Windows.Forms.Button button4;
    }
}