﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Xml.Linq;



//● データベースに接続する
//● 引数で渡されたユーザーIDを元に、loginuserテーブルを参照し、ユーザー名と権限情報を抽出する
//● 引数で渡された社員IDを元に、employeeテーブルから社員情報を抽出する
//● 引数で渡された社員情報をemployeeテーブルに登録する
//● 検索時、既に存在しない社員IDを指定した場合は、エラーメッセージを出力する
//● 登録時、既に存在する社員IDを指定した場合は、エラーメッセージを出力する
namespace EmpSys_CS
{
    internal class DBAccess
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter sda;
        DataTable dt;

        public DBAccess()
        {
            con = new SqlConnection();
            cmd = new SqlCommand();
            sda = new SqlDataAdapter();
            dt = new DataTable();

            ConnectionStringSettings cs = ConfigurationManager.ConnectionStrings
                ["EmpSys_CS.Properties.Settings.EmpSys_CSDBConnectionString"];
            if(cs == null)
            {
                throw new Exception("データベースへの接続文字列が正しく設定されていません");
            }
            else
            {
                con.ConnectionString = cs.ConnectionString;
                
                cmd.Connection = con;
            }
        }

        //ユーザー情報獲得処理
        public User GetUser(string strId,string strPw)
        {
            User user;
            int id;
            //数字か判断
            bool numId = int.TryParse(strId, out id);

            if (strId == " " || strPw == " " || !numId)
            {
                throw new Exception("正しく入力してください");
            }

            try
            {
                con.Open();
                cmd.CommandText = "SELECT * FROM loginuser WHERE ID=@key";
                cmd.Parameters.Clear();
                cmd.Parameters.Add("@key",SqlDbType.Int,4,"ID").Value = strId;
                sda.SelectCommand = cmd;
                sda.Fill(dt);

                if(dt.Rows.Count == 1)
                {
                    user = new User();
                    if (dt.Rows[0]["PASSWORD"].ToString() == strPw)
                    {
                        user.LogName = dt.Rows[0]["NAME"].ToString();
                        user.LogAdmin = dt.Rows[0]["ADMIN"].ToString();
                        return user;
                    }
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "該当するユーザーが存在しません", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                con.Dispose();
                cmd.Dispose();
                sda.Dispose();
                dt.Dispose();
            }
            return null;
        }

        //社員情報の検索
        public Emp GetEmp(string strId)
        {
            Emp emp;
            int id;
            bool numId = int.TryParse(strId, out id);

            if (strId == " " || !numId)
            {
                throw new Exception("IDを正しく入力して下さい");
            }

            try
            {
                con.Open();
                cmd.CommandText = "SELECT * FROM employee WHERE ID=@key";
                cmd.Parameters.Clear();

                cmd.Parameters.Add("@key", SqlDbType.Int, 4, "ID").Value = strId;
                sda.SelectCommand = cmd;

                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    emp = new Emp();
                    emp.Id = dt.Rows[0]["ID"].ToString();
                    emp.Name = dt.Rows[0]["NAME"].ToString();
                    emp.Phone = dt.Rows[0]["PHONE"].ToString();
                    emp.Post = dt.Rows[0]["POST"].ToString();
                    emp.Address = dt.Rows[0]["ADDRESS"].ToString();
                    emp.Mail = dt.Rows[0]["MAIL"].ToString();

                    return emp;
                }
                else
                {
                    throw new Exception("アカウントが存在しません");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                con.Dispose();
                cmd.Dispose();
                sda.Dispose();
                dt.Dispose();
            }
            return null;
        }

        //社員情報を追加で登録する
        public void AddEmp(Emp emp)
        {
            
            if(emp.Id == " ")
            {
                throw new Exception("IDを正しく登録して下さい");
            }
            else if(emp.Name == " ")
            {
                throw new Exception("名前を正しく登録して下さい");
            }

            try
            {
                con.Open();
                cmd.CommandText = "SELECT count(*) FROM employee WHERE ID=@key";

                cmd.Parameters.Clear();
                cmd.Parameters.Add("@key", SqlDbType.Int, 4, "ID").Value = emp.Id;

                int resultScalar = (int)cmd.ExecuteScalar(); 

                if (resultScalar != 0)
                {
                    throw new Exception("このIDはすでに登録済みです");
                }

                cmd.CommandText = "INSERT INTO employee (ID, NAME, PHONE, POST, ADDRESS, MAIL)VALUES(@id, @name, @phone, @post, @address, @mail)";
                cmd.Parameters.Clear();

                cmd.Parameters.Add("@id", SqlDbType.Int, 4, "ID").Value = emp.Id;
                cmd.Parameters.Add("@name", SqlDbType.NVarChar, 50, "NAME").Value = emp.Name;
                cmd.Parameters.Add("@phone", SqlDbType.NVarChar, 50, "PHONE").Value = emp.Phone;
                cmd.Parameters.Add("@post", SqlDbType.NVarChar, 50, "POST").Value = emp.Post;
                cmd.Parameters.Add("@address", SqlDbType.NVarChar, 50, "ADDRESS").Value = emp.Address;
                cmd.Parameters.Add("@mail", SqlDbType.NVarChar, 50, "MAIL").Value = emp.Mail;

                cmd.ExecuteNonQuery();

                //if (cmd.ExecuteNonQuery() != 0)
                //{
                //    throw new Exception("登録に失敗しました");
                //}
                //else
                //{
                    MessageBox.Show("変更が完了しました。");
                //}

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生");
            }
            finally
            {
                con.Close();
                con.Dispose();
                cmd.Dispose();
                sda.Dispose();
                dt.Dispose();
            }
        }


        //社員情報の変更
        public void UpdateEmp(Emp emp)
        {
            if(emp.Id == " ")
            {
                throw new Exception("IDを正しく入力してください");

            }
            if(emp.Name == " ")
            {
                throw new Exception("名前を正しく入力してください");
            }

            try
            {
                con.Open();

                cmd.CommandText = "SELECT count(*) FROM employee WHERE ID=@key";
                cmd.Parameters.Clear();

                cmd.Parameters.Add("@key", SqlDbType.Int, 4, "ID").Value = emp.Id;

                int resultScalar = (int)cmd.ExecuteScalar();
                if (resultScalar == 0)
                {
                    throw new Exception("IDは変更できません");

                }
                cmd.CommandText = "UPDATE employee SET NAME=@name,PHONE=@phone,POST=@post,ADDRESS=@address,MAIL=@mail WHERE ID=@id";
                cmd.Parameters.Clear();

                cmd.Parameters.Add("@id", SqlDbType.Int, 4, "ID").Value = emp.Id;
                cmd.Parameters.Add("@name", SqlDbType.NVarChar, 50, "NAME").Value = emp.Name;
                cmd.Parameters.Add("@phone", SqlDbType.NVarChar, 50, "PHONE").Value = emp.Phone;
                cmd.Parameters.Add("@post", SqlDbType.NVarChar, 50, "POST").Value = emp.Post;
                cmd.Parameters.Add("@address", SqlDbType.NVarChar, 50, "ADDRESS").Value = emp.Address;
                cmd.Parameters.Add("@mail", SqlDbType.NVarChar, 50, "MAIL").Value = emp.Mail;


                cmd.ExecuteNonQuery();

                if (cmd.ExecuteNonQuery() != 1)
                {
                    throw new Exception("更新に失敗");
                }
                else
                {
                    MessageBox.Show("更新が完了しました");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生");
            }
            finally
            {
                con.Close();
                con.Dispose();
                cmd.Dispose();
                sda.Dispose(); 
                dt.Dispose();
            }
        }


        //社員情報の削除
        public void DeleteEmp(string strId)
        {
            if(strId == " ")
            {
                throw new Exception("IDを正しく入力してください");
            }

            try
            {
                con.Open();

                cmd.CommandText = "SELECT count(*) FROM employee WHERE ID=@key";

                cmd.Parameters.Clear();
                cmd.Parameters.Add("@key", SqlDbType.Int, 4, "ID").Value = strId;

                int strScalar = (int)cmd.ExecuteScalar();
                if (strScalar == 0)
                {
                    throw new Exception("このIDのデータは存在しません");
                }

                cmd.CommandText = "DELETE FROM employee WHERE ID=@id";
                cmd.Parameters.Clear();
                
                cmd.Parameters.Add("@id", SqlDbType.Int, 4, "ID").Value = strId;

                cmd.ExecuteNonQuery();
                
                //if ( cmd.ExecuteNonQuery() == 0) 
                //{
                //    throw new Exception("削除に失敗しました");
                //}
                //else
                //{
                    MessageBox.Show("削除が完了しました");
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生");
            }
            finally
            {
                con.Close();
                con.Dispose();
                cmd.Dispose(); 
                sda.Dispose();
                dt.Dispose();
            }
        }
    }
}
//cmd.ExecuteNonQueryの処理ができない(データテーブル反映させる処理)