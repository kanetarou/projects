﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmDelete : FrmEmp
    {
        Emp emp;
        FrmList list = new FrmList();
        FrmLogin user = new FrmLogin();

        public FrmDelete(string strId)
        {
            InitializeComponent();
            textBox1.Text = strId;

            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            textBox6.Enabled = false;
            button2.Visible = false;
        }
        
        public override void BtnExecute_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("本当に削除しますか?", "確認", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (re == DialogResult.OK)
            {
                //削除処理
                try
                {
                    DBAccess db = new DBAccess();

                    db.DeleteEmp(textBox1.Text);
                    list.textBox_log(textBox1.Text + "を削除しました");
                    
                    BtnClear_Click(this, System.EventArgs.Empty);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void FrmDelete_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
            textBox2.BackColor = SystemColors.Window;

            textBox3.ReadOnly = true;
            textBox3.BackColor = SystemColors.Window;

            textBox4.ReadOnly = true;
            textBox4.BackColor = SystemColors.Window;

            textBox5.ReadOnly = true;
            textBox5.BackColor = SystemColors.Window;

            textBox6.ReadOnly = true;
            textBox6.BackColor = SystemColors.Window;
        }



        //検索ボタン
        private void BtnSearch_cl(object sender, EventArgs e)
        {

            try
            {
                DBAccess db = new DBAccess();

                emp = db.GetEmp(textBox1.Text);

                if (emp != null)
                {
                    textBox1.Text = emp.Id;
                    textBox2.Text = emp.Name;
                    textBox3.Text = emp.Phone;
                    textBox4.Text = emp.Post;
                    textBox5.Text = emp.Address;
                    textBox6.Text = emp.Mail;
                }
                else
                {
                    throw new Exception("できない");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生");
            }
        }

        protected override void BtnMenu_Click(object sender, EventArgs e)
        {
            list.Show();
            this.Close();
        }
        
    }
}
