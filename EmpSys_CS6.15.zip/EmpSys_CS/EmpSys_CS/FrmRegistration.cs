﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmRegistration : FrmEmp
    {

        FrmList list = new FrmList();
        FrmLogin user = new FrmLogin();
        public FrmRegistration()
        {
            InitializeComponent();
        }

        public override void BtnExecute_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("登録情報に間違いはありませんか?", "確認", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (re == DialogResult.OK)
            {
                try
                {
                    DBAccess db = new DBAccess();
                    Emp emp = new Emp();
                    if (emp != null)
                    {
                        emp.Id = textBox1.Text;
                        emp.Name = textBox2.Text;
                        emp.Phone = textBox3.Text;
                        emp.Post = textBox4.Text;
                        emp.Address = textBox5.Text;
                        emp.Mail = textBox6.Text;

                        
                        db.AddEmp(emp);
                        list.textBox_log(emp.Id + "を登録しました");
                    }
                    else
                    {
                        MessageBox.Show("入力してください");
                        list.textBox_log(null);
                    }


                    BtnClear_Click(this, System.EventArgs.Empty);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "例外発生");
                }
            }
        }


        protected override void BtnMenu_Click(object sender, EventArgs e)
        {
            list.Show();
            this.Close();
        }
    }
}
