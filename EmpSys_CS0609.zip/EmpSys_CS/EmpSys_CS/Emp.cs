﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//-----------------システム共通情報保持-----------------------

//● 各クラスから呼び出される
//● ログイン情報を扱うプロパティを持つ

namespace EmpSys_CS
{
    internal class Emp
    {
        public string Id { get; set; }       //社員情報ID
        public string Name { get; set; }     //社員情報ユーザー名  
        public string Phone { get; set; }   //社員情報電話番号
        public string Post { get; set; }    //郵便番号
        public string Address { get; set; } //住所
        public string Mail { get; set; }    //メールアドレス

       
        
    }
}
