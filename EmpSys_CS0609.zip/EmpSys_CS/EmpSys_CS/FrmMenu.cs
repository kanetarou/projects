﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmMenu : Form
    {
        FrmLogin frmlog = new FrmLogin();
        FrmLogin user = new FrmLogin();
        FrmRegistration frmReg;
        FrmSearch frmS;
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void BtnRegistration_Click(object sender, EventArgs e)
        {
            if (user.GetAdmin() == "1")
            {
                //登録画面の表示
                frmReg = new FrmRegistration();
                frmReg.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("権限がありません");
            }
        }

        private void BtnSearch_click(object sender, EventArgs e)
        {
            //Searchクラスをインスタンス
            //検索画面の表示
            frmS = new FrmSearch();
            frmS.Show();
            this.Close();
        }

        private void BtnLogout(object sender, EventArgs e)
        {
            frmlog.Show();
            this.Close();
        }

        private void EndBtn(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void UserName_Load(object sender, EventArgs e)
        {
            this.Text =  user.GetUser() + "でログイン中";
        }
    }
}
