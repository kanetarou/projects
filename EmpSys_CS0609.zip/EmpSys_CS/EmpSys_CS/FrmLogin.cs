﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmLogin : Form
    {
        static User user = new User();
        static FrmLogin frmLogin;

        public FrmLogin()
        {
            InitializeComponent();
            frmLogin = this;
            txPas.PasswordChar = '●';
        }

        private void LoginBtn(object sender, EventArgs e)
        {
            try
            {
                
                DBAccess db = new DBAccess();
                user = db.GetUser(txID.Text, txPas.Text);
                

                FrmMenu menu = new FrmMenu();
                menu.Show();
                this.Visible = false;
                txID.Text = "";
                txPas.Text = "";

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void EndBtn( object sender, EventArgs e )
        {
            Application.Exit();
        }

        public String GetUser()
        {
            if (user != null)
            {
                return user.LogName;
            }
            else
            {
                return "null" ;
            }
        }

        public string GetAdmin()
        {
            if (user != null)
            {
                return user.LogAdmin;
            }
            else
            {
                return "null";
            }
        }
    }
}
