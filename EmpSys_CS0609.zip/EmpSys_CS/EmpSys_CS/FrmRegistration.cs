﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpSys_CS
{
    public partial class FrmRegistration : FrmEmp
    {
        public FrmRegistration()
        {
            InitializeComponent();
        }

        public override void BtnExecute_Click(object sender, EventArgs e)
        {
            try
            {
                Emp emp = new Emp();
                textBox1.Text = emp.Id;
                textBox2.Text = emp.Name;
                textBox3.Text = emp.Phone;
                textBox4.Text = emp.Post;
                textBox5.Text = emp.Address;
                textBox6.Text = emp.Mail;

                DBAccess db = new DBAccess();
                db.AddEmp(emp);

                BtnClear_Click(this,System.EventArgs.Empty);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生");
            }
        }
    }
}
