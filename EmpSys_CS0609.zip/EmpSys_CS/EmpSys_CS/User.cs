﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//-----------------システム共通情報保持-----------------------

//● 各クラスから呼び出される
//● ログイン情報を扱うプロパティを持つ
namespace EmpSys_CS
{
    internal class User
    {
        public string LogName { get; set; }     //ログインユーザー名
        public string LogAdmin { get; set; }     //ログイン権限
    }
}
