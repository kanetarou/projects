#include <time.h>
#include "DxLib.h"
#include "main.h"
#include "Init.h"
#include "Select.h"


bool SysInit(void)
{
	bool rtnFlag = true;

	

	// ���я���
	SetWindowText("15PUZZLE");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);			// 800*600�ޯāA65536�F���[�h�ɐݒ�(SysInit)

	ChangeWindowMode(true);									// true:window  false:�ٽ�ذ�(SysInit)
	if (DxLib_Init() == -1)									// (SysInit)
	{
		return false;
	}
	//srand((unsigned int)time(NULL));

	SetDrawScreen(DX_SCREEN_BACK);
	
	// �߽�ق̕`��
	const char* PuzzleImageName[] = { "image/kabigon.png" ,"image/watasi.png" ,"image/donatu.png" };
	/*puzzleImage = LoadGraph("image/kabigon.png");
	if (puzzleImage == -1)
	{
		AST();
		rtnFlag = false;
	}*/
	// ���݂̕`��

	bImage = LoadGraph("image/button2.png");
	if(bImage == -1)
	{
		AST();
		rtnFlag = false;
	}
	/*if(LoadDivGraph("image/button2.png",BUTTON_MAX, BUTTON_MAX,1,B_SIZE_X,B_SIZE_Y,&bImage,true) == -1)
	{
		AST();
		rtnFlag = false;
	}*/
		
	SelectInit();
	return rtnFlag;
}
