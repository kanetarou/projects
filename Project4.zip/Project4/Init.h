#pragma once



bool SysInit(void);