#include <time.h>
#include "DxLib.h"
#include "main.h"
#include "Game.h"
#include "Select.h"
#include "clear.h"
#include "Mouse.h"

int** pzData;								// ���ق�ID�i�[�p
int blankID;								// �������ق�ID
Pos chipSize;								// ���ق̕�����

int pzlImageID[PZL_SEL_MAX];


// �ړ����ق̐���p
int moveID;									// �ړ���������ID
Pos movePanelPos;							// �ړ��������ٍ��W
Pos moveEndPos;								// �ړ��������ُI�����W
int moveSpeed;								// �ړ��������ق̽�߰��
int moveSpeedTable[] = {16,8,8,4,2};		// �������ɉ��������x

DIR dir;

ReplayData* ReplayList;				// ���ڲ�ް�ؽĂ̐擪
ReplayData* ptrReplay ;				// ���݂����ڲ�ް�ؽĂ̱����ʒu

bool reFlag;								// ���ڲ�̏��

int randSeed;
bool suffleFlag;


bool GameInit(bool replay)
{
	bool rtnFlag = true;

	if (!replay)
	{
		FreeMemData();
	}
	// �����p
	if (divID >= (sizeof(divTable) / sizeof(divTable[0])) || (divID < 0))
	{
		// divID���ُ�Ȓl�̏ꍇ�O��ݒ肷��
		divID = 0;
	}
	
	if (!reFlag)
	{
		pzData = (int**)malloc(sizeof(int*) * divTable[divID]);
		if (pzData == NULL)
		{
			//���s���Ă���ꍇ
			return false;
		}
	}

	/*for (int y = 0; y < divTable[divID]; y++)
	{

		pzData[y] = (int*)malloc(sizeof(int) * divTable[divID]);

		if (pzData[y] == NULL)
		{
			return false;
		}
	}

	for (int y = 0; y < divTable[divID]; y++)
	{
		for (int x = 0; x < ; x++)
		{
			pzData[y][x] = y + x * divTable[divID];
		}
	}

	int* pzData = (int*)malloc(sizeof(int) * divTable[divID] * divTable[divID]);

	int* data = (int*)malloc(sizeof(int) * divTable[divID] * divTable[divID]);

	if (pzData == NULL)
	{
		return false;
	}
	if (data == NULL)
	{
		return false;
	}

	for (int s = 0; s < divTable[divID]; s++)
	{
		for (int i = 0; i < divTable[divID]; i++)
		{
			pzData(s * divTable[divID] + i) = s * divTable[divID] + i;
		}
	}*/

	
	if (!reFlag)
	{
		for (int y = 0; y < divTable[divID]; y++)
		{
			pzData[y] = (int*)malloc(sizeof(int) * divTable[divID] * divTable[divID]);
		}
		/*for (int y = 1; y < divTable[divID]; y++)
		{
			for (int x = 1; x < divTable[divID]; x++)
			{
				pzData[0] = pzData[0] + divTable[divID] * y;
			}
		}*/

		for (int y = 0; y < divTable[divID]; y++)
		{
			for (int x = 0; x < divTable[divID]; x++)
			{
				pzData[y][x] = y * divTable[divID] + x;
			}
		}
	}
	chipSize.x = P_SIZE_X / divTable[divID];
	chipSize.y = P_SIZE_Y / divTable[divID];

	dir = DIR_MAX;
	// ������
	movePanelPos.x = 0;
	movePanelPos.y = 0;
	moveEndPos.x = 0;
	moveEndPos.y = 0;
	moveID = NON_ID;
	moveSpeed = moveSpeedTable[divID];
	reFlag = replay;
	
	ptrReplay = ReplayList;		// 
	if (!reFlag)
	{
		randSeed = (unsigned int)time(NULL);
	}
	srand(randSeed);
	blankID = rand() % (divTable[divID] * divTable[divID]);

	
	suffleFlag = false;
		do
		{
			ShafullPanel();

		} while (IsClear());
	suffleFlag = true;

		
	func = GameScene;
	

	return rtnFlag;
}

// ��؂̊J��
void FreeMemData(void)
{
	// �z��̎�������
	if (pzData != NULL)
	{
		for (int y = 0; y < divTable[divID]; y++)
		{
			free(pzData[y]);
		}
	}
	free(pzData);
	pzData = NULL;

	ptrReplay = ReplayList;		// ptr��擪�Ɏ����Ă���

	if (ptrReplay != NULL)
	{
		while (ReplayList != NULL)
		{
			ptrReplay = ReplayList;
			ReplayList = ptrReplay->next;
			free(ptrReplay);
		}
	}
	ReplayList = NULL;
	ptrReplay = NULL;
}

// �ر
bool IsClear(void)
{
	for (int y = 0; y < divTable[divID]; y++)
	{
		for (int x = 0; x < divTable[divID]; x++)
		{
			if (pzData[y][x] != y * divTable[divID] + x)
			{
				return false;
			}
		}
	}
	return true;
}

void ShafullPanel(void)
{
	// �^���د��𐶐�
	mouseF.trg[TRG_NOW] = MOUSE_INPUT_LEFT;
	mouseF.trg[TRG_OLD] = 0;

		mouseF.pos.x = (blankID % divTable[divID]) * chipSize.x;
		mouseF.pos.y = (blankID / divTable[divID]) * chipSize.y;

		for (int i = 0; i < 10000; i++)
		{
			switch (rand() % DIR_MAX)
			{
			case DIR_LEFT:
				mouseF.pos.x = (mouseF.pos.x - chipSize.x) >= 0 ? (mouseF.pos.x - chipSize.x) : mouseF.pos.x;
				break;
			case DIR_RIGHT:
				mouseF.pos.x = (mouseF.pos.x + chipSize.x) <= P_SIZE_X ? (mouseF.pos.x + chipSize.x) : mouseF.pos.x;
				break;
			case DIR_UP:
				mouseF.pos.y = (mouseF.pos.y - chipSize.y) >= 0 ? (mouseF.pos.y - chipSize.y) : mouseF.pos.y;
				break;
			case DIR_DOWN:
				mouseF.pos.y = (mouseF.pos.y + chipSize.y) <= P_SIZE_Y ? (mouseF.pos.y + chipSize.y) : mouseF.pos.y;
				break;
			default:
				break;
			}
			PanelCtl();
			movePanelPos.x = moveEndPos.x;
			movePanelPos.y = moveEndPos.y;
		}
	
	
	mouseF.trg[TRG_NOW] = 0;
	
}

bool GameScene(void)
{
	MoveSwap();
	PanelCtl();
	if (IsClear())
	{
		ClearInit();
	}
	GameDraw();
	
	return false;
}

void GameDraw(void)
{
	ClsDrawScreen();

	// �����̕\��
	DrawRotaGraph(SCREEN_SIZE_X - P_SIZE_X / 2, P_SIZE_Y / 2, 0.5f, 0.0f, puzzleImage[PZL_SEL_NOW], true, false);

	// 1���ߕ��������
	for (int y = 0; y < divTable[divID]; y++)
	{
		for (int x = 0; x < divTable[divID]; x++)
		{
			if (blankID != pzData[y][x] && moveID != pzData[y][x])
			{
				DrawRectGraph(chipSize.x * x, chipSize.y * y,
							  chipSize.x * (pzData[y][x] % divTable[divID]),
							  chipSize.y * (pzData[y][x] / divTable[divID]),
							  chipSize.x, chipSize.y,
							  puzzleImage[PZL_SEL_NOW], false, false);
			}
		}
	}

	DrawDivLine();

	// moveID�����ق̕`��
	if (moveID != NON_ID)
	{
		DrawRectGraph(movePanelPos.x, movePanelPos.y, 
					  chipSize.x * (moveID % divTable[divID]), 
					  chipSize.y * (moveID / divTable[divID]), 
					  chipSize.x, chipSize.y, 
					  puzzleImage[PZL_SEL_NOW], false, false);
	}

	if (movePanelPos.x == moveEndPos.x && movePanelPos.y == moveEndPos.y)
	{
		moveID = NON_ID;
	}

	ScreenFlip();
}

void DrawDivLine(void)
{
	// �������̐�
	for (int y = 0; y < divTable[divID] + 1; y++)
	{
		DrawLine(y * P_SIZE_X / divTable[divID], 0, y * P_SIZE_X / divTable[divID], P_SIZE_Y,
			GetColor(255, 0, 255));

		DrawLine(0, y * P_SIZE_Y / divTable[divID], P_SIZE_X, y * P_SIZE_Y / divTable[divID],
			GetColor(255, 0, 255));
	}
}

// ���وړ�(����ւ�)����
void PanelCtl(void)
{
	Pos tmpPos;
	if (moveID == NON_ID)
	{
	if (reFlag && suffleFlag)
	{
		tmpPos.x = ptrReplay->pos.x / chipSize.x;
		tmpPos.y = ptrReplay->pos.y / chipSize.y;
		ptrReplay = ptrReplay->next;
		mouseF.trg[TRG_NOW] = 1;
		mouseF.trg[TRG_OLD] = 0;
	}
	else
	{
		tmpPos.x = (mouseF.pos.x / chipSize.x);
		tmpPos.y = (mouseF.pos.y / chipSize.y);
	}
	
		if (((mouseF.trg[TRG_NOW] & (~mouseF.trg[TRG_OLD])) & MOUSE_INPUT_LEFT) != 0)
		{
			for (DIR dir = DIR_LEFT; dir < DIR_MAX; dir = (DIR)(dir + 1))
			{
				if (SetMovePanel(tmpPos, dir))
				{
					if (!reFlag)
					{
						if (suffleFlag)
						{
							Replay();
							break;
						}
					}
				}
			}
		}
	}
}

// ���ڲ�p
void Replay(void)
{
	if (!reFlag)
	{
		if (ReplayList != NULL)
		{
			// 2���
			ptrReplay->next = (ReplayData*)malloc(sizeof(ReplayData));
			ptrReplay = ptrReplay->next;
			ptrReplay->next = NULL;
		}
		else
		{
			// 1���
			ptrReplay = (ReplayData*)malloc(sizeof(ReplayData));
			ReplayList = ptrReplay;
			ptrReplay->next = NULL;
		}
		ptrReplay->pos.x = mouseF.pos.x;
		ptrReplay->pos.y = mouseF.pos.y;
	}
}

// ���ق̓����������������ݸ������΂��������A����Έړ���Ă���
bool SetMovePanel(Pos panel, DIR moveDir)
{
	// �����p
	if (panel.x < 0 ||
		panel.x >= divTable[divID] ||
		panel.y < 0 ||
		panel.y >= divTable[divID])
	{
		// ���يO��د����Ă���΁A��������������
		return false;
	}

	Pos nextPanel = panel;

	switch (moveDir)
	{
	case DIR_LEFT:
		nextPanel.x--;
		break;
	case DIR_RIGHT:
		nextPanel.x++;
		break;
	case DIR_UP:
		nextPanel.y--;
		break;
	case DIR_DOWN:
		nextPanel.y++;
		break;
	default:
		AST();
		break;
	}

	if (nextPanel.x < 0 ||
		nextPanel.x >= divTable[divID] ||
		nextPanel.y < 0 ||
		nextPanel.y >= divTable[divID])
	{
		// �ړ��悪�͈͊O���w���Ă���΁A��������������
		return false;
	}

	if (pzData[nextPanel.y][nextPanel.x] != blankID)
	{
		return false;
	}

	//
	moveID = pzData[panel.y][panel.x];
	movePanelPos.x = panel.x * chipSize.x;
	movePanelPos.y = panel.y * chipSize.y;
	moveEndPos.x = nextPanel.x * chipSize.x;
	moveEndPos.y = nextPanel.y * chipSize.y;


	/*if (movePanelPos.x < 0 ||
		movePanelPos.x >= moveSpeedTable[moveSpeed] ||
		movePanelPos.y < 0 ||
		movePanelPos.y >= moveSpeedTable[moveSpeed])
	{
		return;
	}
	if (!moveID)
	{
		movePanelPos = moveEndPos;
		moveID = NON_ID;
	}*/


	SwapNum(&pzData[nextPanel.y][nextPanel.x], &pzData[panel.y][panel.x]);
	
	return true;
}

// �n���ꂽ�Q�̗v�f�������ւ���
void SwapNum(int* num1,int* num2)
{
	int tmpNum = *num1;
	*num1 = *num2;
	*num2 = tmpNum;
}

// �ړ����ق̐���
void MoveSwap(void)
{
	/*if (moveID == NON_ID)
	{
		return true;
	}*/

	if (moveEndPos.x < movePanelPos.x)
	{
		movePanelPos.x -= moveSpeed;
	}
	if (moveEndPos.x > movePanelPos.x)
	{
		movePanelPos.x += moveSpeed;
	}
	if (moveEndPos.y < movePanelPos.y)
	{
		movePanelPos.y -= moveSpeed;
	}
	if (moveEndPos.y > movePanelPos.y)
	{
		movePanelPos.y += moveSpeed;
	}
	if (movePanelPos.x == moveEndPos.x && movePanelPos.y == moveEndPos.y)
	{
		moveID = NON_ID;
	}
	/*if (movePanelPos.x > moveID)
	{
		movePanelPos.x += moveSpeed;
	}

	if (movePanelPos.x == moveEndPos.x && movePanelPos.y == moveEndPos.y)
	{
		moveID = NON_ID;
	}*/


	/*switch (dir)
	{
	case DIR_LEFT:
		movePanelPos.x -= moveSpeed;
		break;
	case DIR_RIGHT:
		movePanelPos.x += moveSpeed;
		break;
	case DIR_UP:
		movePanelPos.y -= moveSpeed;
		break;
	case DIR_DOWN:
		movePanelPos.y += moveSpeed;
		break;
	default:
		AST();
		break;
	}*/
}


