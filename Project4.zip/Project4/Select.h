#pragma once

enum PZL_IMAGE
{
	PZL_SEL_NOW,
	PZL_SEL_OLD,
	PZL_SEL_MAX
};


// �������ߐ錾
bool SelectInit(void);

bool SelectScene(void);

void SelectDraw(void);

void DrawButton(void);

bool OnClickCircle(Pos btnPos, int rad, int hitRad);

extern int selScreen[PZL_SEL_MAX];			// �Z���N�g�p
extern int selPzScreen;

extern int selPanelMove;