#include <math.h>
#include "DxLib.h"
#include "main.h"
#include "Select.h"
#include "Game.h"
#include "Mouse.h"

int selScreen[PZL_SEL_MAX];			// �Z���N�g�p
int selPzScreen;

int selPanelMove;

bool SelectInit(void)
{
	bool rtnFlag = true;

	bPos.x = SCREEN_SIZE_X / 2 + SCREEN_SIZE_X / 6;
	bPos.y = SCREEN_SIZE_Y / 2 + 20;
	bFlag = 0;

	func = SelectScene;
	//scnID = SCN_ID_SELECT;

	for (int s = 0; s < PZL_SEL_MAX; s++)
	{
		selScreen[s] = MakeScreen(P_SIZE_X, P_SIZE_Y, true);
		pzlImageID[s] = 0;
	}

	selPzScreen = MakeScreen(P_SIZE_X, P_SIZE_Y, true);
	selPanelMove = 0;
	return rtnFlag;
}

bool SelectScene(void)
{
	
	if (OnClickCircle(bPos, B_SIZE_X / 2, B_HIT_SIZE))
	{
		GameInit(false);
		DeleteGraph(selScreen[0]);
		DeleteGraph(selScreen[0]);
		DeleteGraph(selPzScreen);
	}
	
	if (selPanelMove != 0)
	{
		if (selScreen)
		{
			selPanelMove += 5;
			pzlImageID[0] = selPanelMove;
			pzlImageID[1] = selPanelMove;
			
		}
	}

	if (mouseF.pos.x < P_SIZE_X)
	{
		// ϳ��̍����������Ƃ�
		if (((mouseF.trg[TRG_NOW] & (~mouseF.trg[TRG_OLD])) & MOUSE_INPUT_LEFT) != 0)
		{
			if (divID < (sizeof(divTable) / sizeof(divTable[0])) - 1)
			{
				divID++;
			}
		}
		// ϳ��̉E���������Ƃ�
		if (((mouseF.trg[TRG_NOW] & (~mouseF.trg[TRG_OLD])) & MOUSE_INPUT_RIGHT) != 0)
		{
			if (selPanelMove == 0)
			{
				selPanelMove = - P_SIZE_X;
				pzlImageID[0] = selPanelMove;
				pzlImageID[1] = selPanelMove + P_SIZE_X;
			}
		}
	}
	if (CheckHitKey(MOUSE_INPUT_MIDDLE))
	{

	}
	DrawButton();

	SelectDraw();
	return false;
}

void SelectDraw(void)
{
	//	�I�𒆂̉摜�ƕ�������Ăɂ����摜�����
	SetDrawScreen(selScreen[PZL_SEL_NOW]);
	ClsDrawScreen();
	DrawGraph(0, 0, puzzleImage[PZL_IMAGE_MAX], false);
	DrawDivLine();

	if (selPanelMove != 0)
	{
		SetDrawScreen(selScreen[PZL_SEL_OLD]);
		ClsDrawScreen();
		DrawGraph(0, 0, puzzleImage[pzlImageID[PZL_SEL_OLD]], false);
		DrawDivLine();
	}
	
	SetDrawScreen(selPzScreen);
	ClsDrawScreen();
	DrawGraph(selPanelMove, 0, selScreen[PZL_SEL_NOW], false);
	if (selPanelMove != 0)
	{
		DrawGraph(selPanelMove + P_SIZE_X, 0, selScreen[PZL_SEL_OLD], false);
	}

	// ����
	SetDrawScreen(DX_SCREEN_BACK);
	ClsDrawScreen();
	DrawGraph(0, 0, selPzScreen, false);
	DrawButton();
	ScreenFlip();

	//DrawGraph(0, 0, puzzleImage[PZL_IMAGE_MAX], true);

	//DrawRectGraph(bPos.x, bPos.y, B_SIZE_X * bFlag, 0, B_SIZE_X, B_SIZE_Y, bImage, true, false);

	//DrawString(360, 10, "���N���b�N�ŕ������𑝂₷", GetColor(255, 255, 255));
	//DrawString(360, 30, "�E�N���b�N�ŕ����������炷", GetColor(255, 255, 255));
	// �������̐�
	/*for (int y = 0; y < divTable[divID] + 1; y++)
	{
		DrawLine(y * P_SIZE_X / divTable[divID], 0, y * P_SIZE_X / divTable[divID], P_SIZE_Y,
				 GetColor(255, 0, 255));

		DrawLine(0, y * P_SIZE_Y / divTable[divID], P_SIZE_X, y * P_SIZE_Y / divTable[divID],
				 GetColor(255, 0, 255));
	}*/
}

// 
void DrawButton(void)
{
	DrawRectGraph(bPos.x, bPos.y, B_SIZE_X * bFlag, 0, B_SIZE_X, B_SIZE_Y, bImage, true, false);

}

// ���݉��������֐�(�~����A�����F���S���W�A���ݔ���A�����蔻��p)
bool OnClickCircle(Pos btnPos,int rad,int hitRad)
{
	int x_len = ((btnPos.x + rad) - mouseF.pos.x);
	int y_len = ((btnPos.y + rad) - mouseF.pos.y);
	int mouse_len = (x_len * x_len) + (y_len * y_len);

	int bCnt = 0;

	/*if (((bPos.x + B_SIZE_X / 2) - mouseF.pos.x) * ((bPos.x + B_SIZE_X / 2) - mouseF.pos.x)
	+ ((bPos.y + B_SIZE_Y / 2) - mouseF.pos.y) * ((bPos.y + B_SIZE_Y / 2) - mouseF.pos.y)
	< (B_SIZE_X / 2 * B_SIZE_X / 2))*/

	if (((mouseF.trg[TRG_NOW] & (~mouseF.trg[TRG_OLD])) & MOUSE_INPUT_LEFT) != 0)
	{
		if (mouse_len <= hitRad * hitRad)
		{
			bFlag = B_ON;
		}
	}
	if (((mouseF.trg[TRG_OLD] & (~mouseF.trg[TRG_NOW])) & MOUSE_INPUT_LEFT) != 0)
	{
		if (mouse_len < hitRad * hitRad && bFlag == B_ON)
		{
			bFlag = B_OFF;
			return true;
		}
		bFlag = B_OFF;
	}
	
	return false;

}