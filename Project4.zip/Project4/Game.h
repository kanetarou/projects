#pragma once
#include "Select.h"

#define NON_ID (- 1)

// ����
enum DIR
{
	DIR_LEFT,
	DIR_RIGHT,
	DIR_UP,
	DIR_DOWN,
	DIR_MAX,
};


// �������ߐ錾
bool GameInit(bool replay);

bool GameScene(void);

void GameDraw(void);

void DrawDivLine(void);

void PanelCtl(void);

bool SetMovePanel(Pos panel, DIR moveDir);

void SwapNum(int *num1, int *num2);

void MoveSwap(void);


void ShafullPanel(void);

bool IsClear(void);

void Replay(void);

void FreeMemData(void);


extern int pzlImageID[PZL_SEL_MAX];
extern ReplayData* ReplayList;
extern ReplayData* ptrReplay;