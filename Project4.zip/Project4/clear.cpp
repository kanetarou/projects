#include "DxLib.h"
#include "main.h"
#include "Game.h"
#include "Select.h"
#include "clear.h"

bool ClearInit(void)
{
	bool rtnFlag = true;

	func = ClearScene;
	//scnID = SCN_ID_CLEAR;

	return rtnFlag;
}
bool ClearScene(void)
{
	if (OnClickCircle(bPos, B_SIZE_X / 2, B_HIT_SIZE))
	{
		SelectInit();
	}
	if (CheckHitKey(KEY_INPUT_SPACE))
	{
		GameInit(true);
	}
	DrawButton();
	ClearDraw();
	return false;
}

void ClearDraw(void)
{
	ClsDrawScreen();
	DrawGraph(0, 0, puzzleImage[PZL_SEL_MAX], true);
	DrawButton();
	ScreenFlip();
}