#include <Windows.h>
#include <DxLib.h>
#include <cmath>
#include "GameCommon.h"
#include "CountDown.h"

CountDown::CountDown()
{
}

CountDown::~CountDown()
{
}


void CountDown::Start(float sec)
{
	//���ݎ�������
	mTickCnt = GetTickCount64();

	mEndTime = sec * 1000.0f;

	//Start�Ȃ̂ŏ�Ԃ��J�E���g�_�E���ɂ��Ă���
	mState = STATE::COUNT_DOWN;
}

bool CountDown::IsEnd()
{
	switch (mState)
	{
	case CountDown::STATE::NONE:
	case CountDown::STATE::END:
		return true;
	}
	return false;
}

void CountDown::Update()
{
	float tickCount;
	//float deltaTime;

	switch (mState)
	{
	case CountDown::STATE::NONE:
		break;
	case CountDown::STATE::COUNT_DOWN:
		//���ݎ�������
		tickCount = GetTickCount64();

		//���ݎ����@-�@�O��̃t���[�������@=�@�o�ߎ���
		mDeltaTime = (tickCount - mTickCnt);

		//�I�����Ԃ���o�ߎ��Ԃ�����
		mEndTime -= mDeltaTime;
		if (mEndTime < 0)
		{
			int cnt = 0;
			if (mState == STATE::COUNT_DOWN)
			{
				mState = STATE::START;
				mEndTime = SEC_SHOW_START * 1000.0f;
				
				cnt++;
			}
			if (mState == STATE::START && cnt < 30)
			{
				mState = STATE::END;
			}
		}

		//���̃t���[���Ɏ������X�V
		mTickCnt = tickCount;
		break;
	case CountDown::STATE::START:
		break;
	case CountDown::STATE::END:
		break;
	default:
		break;
	}

	
}

void CountDown::Render()
{
	//�e�X�g�p
	//DrawFormatString(0, 0, 0x000000, "%f", mDeltaTime);
	int sec;
	int len;
	int width;
	switch (mState)
	{
	case CountDown::STATE::NONE:
		break;
	case CountDown::STATE::COUNT_DOWN:
	{
		SetFontSize(96);
		sec = ceilf(mEndTime / 1000.0f);
		DrawFormatString(SCREEN_SIZE_X / 2, (SCREEN_SIZE_Y / 2) - 200, 0x000000, "%d", sec);
		
		break;
	}
	case CountDown::STATE::START:
	{
		SetFontSize(96);
		len = strlen(MSG_START);
		width = GetDrawStringWidth(MSG_START, len);
		DrawFormatString((SCREEN_SIZE_X / 2) - (width / 2), (SCREEN_SIZE_Y / 2) - 200, 0x000000, "%s", MSG_START);
		break;
	}
	case CountDown::STATE::END:
		break;
	default:
		break;
	}
}
