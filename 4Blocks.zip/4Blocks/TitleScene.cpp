#include "DxLib.h"
#include "KeyCheck.h"
#include "SceneManager.h"
#include "BlockData.h"
#include "GameCommon.h"
#include <string>
#include <iostream>
#include "TitleScene.h"

void TitleScene::Test()
{
	DrawFormatString(0, 0, 0x000000, "�ʏ�ϐ�");
	int height = 15;
	int posY = 0;
	int tmp;
	SetFontSize(16);

	//�ʏ�ϐ�
	int mPow =30;
	int mSpeed=17;
	posY += height;
	DrawFormatString(0, posY, 0x000000, "%d", mPow);
	//�|�C���^��\��
	posY += height;
	DrawFormatString(0, posY, 0x000000, "%p", &mPow);

	posY += height;
	DrawFormatString(0, posY, 0x000000, "%d", mSpeed);
	posY += height;
	DrawFormatString(0, posY, 0x000000, "%p", &mSpeed);

	//�|�C���^�ϐ�
	posY += height*2;
	DrawFormatString(0, posY, 0x000000, "�|�C���^�ϐ�");
	int* mPowPtr;
	int* mSpdPtr;

	mPowPtr = &mPow;
	mSpdPtr = &mSpeed;

	posY += height;
	DrawFormatString(0, posY, 0x000000, "%p",mPowPtr);
	posY += height;
	DrawFormatString(0, posY, 0x000000, "%d", *mPowPtr);

	posY += height;
	DrawFormatString(0, posY, 0x000000, "%p", mSpdPtr);
	posY += height;
	DrawFormatString(0, posY, 0x000000, "%d", *mSpdPtr);

	//
	BlockData* block = mSceneManager->GetBlockData();

	//�u���b�N�̌`����擾
	BlockData::Shape shape = 
		block->GetData(BlockData::TYPE::BLOCK_TYPE_I, BlockData::ROT::R000);
	posY += height;
	for (int y = 0; y <= BLOCK_MAP_Y-1; y++)
	{
		posY += height;
		for (int x = 0; x <= BLOCK_MAP_X-1; x++)
		{
			DrawFormatString(x * height, posY, 0x000000, "%d", shape.data[y][x]);
		}
	}
	posY += (height*4);
	//�z��ƃ|�C���^�̊�b
	int mMap[5];
	mMap[2] = 1;
	for (int x = 0; x < 5; x++)
	{
		posY += height;
		DrawFormatString(0, posY, 0x000000, "%p", &mMap[x]);
		
	}
	int* mMapPtr = &mMap[0];
	posY += (height * 2);
	DrawFormatString(0, posY, 0x000000, "%p", mMapPtr);
	mMapPtr++;
	posY += (height * 2);
	DrawFormatString(0, posY, 0x000000, "%p", mMapPtr);

	//�u���b�N�`����|�C���^�ŕ\��
	int* ptr = shape.data[0];
	posY += (height * 2);
	DrawFormatString(0, posY, 0x000000, "�u���b�N�̐擪�|�C���^�F%p", ptr);
	std::system("cls");
	for (int y = 0; y < BLOCK_MAP_Y; y++)
	{
		for (int x = 0; x < BLOCK_MAP_X; x++)
		{
			std::cout << ptr << std::endl;
			ptr++;
		}
	}
	//�|�C���^������g���u���b�N����\��
	int* tpr2 = shape.data[0];
	posY += (height * 2);
	
	for (int x = 0; x < BLOCK_MAP_Y * BLOCK_MAP_X; x++)
	{
		DrawFormatString(x * height, posY, 0x000000, "%d", *tpr2);
		tpr2++;
	}


	//
	block->TestStudy(posY);
}

TitleScene::TitleScene(SceneManager* manager) : SceneBase(manager)
{

}

void TitleScene::Init(void)
{
	//�^�C�g���摜�̓ǂݍ���
	mImage = LoadGraph("Image/Title.png");
}

void TitleScene::Update(void)
{

	if (keyTrgDown[KEY_SYS_START])
	{
		mSceneManager->ChangeScene(SCENE_ID::MANUAL, true);
	}

}

void TitleScene::Draw(void)
{
	SetDrawScreen(DX_SCREEN_BACK);
	ClearDrawScreen();
	
	// �^�C�g���摜�̕`��
	DrawGraph(0, 0, mImage, true);
	//Test();
}

void TitleScene::Release(void)
{
	// �摜�̊J��
	DeleteGraph(mImage);
}
