#pragma once
class CountDown
{
public:

	static constexpr float SEC_SHOW_START = 1.0f;
	static constexpr char* MSG_START = (char*)"START!";

	enum class STATE
	{
		NONE,
		COUNT_DOWN,
		START,
		END
	};

	CountDown();
	~CountDown();

	void Update();
	void Render();

	void Start(float sec);

	//�I������
	bool IsEnd();
private:
	//�O�t���[���̎���
	float mTickCnt;

	//�o�ߎ���
	float mDeltaTime;

	float mEndTime;

	STATE mState;
};

