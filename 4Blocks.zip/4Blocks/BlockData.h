#pragma once
#include "GameCommon.h"
class BlockData
{
public:
	//�u���b�N�̎��
	enum class TYPE
	{
		BLOCK_TYPE_I,
		BLOCK_TYPE_O,
		BLOCK_TYPE_S,
		BLOCK_TYPE_Z,
		BLOCK_TYPE_J,
		BLOCK_TYPE_L,
		BLOCK_TYPE_T,
		BLOCK_TYPE_B,
		BLOCK_TYPE_MAX,
	};
	//�u���b�N�̉�]
	enum class ROT
	{
		R000,
		R090,
		R180,
		R270,
		RMAX,
	};

	//�u���b�N�̌`��
	struct Shape
	{
		int data[BLOCK_MAP_Y][BLOCK_MAP_X];
	};
	void Init();

	Shape GetData(TYPE type, ROT rot);


	void Render();

	//�e�X�g�p
	void TestStudy(int posY);
private:
	Shape mData[BLOCK_TYPE_NUM][BLOCK_ROT_NUM];
};

