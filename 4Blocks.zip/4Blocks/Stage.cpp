#include <DxLib.h>
#include "ActiveBlock.h"
#include "Stage.h"

Stage::Stage()
{
	for (int y = 0; y < MAX_MAP_NUM_Y; y++)
	{
		for (int x = 0; x < MAX_MAP_NUM_X; x++)
		{
			mMap[y][x] = 0;
		}
	}
	//activeBlock = new ActiveBlock();
	//Init(activeBlock);
}

Stage::~Stage()
{

}

void Stage::Init(ActiveBlock* acBlock)
{
	//block
	endBlockImg = LoadGraph("Image/Blocks/Glay.png");
	mScore = 0; 

	mGameOver = false;

	mCntEffect = 0;

	activeBlock = acBlock;

	cnt = 0;
}

void Stage::Updata()
{
	if (IsEffecting())
	{
		mCntEffect++;
		if (mCntEffect > CNT_EFFECT)
		{
			//�L�������s�����Ƃɍ폜����
			int tmpScore = 0;
			for (int i = 0; i < mCntErace; i++)
			{
				tmpScore = SCORES[i];
				EraceLine(mEraceLine[i]);
			}

			//�X�R�A���Z
			mScore += tmpScore;
			DrawFormatString(0, 0, 0x000000, " + %d", mScore);
			

			//�x���J�E���^��������
			mCntEffect = 0;

			//�폜�Ώۂ̏���������
			mCntErace = 0;
			for(int i = 0; i< 4; i++)
			{
				mEraceLine[i] = -1;
			}
			//����u���b�N�����̃u���b�N�ɕς���
			activeBlock->ChangeNext();
		}
	}
	
}

void Stage::Render()
{
	DrawBox(GAME_AREA_X, GAME_AREA_Y, GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE, GAME_AREA_Y + MAX_MAP_NUM_Y * BLOCK_IMG_SIZE, GetColor(255, 255, 255), true);
	//����̘g
	DrawBox(GAME_AREA_X, GAME_AREA_Y, GAME_AREA_X - 10, GAME_AREA_Y + MAX_MAP_NUM_Y * BLOCK_IMG_SIZE, GetColor(200, 100, 150), true);
	DrawBox(GAME_AREA_X - 10, GAME_AREA_Y, GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 10, GAME_AREA_Y - 10, GetColor(200, 100, 150), true);
	DrawBox(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE, GAME_AREA_Y, GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 10, GAME_AREA_Y + MAX_MAP_NUM_Y * BLOCK_IMG_SIZE, GetColor(200, 100, 150), true);
	DrawBox(GAME_AREA_X - 10, GAME_AREA_Y + MAX_MAP_NUM_Y * BLOCK_IMG_SIZE, GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 10, GAME_AREA_Y + MAX_MAP_NUM_Y * BLOCK_IMG_SIZE + 10, GetColor(200, 100, 150), true);
	////�c��
	for (int x = GAME_AREA_X; x < GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 1; x += BLOCK_IMG_SIZE)
	{
		DrawLine(x, GAME_AREA_Y, x, GAME_AREA_Y + MAX_MAP_NUM_Y * BLOCK_IMG_SIZE, GetColor(0, 0, 0), true);
	}
	DrawLine(GAME_AREA_X, GAME_AREA_Y, GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE, GAME_AREA_Y, GetColor(0, 0, 0), true);
	DrawLine(GAME_AREA_X, GAME_AREA_Y + MAX_MAP_NUM_Y * BLOCK_IMG_SIZE, GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE, GAME_AREA_Y + MAX_MAP_NUM_Y * BLOCK_IMG_SIZE, GetColor(0, 0, 0), true);
	//score
	//DrawBox(10, 30, 370, 80, GetColor(0, 0, 0), true);

	//nextBlock
	//DrawBox(400,150,500,250, GetColor(100, 100, 100), true);

	//�蒅�u���b�N�̕\��

	/*for (int y = 0; y < MAX_MAP_NUM_Y; y++)
	{
		for (int x = 0; x < MAX_MAP_NUM_X; x++)
		{
			mMap[5][5] = 1;
		}
	}
	/*for (int y = 1; y < MAX_MAP_NUM_Y; y += 2)
	{
		for (int x = 1; x < MAX_MAP_NUM_X; x += 2)
		{
			mMap[y][x] = 1;
		}
	}*/
	for (int y = 0; y < MAX_MAP_NUM_Y; y++)
	{
		if (IsEffecting() == true)
		{
			for (int i = 0; i < mCntErace; i++)
			{
				if (y == mEraceLine[i])
				{
					if (mCntEffect < (CNT_EFFECT/5))
					{
						DrawBox(GAME_AREA_X,
							GAME_AREA_Y + (y * BLOCK_IMG_SIZE),
							GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE,
							GAME_AREA_Y + (y * BLOCK_IMG_SIZE) + BLOCK_IMG_SIZE,
							0xe6e600, true);
						//������
						SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
					}
					else
					{
						int alpha = (255 / (CNT_EFFECT - (CNT_EFFECT / 5)))*mCntEffect;
						//���Ƃɖ߂�
						SetDrawBlendMode(DX_BLENDMODE_ALPHA, 255- alpha);
					}
					
				}
			}
		}
		for (int x = 0; x < MAX_MAP_NUM_X; x++)
		{
			if (mMap[y][x] == 1)
			{
				DrawGraph(GAME_AREA_X + (x * BLOCK_IMG_SIZE), GAME_AREA_Y + (y * BLOCK_IMG_SIZE), endBlockImg, true);
			}
		}
		
	}

	
	//�Q�[���I�[�o�[��
	if (mGameOver)
	{
		//cnt++;
		if (cnt < MAX_MAP_NUM_Y+1)
		{
			cnt++;
		}
		for (int i = MAX_MAP_NUM_Y; i > MAX_MAP_NUM_Y - cnt; i--)
		{
			for (int j = 0; j < MAX_MAP_NUM_X; j++)
			{

				//�Q�[�����̒蒅�u���b�N�̍폜
				//DeleteGraph(endBlockImg);	

				//�Q�[���I�[�o�[���̒蒅�u���b�N�\��
				DrawGraph(GAME_AREA_X + (j * BLOCK_IMG_SIZE), GAME_AREA_Y + i * BLOCK_IMG_SIZE, endBlockImg, true);
			}
		}
	}
	DrawScore();
	DrawFormatString(0, 0, 0xffffff, "cnt= %d", cnt);
	int scCnt = 0;
	if (mScore < 500)
	{
		DrawString(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 60, GAME_AREA_Y + 130, "LEVEL 1", 0x000000, true);
		DrawFormatString(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 20, GAME_AREA_Y + 160, 0x000000, "LEVEL UP�܂�\n���� %d", 500- mScore);
	}
	else if (mScore >= 500 && mScore < 1000)
	{
		DrawString(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 60, GAME_AREA_Y + 130, "LEVEL 2", 0x000000, true);
		DrawFormatString(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 20, GAME_AREA_Y + 160, 0x000000, "LEVEL UP�܂�\n���� %d", 1000 - mScore);
	}
	else if (mScore >= 1000 && mScore < 1500)
	{
		DrawString(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 60, GAME_AREA_Y + 130, "LEVEL 3", 0x000000, true);
		DrawFormatString(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 20, GAME_AREA_Y + 160, 0x000000, "LEVEL UP�܂�\n���� %d", 1500 - mScore);
	}
}

void Stage::DrawScore()
{
	DrawBox(10, 10, 300, 50, 0x000000, false);
	DrawBox(11, 11, 299, 49, 0xff0000, true);
	SetFontSize(18);
	DrawFormatString(160, 25, 0xffffff, "SCORE : %d", mScore);
	
}

void Stage::Release()
{
}

int Stage::GetData(int x, int y)
{
	return mMap[y][x];
}

void Stage::SetBlock(Vector2 blockMapPos, BlockData::Shape shape)
{
	int mapX = 0;
	int mapY = 0;
	
	//mMap�ɑ���u���b�N�̏�����������
	for (int i = 0; i < BLOCK_MAP_Y; i++)
	{
		for (int j = 0; j < BLOCK_MAP_X; j++)
		{
			mapX = blockMapPos.x + j;
			mapY = blockMapPos.y + i;

			//�蒅�u���b�N�ɂ���
			if (shape.data[i][j] == 1)
			{
				mMap[mapY][mapX] = 1;
			}
			if (mapY == 0)
			{
				mGameOver = true;
			}
		}
	}
	//DrawFormatString(0, 0, 0xffffff, "cnt= %d", cnt);
}

bool Stage::IsGameOver()
{
	return mGameOver;
}

bool Stage::IsEffecting()
{
	return 0 < mCntErace;
}



void Stage::CheckErace()
{
	for (int i = 0; i < 4; i++)
	{
		mEraceLine[i] = -1;
	}
	mCntErace = 0;

	int lineX = 0;
	//���C��(�s)���P�s���`�F�b�N
	for (int i = 0; i < MAX_MAP_NUM_Y; i++)
	{
		lineX = 0;
		for (int j = 0; j < MAX_MAP_NUM_X; j++)
		{
			//�s���������烉�C��������
			if (mMap[i][j] == 1)
			{
				lineX++;
			}
		}
		if (lineX >= MAX_MAP_NUM_X)
		{
			mEraceLine[mCntErace] = i;
			mCntErace++;
			
		}
	}

	//�L�������s�����Ƃɍ폜����
	//int tmpScore = 0;
	//for (int i = 0; i < mCntErace; i++)
	//{
	//	tmpScore = SCORES[i];
	//	EraceLine(mEraceLine[i]);
	//}

	////�X�R�A���Z
	//mScore += tmpScore;
	
}

int Stage::GetScore()
{
	return mScore;
}

void Stage::EraceLine(int eraceY)
{
	//���C������
	for (int i = 0; i < MAX_MAP_NUM_X; i++)
	{
		mMap[eraceY][i] = 0;
	}

	//�u���b�N�ړ�

	for (int i = eraceY; i > 0; i--)
	{
		//��̒i���R�s�[
		for (int j = 0; j < MAX_MAP_NUM_X; j++)
		{
			mMap[i][j] = mMap[i - 1][j];
		}
	}
	//�P�ԏ�̒i������
	for (int i = 0; i < MAX_MAP_NUM_X; i++)
	{
		mMap[0][i] = 0;
	}
}

