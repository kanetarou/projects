#include "DxLib.h"
#include "Stage.h"
#include "KeyCheck.h"
#include "GameCommon.h"
#include "SceneManager.h"
#include "ActiveBlock.h"
#include "CountDown.h"
#include "BlockData.h"
#include "GameScene.h"

GameScene::GameScene(SceneManager* manager) : SceneBase(manager)
{
	if (mStage == nullptr)mStage = new Stage();
	

	if (activeBlock == nullptr)activeBlock = new ActiveBlock();
	//�J�E���g�_�E��
	if (mCntDown == nullptr)mCntDown = new CountDown();
	
}

GameScene::~GameScene()
{
	delete mStage;
	delete activeBlock;
	delete mCntDown;
}

/// <summary>
/// ������
/// </summary>
/// <param name=""></param>
/// <returns></returns>
void GameScene::Init(void)
{
	//�^�C�g���摜�̓ǂݍ���
	mImage = LoadGraph("Image/Game.png");

	mStage->Init(activeBlock);

	activeBlock->Init(mStage,mSceneManager->GetBlockData());

	//����u���b�N�̍쐬
	activeBlock->RandomCreate();
	//activeBlock->ChangeNext();

	mCntDown->Start(3);

	mIsGameStart = false;

}

/// <summary>
/// �X�V�X�e�b�v
/// </summary>
/// <param name=""></param>
/// <returns></returns>
void GameScene::Update(void)
{
	//PlaySound("music.mp3", DX_PLAYTYPE_BACK);
	if (keyTrgDown[KEY_SYS_START])
	{
		mSceneManager->ChangeScene(SCENE_ID::GAMEOVER, true);
		StopSound();
	}
	mStage->Updata();
	mStage->CheckErace();
	activeBlock->Updata();
	
	mCntDown->Update();
	if (mCntDown->IsEnd() == false)
	{
		return;
	}
	else if (mIsGameStart == false)
	{
		mIsGameStart = true;
		activeBlock->ChangeNext();
	}
	
	
	if (mStage->IsGameOver())
	{
		mSceneManager->ChangeScene(SCENE_ID::GAMEOVER, true);
		StopSound();
	}
}

/// <summary>
/// �`�揈��
/// </summary>
/// <param name=""></param>
void GameScene::Draw(void)
{
	
	SetDrawScreen(DX_SCREEN_BACK);

	// ��ʂ̃N���A
	ClearDrawScreen();
	
	DrawGraph(0, 0, mImage, true);
	mStage->Render();
	
	activeBlock->Render();

	mCntDown->Render();
	
	
}

/// <summary>
/// ���\�[�X���
/// </summary>
/// <param name=""></param>
/// <returns></returns>
void GameScene::Release(void)
{
}


