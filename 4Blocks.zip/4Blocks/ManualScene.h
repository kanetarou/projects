#pragma once
#include "SceneBase.h"
class SceneManager;

class ManualScene : public SceneBase
{
private:
	int Image;
public:
	ManualScene(SceneManager* manager);
	~ManualScene();

	void Init() override;
	void Update() override;
	void Draw() override;


};

