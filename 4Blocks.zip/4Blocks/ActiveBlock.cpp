#include <DxLib.h>
#include "KeyCheck.h"
#include "Stage.h"
#include "ActiveBlock.h"

ActiveBlock::ActiveBlock()
{
	mStage = new Stage();
	Init(mStage,mBlockData);
}

ActiveBlock::~ActiveBlock()
{
}

void ActiveBlock::Init(Stage* stage, BlockData* data)
{
	//�摜�̓ǂݍ���
	mImages[(int)BlockData::TYPE::BLOCK_TYPE_I] = LoadGraph("Image/Blocks/LightBlue.png");
	mImages[(int)BlockData::TYPE::BLOCK_TYPE_O] = LoadGraph("Image/Blocks/Yellow.png");
	mImages[(int)BlockData::TYPE::BLOCK_TYPE_S] = LoadGraph("Image/Blocks/Red.png");
	mImages[(int)BlockData::TYPE::BLOCK_TYPE_Z] = LoadGraph("Image/Blocks/Green.png");
	mImages[(int)BlockData::TYPE::BLOCK_TYPE_J] = LoadGraph("Image/Blocks/Orange.png");
	mImages[(int)BlockData::TYPE::BLOCK_TYPE_L] = LoadGraph("Image/Blocks/Blue.png");
	mImages[(int)BlockData::TYPE::BLOCK_TYPE_T] = LoadGraph("Image/Blocks/Purple.png");
	mImages[(int)BlockData::TYPE::BLOCK_TYPE_B] = LoadGraph("Image/Blocks/Yellow.png");

	//�������W�𒆐S�ɃZ�b�g
	int x = MAX_MAP_NUM_X / 2;
	int y = 0;
	mDefaultMapPos = { x,y };
	mMapPos = mDefaultMapPos;

	mBlockData = data;
	mStage = stage;
	//���R�����̏�����
	mFallCnt = 0;
	mMoveFrame = DEF_MOVE_FRAME;

	//��t����ɏ�����
	mCntKeyInput = 0;

	//�蒅�m�肷��܂ł̒x���J�E���^
	mCntSetBlock = 0;

}

void ActiveBlock::Updata()
{
	Vector2 movePow = { 0,0 };
	//����
	mFallCnt++;
	if (mFallCnt > mMoveFrame)
	{
		mFallCnt = 0;
		
		if (mStage->GetScore() < 500)
		{
			movePow = { 0,1 };
		}
		else if (mStage->GetScore() >= 500 && mStage->GetScore() < 1000)
		{
			movePow = { 0,2 };
		}
		else if (mStage->GetScore() >= 1000 && mStage->GetScore() < 1500)
		{
			movePow = { 0,3 };
		}
		if (IsCollision(movePow, mRot) == false)
		{
			mMapPos.y += movePow.y;
		}
		else
		{

			//�x���J�E���^
			mCntSetBlock++;
			if (mCntSetBlock > CNT_SET_BLOCK)
			{

				mStage->SetBlock(mMapPos, mShape);

				if (mStage->IsEffecting() == false)
				{
					ChangeNext();
					mCntSetBlock = 0;
				}
			}
		}
	}

	//���{�^���ŗ������x�𑁂߂�

	if (keyNew[KEY_P1_DOWN])
	{
		movePow = { 0,1 };
		if (IsCollision(movePow, mRot) == false)
		{
			mMapPos.y += movePow.y;
		}
		//else
		//{
		//	mStage->SetBlock(mMapPos, mShape);
		//	//Create(BlockData::TYPE::BLOCK_TYPE_S, BlockData::ROT::R090);
		//	ChangeNext();
		//}
	}

	//��{�^���ŏՓː�܂ŗ���������
	if (keyTrgDown[KEY_P1_UP])
	{
		for (int i = 0; i < MAX_MAP_NUM_Y; i++)
		{
			movePow = { 0,i };

			if (IsCollision(movePow, mRot) == true)
			{

				if (i > 1)
				{
					mCntSetBlock = 0;
					mMapPos.y += (i - 1);

					mStage->SetBlock(mMapPos, mShape);

					if (mStage->IsEffecting() == false)
					{
						ChangeNext();
					}
					break;
				}
			}
		}
	}


	//���E�ړ�
	if (keyTrgDown[KEY_P1_LEFT] || (keyNew[KEY_P1_LEFT]) && mCntKeyInput == 0)
	{
		mCntKeyInput = CNT_LR_MOVE;
		movePow = { -1,0 };
		if (IsCollision(movePow, mRot) == false)
		{
			mMapPos.x += movePow.x;
		}
	}

	if (keyTrgDown[KEY_P1_RIGHT] || (keyNew[KEY_P1_RIGHT]) && mCntKeyInput == 0)
	{
		mCntKeyInput = CNT_LR_MOVE;
		movePow = { 1,0 };
		if (IsCollision(movePow, mRot) == false)
		{
			mMapPos.x += movePow.x;
		}
	}

	if (0 < mCntKeyInput)
	{
		mCntKeyInput--;
	}

	//��]
	//��
	BlockData::ROT  tmpRot;
	if (keyTrgDown[KEY_P1_B])
	{
		tmpRot = GetNextRot(TURN::LEFT);
		movePow = { 0,0 };
		if (IsCollision(movePow, tmpRot) == false)
		{
			mRot = tmpRot;
			mShape = mBlockData->GetData(mType, mRot);
		}

	}
	if (keyTrgDown[KEY_P1_A])
	{
		tmpRot = GetNextRot(TURN::RIGHT);
		movePow = { 0,0 };
		if (IsCollision(movePow, tmpRot) == false)
		{
			mRot = tmpRot;
			mShape = mBlockData->GetData(mType, mRot);
		}
	}
	/*switch (mStage->GetScore())
	{
	case 500:
		movePow = { 0,1 };
		if (IsCollision(movePow, mRot) == false)
		{
			mMapPos.y += movePow.y;
		}
		break;
	case 1000:
		movePow = { 0,1 };
		if (IsCollision(movePow, mRot) == false)
		{
			mMapPos.y += movePow.y;
		}
		break;
	default:
		break;
	}*/

	if (mStage->IsGameOver())
	{
		for (int y = 0; y < BLOCK_MAP_Y; y++)
		{
			for (int x = 0; x < BLOCK_MAP_X; x++)
			{
				mShape.data[y][x] = 0;
			}
		}
	}
	
}

void ActiveBlock::Render()
{
	if (mStage->IsEffecting() == false)
	{
		for (int y = 0; y < BLOCK_MAP_Y; y++)
		{
			for (int x = 0; x < BLOCK_MAP_X; x++)
			{
				if (mShape.data[y][x] == 1)
				{
					DrawGraph(GAME_AREA_X + ((mMapPos.x + x) * BLOCK_IMG_SIZE), GAME_AREA_Y + ((mMapPos.y + y) * BLOCK_IMG_SIZE), mImages[(int)mType], true);
				}

			}
		}
	}
	DrawNextBlock();
	//DrawHoldBlock();
}

//���̃u���b�N�̕\��
void ActiveBlock::DrawNextBlock()
{
	DrawString(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 30, GAME_AREA_Y - 25, "NextBlock", 0x000000, true);
	int startAreaX = GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 30;
	int endAreaX = GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 130;
	DrawBox(startAreaX, GAME_AREA_Y, endAreaX, GAME_AREA_Y + 80, 0xffffff, true);

	//���݂̃u���b�N��\��
	int tmpSize = BLOCK_IMG_SIZE * 0.7;
	int margin = 6;
	for (int i = 0; i < BLOCK_MAP_Y; i++)
	{
		for (int j = 0; j < BLOCK_MAP_X; j++)
		{
			if (mNextShape.data[i][j] == 1)
			{
				DrawExtendGraph((startAreaX) + (tmpSize *j), (GAME_AREA_Y+10)+ (tmpSize * i), (startAreaX) + (tmpSize * j)+tmpSize, (GAME_AREA_Y +10) + (tmpSize * i) + tmpSize, mImages[(int)mNextType], true);
			}
		}
	}
}

void ActiveBlock::Create(BlockData::TYPE type, BlockData::ROT rot)
{
	mType = type;
	mRot = rot;

	mShape = mBlockData->GetData(mType, mRot);

	//�������W�ֈړ�������
	mMapPos = mDefaultMapPos;

}

void ActiveBlock::RandomCreate()
{
	int randomType = GetRand((int)BlockData::TYPE::BLOCK_TYPE_MAX - 1);
	BlockData::TYPE type = (BlockData::TYPE)randomType;

	/*mType = type;
	mRot = BlockData::ROT::R000;
	mShape = mBlockData->GetData(mType, mRot);*/

	//�������W�ֈړ�������
	//mMapPos = mDefaultMapPos;

	//���̃u���b�N�������_���ɐ�������
	mNextType = type;
	mRot = BlockData::ROT::R000;
	mNextShape = mBlockData->GetData(mNextType, BlockData::ROT::R000);
	
}

void ActiveBlock::ChangeNext()
{
	
	
		mType = mNextType;
		mRot = BlockData::ROT::R000;
		mShape = mBlockData->GetData(mType, mRot);

		//�������W�ֈړ�������
		mMapPos = mDefaultMapPos;


		RandomCreate();
}

void ActiveBlock::DrawHoldBlock()
{
	DrawString(GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 60, GAME_AREA_Y + 130, "Hold", 0x000000, true);
	int startAreaX = GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 30;
	int endAreaX = GAME_AREA_X + MAX_MAP_NUM_X * BLOCK_IMG_SIZE + 130;
	DrawBox(startAreaX, GAME_AREA_Y+150, endAreaX, GAME_AREA_Y + 230, 0xffffff, true);
}

void ActiveBlock::ChangeHold()
{
	if (keyTrgDown[KEY_P1_HOLD])
	{
		mType = mHoldType;
	}
	mType = mNextType;
	mRot = BlockData::ROT::R000;
}

bool ActiveBlock::IsCollision(Vector2 movePow, BlockData::ROT rot)
{
	//�Փ˔���
	int mapPosX = mMapPos.x + movePow.x;
	int mapPosY = mMapPos.y + movePow.y;

	BlockData::Shape tmpShape = mBlockData->GetData(mType, rot);;

	int tmpX;
	int tmpY;
	for (int y = 0; y < BLOCK_MAP_Y; y++)
	{
		for (int x = 0; x < BLOCK_MAP_X; x++)
		{
			if (tmpShape.data[y][x] == 1)
			{
				tmpX = mapPosX + x;
				tmpY = mapPosY + y;

				if (0 > tmpX)
				{
					return true;
				}
				if (MAX_MAP_NUM_X <= tmpX)
				{
					return true;
				}
				if (tmpY >= MAX_MAP_NUM_Y)
				{
					return true;
				}

				//�蒅�u���b�N�Ƃ̏Փ�
				if (mStage->GetData(tmpX, tmpY) == 1)
				{
					return true;
				}
			}
		}
	}
	return false;
}


BlockData::ROT ActiveBlock::GetNextRot(TURN turn)
{
	int tmpRot = (int)mRot;
	
	int add = 1;
	if (turn == TURN::LEFT)
	{
		tmpRot += add;
	}
	else if (turn == TURN::RIGHT)
	{
		tmpRot -= add;
	}

	//���E�l�`�F�b�N
	if (tmpRot < 0)
	{
		tmpRot = (int)BlockData::ROT::R270;
	}
	if (tmpRot >= (int)BlockData::ROT::RMAX)
	{
		tmpRot = (int)BlockData::ROT::R000;
	}

	return (BlockData::ROT)tmpRot;
}
