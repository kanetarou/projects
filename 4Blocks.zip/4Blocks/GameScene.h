#pragma once
#include "GameCommon.h"
#include "SceneBase.h"
class SceneManager;
class Stage;
class ActiveBlock;
class CountDown;

class GameScene : public SceneBase
{
public:
	GameScene(SceneManager* manager);
	~GameScene();
	void Init(void) override;
	void Update(void) override;
	void Draw(void) override;
	void Release(void) override;

private:
	int mImage;
	Stage* mStage = nullptr;

	ActiveBlock* activeBlock = nullptr;

	CountDown* mCntDown = nullptr;

	//�Q�[���J�n����p
	bool mIsGameStart;
};
