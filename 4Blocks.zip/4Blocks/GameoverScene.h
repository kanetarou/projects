#pragma once
#include "GameScene.h"
class SceneManager;

class GameoverScene : public SceneBase
{
private:
	int mImage;

public:
	GameoverScene(SceneManager* manager);
	void Init(void) override;
	void Update(void) override;
	void Draw(void) override;
	void Release(void) override;
};
