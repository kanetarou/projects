#include <DxLib.h>
#include "BlockData.h"

void BlockData::Init()
{
	int tmpType;

	tmpType = (int)TYPE::BLOCK_TYPE_I;

	mData[tmpType][(int)ROT::R000] =
	{
		{
		{0,0,0,0},
		{1,1,1,1},
		{0,0,0,0},
		{0,0,0,0},
		}
	};

	//90�x
	mData[tmpType][(int)ROT::R090] =
	{
		{
		{0,0,1,0},
		{0,0,1,0},
		{0,0,1,0},
		{0,0,1,0},
		}
	};

	//180�x
	mData[tmpType][(int)ROT::R180] =
	{
		{
		{0,0,0,0},
		{0,0,0,0},
		{1,1,1,1},
		{0,0,0,0},
		}
	};

	//270�x
	mData[tmpType][(int)ROT::R270] =
	{
		{
		{0,1,0,0},
		{0,1,0,0},
		{0,1,0,0},
		{0,1,0,0},
		}
	};

	//0
	tmpType = (int)TYPE::BLOCK_TYPE_O;
	mData[tmpType][(int)ROT::R000] =
	{
		{
			{0,0,0,0},
			{0,1,1,0},
			{0,1,1,0},
			{0,0,0,0},
		}
	};

	//90
	mData[tmpType][(int)ROT::R090] =
	{
		{
			{0,0,0,0},
			{0,1,1,0},
			{0,1,1,0},
			{0,0,0,0},
		}
	};

	//180
	mData[tmpType][(int)ROT::R180] =
	{
		{
			{0,0,0,0},
			{0,1,1,0},
			{0,1,1,0},
			{0,0,0,0},
		}
	};

	//270
	mData[tmpType][(int)ROT::R270] =
	{
		{
			{0,0,0,0},
			{0,1,1,0},
			{0,1,1,0},
			{0,0,0,0},
		}
	};

	//S
	tmpType = (int)TYPE::BLOCK_TYPE_S;
	mData[tmpType][(int)ROT::R000] =
	{
		{
			{0,0,0,0},
			{0,0,1,1},
			{0,1,1,0},
			{0,0,0,0},
		}
	};

	//90
	mData[tmpType][(int)ROT::R090] =
	{
		{
			{0,1,0,0},
			{0,1,1,0},
			{0,0,1,0},
			{0,0,0,0},
		}
	};

	//180
	mData[tmpType][(int)ROT::R180] =
	{
		{
			{0,0,1,1},
			{0,1,1,0},
			{0,0,0,0},
			{0,0,0,0},
		}
	};

	//270
	mData[tmpType][(int)ROT::R270] =
	{
		{
			{0,0,1,0},
			{0,0,1,1},
			{0,0,0,1},
			{0,0,0,0},
		}
	};

	//Z
	tmpType = (int)TYPE::BLOCK_TYPE_Z;
	mData[tmpType][(int)ROT::R000] =
	{
		{
			{0,0,0,0},
			{0,1,1,0},
			{0,0,1,1},
			{0,0,0,0},
		}
	};

	//180
	mData[tmpType][(int)ROT::R090] =
	{
		{
			{0,0,1,0},
			{0,1,1,0},
			{0,1,0,0},
			{0,0,0,0},
		}
	};

	//180
	mData[tmpType][(int)ROT::R180] =
	{
		{
			{0,1,1,0},
			{0,0,1,1},
			{0,0,0,0},
			{0,0,0,0},
		}
	};

	//270
	mData[tmpType][(int)ROT::R270] =
	{
		{
			{0,0,0,1},
			{0,0,1,1},
			{0,0,1,0},
			{0,0,0,0},
		}
	};

	//J
	tmpType = (int)TYPE::BLOCK_TYPE_J;
	mData[tmpType][(int)ROT::R000] =
	{
		{
			{0,1,0,0},
			{0,1,1,1},
			{0,0,0,0},
			{0,0,0,0},
		}
	};

	//90
	mData[tmpType][(int)ROT::R090] =
	{
		{
			{0,0,1,1},
			{0,0,1,0},
			{0,0,1,0},
			{0,0,0,0},
		}
	};

	//180
	mData[tmpType][(int)ROT::R180] =
	{
		{
			{0,0,0,0},
			{0,1,1,1},
			{0,0,0,1},
			{0,0,0,0},
		}
	};

	//270
	mData[tmpType][(int)ROT::R270] =
	{
		{
			{0,0,1,0},
			{0,0,1,0},
			{0,1,1,0},
			{0,0,0,0},
		}
	};

	//L
	tmpType = (int)TYPE::BLOCK_TYPE_L;
	mData[tmpType][(int)ROT::R000] =
	{
		{
			{0,0,0,1},
			{0,1,1,1},
			{0,0,0,0},
			{0,0,0,0},
		}
	};

	//90
	mData[tmpType][(int)ROT::R090] =
	{
		{
			{0,0,1,0},
			{0,0,1,0},
			{0,0,1,1},
			{0,0,0,0},
		}
	};

	//180
	mData[tmpType][(int)ROT::R180] =
	{
		{
			{0,0,0,0},
			{0,1,1,1},
			{0,1,0,0},
			{0,0,0,0},
		}
	};

	//270
	mData[tmpType][(int)ROT::R270] =
	{
		{
			{0,1,1,0},
			{0,0,1,0},
			{0,0,1,0},
			{0,0,0,0},
		}
	};

	//T
	tmpType = (int)TYPE::BLOCK_TYPE_T;
	mData[tmpType][(int)ROT::R000] = 
	{
		{
			{0,0,1,0},
			{0,1,1,1},
			{0,0,0,0},
			{0,0,0,0},
		}
	};

	//90
	mData[tmpType][(int)ROT::R090] =
	{
		{
			{0,0,1,0},
			{0,0,1,1},
			{0,0,1,0},
			{0,0,0,0},
		}
	};

	//180
	mData[tmpType][(int)ROT::R180] =
	{
		{
			{0,0,0,0},
			{0,1,1,1},
			{0,0,1,0},
			{0,0,0,0},
		}
	};

	//270
	mData[tmpType][(int)ROT::R270] =
	{
		{
			{0,0,1,0},
			{0,1,1,0},
			{0,0,1,0},
			{0,0,0,0},
		}
	};

	//B
	tmpType = (int)TYPE::BLOCK_TYPE_B;
	mData[tmpType][(int)ROT::R000] =
	{
		{
			{0,0,0,0},
			{0,0,1,0},
			{0,0,0,0},
			{0,0,0,0},
		}
	};

	//90
	mData[tmpType][(int)ROT::R090] =
	{
		{
			{0,0,0,0},
			{0,0,1,0},
			{0,0,0,0},
			{0,0,0,0},
		}
	};

	//180
	mData[tmpType][(int)ROT::R180] =
	{
		{
			{0,0,0,0},
			{0,0,1,0},
			{0,0,0,0},
			{0,0,0,0},
		}
	};

	//270
	mData[tmpType][(int)ROT::R270] =
	{
		{
			{0,0,0,0},
			{0,0,1,0},
			{0,0,0,0},
			{0,0,0,0},
		}
	};
}

BlockData::Shape BlockData::GetData(TYPE type, ROT rot)
{
	return mData[(int)type][(int)rot];
}


void BlockData::Render()
{
	
}

void BlockData::TestStudy(int posY)
{
	//���K�F�|�C���^����Ńu���b�N�`����擾
	// 0 0 1 0
	// 0 0 1 0
	// 0 0 1 1
	// 0 0 0 0

	int height = 15;
	posY += height;

	Shape* ptr = mData[0];

	int type = (int)TYPE::BLOCK_TYPE_L;
	int rot = (int)ROT::R090;
		
	int num = (type * (int)ROT::RMAX) + rot;
	ptr += num;

	int* ptr2 = (*ptr).data[0];

	for (int y = 0; y < BLOCK_MAP_Y; y++)
	{
		posY += height;
		for (int x = 0; x < BLOCK_MAP_X; x++)
		{
			DrawFormatString(x * height, posY, 0x000000, "%d", *ptr2);
			ptr2++;
		}
	}
	
}
