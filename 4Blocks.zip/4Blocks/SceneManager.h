//#pragma once
#include "TitleScene.h"
class SceneBase;
class Fader;
class BlockData;
class ActiveBlock;
class Stage;

// �V�[���Ǘ��p
enum class SCENE_ID
{
	NONE
	, TITLE
	, MANUAL
	, GAME
	, GAMEOVER
};

class SceneManager
{
private:

	SCENE_ID mSceneID;
	SCENE_ID mWaitSceneID;

	SceneBase* mScene;
	Fader* mFader;
	BlockData* mBlockData;
	Stage* mStage;
	bool mIsSceneChanging;

	ActiveBlock* activeBlock = nullptr;

public:

	void Init(void);
	void Update(void);
	void Release(void);

	void ChangeScene(SCENE_ID nextId, bool isFading);
	//�u���b�N�`��f�[�^�̎擾
	BlockData* GetBlockData();

private:

	void DoChangeScene(void);

};