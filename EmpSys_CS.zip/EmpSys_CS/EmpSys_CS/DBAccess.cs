﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;



//● データベースに接続する
//● 引数で渡されたユーザーIDを元に、loginuserテーブルを参照し、ユーザー名と権限情報を抽出する
//● 引数で渡された社員IDを元に、employeeテーブルから社員情報を抽出する
//● 引数で渡された社員情報をemployeeテーブルに登録する
//● 検索時、既に存在しない社員IDを指定した場合は、エラーメッセージを出力する
//● 登録時、既に存在する社員IDを指定した場合は、エラーメッセージを出力する
namespace EmpSys_CS
{
    internal class DBAccess
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter sda;
        DataTable dt;
        public DBAccess()
        {
            con = new SqlConnection();
            cmd = new SqlCommand();
            sda = new SqlDataAdapter();
            dt = new DataTable();

            ConnectionStringSettings cs = ConfigurationManager.ConnectionStrings
                ["EmpSys_CS.Properties.Settings.EmpSys_CSDBConnectionString"];
            if(cs == null)
            {
                throw new Exception("データベースへの接続文字列が正しく設定されていません");
            }
            else
            {
                con.ConnectionString = cs.ConnectionString;
                con.Open();
                cmd.Connection = con;
            }
        }
        public User GetUser(string strId,string strPw)
        {
            if(strId != "" || strPw != "" || strId == ToString())
            {
                throw new Exception("正しく入力してください");
            }

            try
            {
                cmd.CommandText = "SELECT * FROM loginuser WHERE ID=@key";
                cmd.Parameters.Clear();
                cmd.Parameters.Add("@key",SqlDbType.Int,4,"ID").Value = strId;
                sda.SelectCommand = cmd;
                sda.Fill(dt);

                if(dt.Rows.Count == 1)
                {
                    User user = new User();
                    return user;
                }
               
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "例外発生");
            }
            finally
            {

            }
        }
    }
}
