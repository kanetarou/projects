﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExTestForm
{
    internal class BattleScene
    {

        public int hp { get; set; }
        public int mp { get; set; }
        public string name { get; set; }

        public BattleScene(string n,int h, int mp)
        {
            hp = h;
            name = n;
            this.mp = mp;
        }

        public virtual string GetInfo()
        {
            return name + " : HP-" + hp + " : MP-" + mp;
        }


        public virtual string AttackDmg(int dmg)
        {
            this.hp -= dmg;
            if(dmg == 0)
            {
                return "ミス！" + this.name + "にダメージを与えられない";
            }
            else
            {
                return this.name + "に" + dmg + "のダメージ";
            }
        }
    }
}
