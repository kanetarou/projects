﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExTestForm
{
    internal class Boss : BattleScene
    {

        public Boss(string str,int hp,int mp):base(str,hp,mp)
        {
            this.hp = hp;
            this.name = str;
            this.mp = mp;
        }

        public override string GetInfo()
        {
            return name + " : HP-" + hp + " : MP-" + mp;
        }

        public override string AttackDmg(int dmg)
        {
            this.hp -= dmg;
            if (dmg == 0)
            {
                return "ミス！" + this.name + "にダメージを与えられない";
            }
            else
            {
                return this.name + "に" + dmg + "のダメージ";
            }
        }

    }
}
