﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExTestForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_cl(object sender, EventArgs e)
        {
            Random random = new Random();
            int num = random.Next(1, 100 + 1);

            num.ToString();
            if(num % 3 == 0 || num.ToString().IndexOf("3") >= 0)
            {
                label1.Text = num + "当たり";
            }
            else
            {
                label1.Text = num + "はずれ";
            }
        }
    }
}
