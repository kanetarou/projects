﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ExTestForm
{
    public partial class Form3 : Form
    {
        int yHp = 100;
        int sHp = 30;
        BattleScene bY;
        BattleScene bS;
        Boss boss;
        int dmg;
        SetMP smp;


        //攻撃した回数
        int cnt = 5;

        //ボス戦闘選択
        DialogResult re;

        public Form3()
        {
            InitializeComponent();

            bY = new BattleScene("勇者", yHp, 80);
            bS = new BattleScene("スライム", sHp, 80);
            boss = new Boss("ボス", 100, 100);
            label1.Text = bY.GetInfo();
            label2.Text = bS.GetInfo();

            //回復ボタン
            button2.Enabled = false;
            button4.Enabled = false;
            
            //必殺技ボタン
            button3.Enabled = false;
            button6.Enabled = false;

            //ボス戦用ボタン
            button4.Visible = false;
            button5.Visible = false;
            button6.Visible = false;

            //回復使用回数
            label4.Text = "残り" + button2.TabIndex + "回";

            //技ボタン初期化
            button1.TabIndex = 0;

            

            label5.Text = "残り" + cnt + "回";

            label7.Text = "";

        }


        //攻撃ボタン
        private void btn_cl(object sender, EventArgs e)
        {
            //勇者とスライムの戦闘
            YvsS();
            //カウンタ
            if (button2.TabIndex <= 0)
            {
                button2.Enabled = false;
            }
            else
            {
                if (bY.hp < 10)
                {
                    button2.Enabled = true;
                }
            }
            button1.TabIndex++;
            if (cnt == 0)
            {
                cnt = 0;
            }
            else
            {
                cnt--;
            }
            label5.Text = "残り" + cnt + "回";

            if (button1.TabIndex == 5 && bY.mp >= 0)
            {
                button3.Enabled = true;
            }
            else if (bY.mp <= 0)
            {
                button3.Enabled = false;
            }

            //ボス
            if (re == DialogResult.Yes)
            {
                button1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
                button4.Visible = true;
                button5.Visible = true;
                button6.Visible = true;

                label2.Text = "";
                label7.Text = boss.GetInfo();
                cnt = 5;
                label5.Text = "残り" + cnt + "回";
            }
            else
            {

            }
        }

        private void AddLog(string log)
        {
            listBox1.Items.Add(log);
        }

        //回復ボタン
        private void btn_heal(object sender, EventArgs e)
        {
            bY.hp += 10;
            label1.Text = bY.GetInfo();
            AddLog("勇者のHPを10回復");
            button2.TabIndex--;
            label4.Text = "残り" + button2.TabIndex + "回";


            button2.Enabled = false;

        }


        //技ボタン
        private void btn_Attack(object sender, EventArgs e)
        {
            cnt = 5;
            switch (cmb.SelectedIndex)
            {
                case 0:
                    if (bY.mp >= 10)
                    {
                        dmg = 10;
                        bY.mp -= 10;
                        AddLog("勇者はMPを" + bY.mp + "消費した");
                    }
                    else
                    {
                        MessageBox.Show("MPが足りません！");
                        dmg = 0;
                    }
                    break;
                case 1:
                    if (bY.mp >= 20)
                    {
                        dmg = 15;
                        bY.mp -= 20;
                        AddLog("勇者はMPを" + bY.mp + "消費した");
                    }
                    else
                    {
                        MessageBox.Show("MPが足りません！");
                        dmg = 0;
                    }
                    break;
                case 2:
                    if (bY.mp >= 30)
                    {
                        dmg = 20;
                        bY.mp -= 30;
                        AddLog("勇者はMPを" + bY.mp + "消費した");
                    }
                    else
                    {
                        MessageBox.Show("MPが足りません！");
                        dmg = 0;
                    }
                    break;
                case 3:
                    if (bY.mp >= 40)
                    {
                        dmg = 25;
                        bY.mp -= 40;
                        AddLog("勇者はMPを" + bY.mp + "消費した");
                    }
                    else
                    {
                        MessageBox.Show("MPが足りません！");
                        dmg = 0;
                    }
                    break;
                default:
                    break;
            }
            AddLog(bS.AttackDmg(dmg));

            label2.Text = bS.GetInfo();
            label1.Text = bY.GetInfo();
            button1.TabIndex = 0;

            //消費MPの表示



            if (bS.hp <= 0)
            {
                AddLog(bS.name + "を倒した");
                btn_False();
                re = MessageBox.Show("ボスに挑みますか?", "※挑戦", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            button3.Enabled = false;
        }

        //ボタン状態専用関数
        private void btn_False()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
        }

        //ボス戦時の攻撃ボタン
        private void Boss_Ch(object sender, EventArgs e)
        {
            Random random = new Random();

            //勇者の攻撃
            dmg = random.Next(0, 7 + 1);
            AddLog(boss.AttackDmg(dmg));
            label7.Text = boss.GetInfo();
            if (boss.hp <= 0)
            {
                AddLog(boss.name + "を倒した");
                btn_False();
                return;
            }

            dmg = random.Next(0, 7 + 1);
            AddLog(bY.AttackDmg(dmg));
            label1.Text = bY.GetInfo();
            if (bY.hp <= 0)
            {
                AddLog(bY.name + "は負けた");
                btn_False();
                return;
            }

            //カウンタ
            if (button4.TabIndex <= 0)
            {
                button4.Enabled = false;
            }
            else
            {
                if (bY.hp < 10)
                {
                    button4.Enabled = true;
                }
            }
            button5.TabIndex++;
            if (cnt == 0)
            {
                cnt = 0;
            }
            else
            {
                cnt--;
            }
            label5.Text = "残り" + cnt + "回";

            if (button5.TabIndex == 5 && bY.mp >= 0)
            {
                button6.Enabled = true;
            }
            else if (bY.mp <= 0)
            {
                button6.Enabled = false;
            }
        }

        //勇者とスライムの戦闘処理
        private void YvsS()
        {
            Random random = new Random();

            //勇者の攻撃
            dmg = random.Next(0, 7 + 1);
            AddLog(bS.AttackDmg(dmg));
            label2.Text = bS.GetInfo();
            if (bS.hp <= 0)
            {
                AddLog(bS.name + "を倒した");
                btn_False();

                re = MessageBox.Show("ボスに挑みますか?", "※挑戦", MessageBoxButtons.YesNo, MessageBoxIcon.None);
            }

            //スライムの攻撃
            dmg = random.Next(0, 7 + 1);
            AddLog(bY.AttackDmg(dmg));
            label1.Text = bY.GetInfo();
            if (bY.hp <= 0)
            {
                AddLog(bY.name + "は負けた");
                btn_False();
                return;
            }
        }

        //ボス戦時の回復
        private void boss_heal(object sender, EventArgs e)
        {
            bY.hp += 10;
            label1.Text = bY.GetInfo();
            AddLog("勇者のHPを10回復");
            button4.TabIndex--;
            label4.Text = "残り" + button4.TabIndex + "回";


            button4.Enabled = false;
        }

        //ボス戦時の技ボタン
        private void boss_Attack(object sender, EventArgs e)
        {
            cnt = 5;
            switch (cmb.SelectedIndex)
            {
                case 0:
                    if (bY.mp >= 10)
                    {
                        dmg = 10;
                        bY.mp -= 10;
                        AddLog("勇者はMPを" + bY.mp + "消費した");
                    }
                    else
                    {
                        MessageBox.Show("MPが足りません！");
                        dmg = 0;
                    }
                    break;
                case 1:
                    if (bY.mp >= 20)
                    {
                        dmg = 15;
                        bY.mp -= 20;
                        AddLog("勇者はMPを" + bY.mp + "消費した");
                    }
                    else
                    {
                        MessageBox.Show("MPが足りません！");
                        dmg = 0;
                    }
                    break;
                case 2:
                    if (bY.mp >= 30)
                    {
                        dmg = 20;
                        bY.mp -= 30;
                        AddLog("勇者はMPを" + bY.mp + "消費した");
                    }
                    else
                    {
                        MessageBox.Show("MPが足りません！");
                        dmg = 0;
                    }
                    break;
                case 3:
                    if (bY.mp >= 40)
                    {
                        dmg = 25;
                        bY.mp -= 40;
                        AddLog("勇者はMPを" + bY.mp + "消費した");
                    }
                    else
                    {
                        MessageBox.Show("MPが足りません！");
                        dmg = 0;
                    }
                    break;
                default:
                    break;
            }
            AddLog(boss.AttackDmg(dmg));

            label7.Text = boss.GetInfo();
            label1.Text = bY.GetInfo();
            button5.TabIndex = 0;

            //消費MPの表示



            if (boss.hp <= 0)
            {
                AddLog(boss.name + "を倒した");
                btn_False();
                MessageBox.Show("ボスを倒しました！");
            }
            button6.Enabled = false;
        }
    }
}
