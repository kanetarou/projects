﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//BMI指数計算
namespace ExTestForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_cl(object sender, EventArgs e)
        {
            double w = double.Parse(textBox1.Text);
            double h = double.Parse(textBox2.Text);
            
            double bmi = w / (h * h);

            string s = bmi.ToString("F2");
            if(bmi < 18.5)
            {
                label3.Text = "BMI指数 : " + s + "(痩せています)";
            }
            else if(bmi < 25)
            {
                label3.Text = "BMI指数 : " + s + "(普通です)";
            }
            else if (bmi < 35)
            {
                label3.Text = "BMI指数 : " + s + "(やや肥満です)";
            }
            else if (bmi >= 35)
            {
                label3.Text = "BMI指数 : " + s + "(肥満です)";
            }
        }
    }
}
