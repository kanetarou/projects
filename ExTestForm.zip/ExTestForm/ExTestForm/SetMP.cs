﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExTestForm
{
    internal class SetMP
    {
        public int MP { get; set; }
        public string Disp { get; set; }

        public SetMP(int mP, string disp)
        {
            MP = mP;
            Disp = disp;
        }
    }
}
