#include <time.h>
#include "DxLib.h"
#include "main.h"
#include "Init.h"

bool SysInit(void)
{

	bool rtnFlag = true;
	const char* fileNameList[CHAR_ID_MAX][IMAGE_TYPE_MAX] =
	{
		{"image/madoka.png","image/icon_madoka.png","image/madoka_st.png"},
		{"image/sayaka.png","image/icon_sayaka.png","image/sayaka_st.png"},
		{"image/mami.png",	"image/icon_mami.png",	"image/mami_st.png"	},
		{"image/kyoko.png",	"image/icon_kyoko.png",	"image/kyoko_st.png"},
		{"image/homura.png","image/icon_homura.png","image/homura_st.png"},
		{"image/qb.png",	"image/icon_qb.png",	"image/qb_st.png"	},
	};
	/*const char* blockNameList[BL_MAX] =
	{
		{ "image/block1.png" },
		{ "image/block2.png" },
		{ "image/block3.png" },
		{ "image/block4.png" },
		{ "image/block5.png" },
	};*/

	// ���я���
	SetWindowText("1916010_���q�ɑ��Y");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);			// 800*600�ޯāA65536�F���[�h�ɐݒ�(SysInit)

	ChangeWindowMode(true);									// true:window  false:�ٽ�ذ�(SysInit)
	if (DxLib_Init() == -1)									// (SysInit)
	{
		AST();
		return false;
	}
	SetDrawScreen(DX_SCREEN_BACK);

	srand((unsigned)time(NULL));

	for (int y = 0; y < CHAR_ID_MAX; y++)
	{
		for (int x = 0; x < BL_MAX; x++)
		{
			if (LoadDivGraph(fileNameList[y][IMAGE_TYPE_CHAR], ANIM_IMAGE_MAX * DIR_MAX,
				ANIM_IMAGE_MAX, DIR_MAX,
				CHAR_SIZE_X, CHAR_SIZE_Y,
				charImage[y].chipImage[0]) == -1)
			{
				AST();
				rtnFlag = false;
			}

			if ((charImage[y].faceImage = LoadGraph(fileNameList[y][IMAGE_TYPE_FACE])) == -1)
			{
				AST();
				rtnFlag = false;
			}
			if ((charImage[y].standImage = LoadGraph(fileNameList[y][IMAGE_TYPE_STAND])) == -1)
			{
				AST();
				rtnFlag = false;
			}
		}
	}
	// ���Ă̎��̉摜

	if (LoadDivGraph("image/start_mes.png", START_MAX, 1, START_MAX, START_IMAGE_SIZE_X, START_IMAGE_SIZE_Y,
		&startImage[0], true) == -1)
	{
		AST();
		rtnFlag = false;
	}

	// ��בI���̉摜
	charSelImage = LoadGraph("image/char_sel.png");
	if (charSelImage == -1)
	{
		AST();
		rtnFlag = false;
	}
	// ���ق̉摜
	titleImage = LoadGraph("image/title.png");
	if (titleImage == -1)
	{
		AST();
		rtnFlag = false;
	}

	// ��ׂ̏��������̉摜
	if (LoadDivGraph("image/WIN.png", CHAR_ID_MAX, 1, CHAR_ID_MAX, WIN_IMAGE_SIZE_X, WIN_IMAGE_SIZE_Y, &winImage[0], true) == -1)
	{
		AST();
		rtnFlag = false;
	}
	// ��ۯ��̉摜
	if (LoadDivGraph("image/block1.png", BLOCK_PTN_MAX, BLOCK_PTN_MAX, 1, MAP_CHIP_SIZE_X, MAP_CHIP_SIZE_Y,
		blockImage1) == -1)
	{
		AST();
		rtnFlag = false;
	}
	

	// �F�Ⴂ����ۯ��̉摜
	if (LoadDivGraph("image/block2.png", BLOCK_PTN_MAX, BLOCK_PTN_MAX, 1, MAP_CHIP_SIZE_X, MAP_CHIP_SIZE_Y,
		blockImage2) == -1)
	{
		AST();
		rtnFlag = false;
	}
	if (LoadDivGraph("image/block3.png", BLOCK_PTN_MAX, BLOCK_PTN_MAX, 1, MAP_CHIP_SIZE_X, MAP_CHIP_SIZE_Y,
		blockImage3) == -1)
	{
		AST();
		rtnFlag = false;
	}
	if (LoadDivGraph("image/block4.png", BLOCK_PTN_MAX, BLOCK_PTN_MAX, 1, MAP_CHIP_SIZE_X, MAP_CHIP_SIZE_Y,
		blockImage4) == -1)
	{
		AST();
		rtnFlag = false;
	}
	if (LoadDivGraph("image/block5.png", BLOCK_PTN_MAX, BLOCK_PTN_MAX, 1, MAP_CHIP_SIZE_X, MAP_CHIP_SIZE_Y,
		blockImage5) == -1)
	{
		AST();
		rtnFlag = false;
	}


	// �ްт̔w�i�摜
	gameBgImage = LoadGraph("image/bg.png");
	if (gameBgImage == -1)
	{
		AST();
		rtnFlag = false;
	}
	scnID = SCN_ID_TITLE;
	flamCnt = 0;
	// ���ق̔w�i���
	titleHImage = LoadGraph("image/haikei.png");
	if (titleHImage == -1)
	{
		AST();
		rtnFlag = false;
	}
	// ���т̕`��
	itemImage = LoadGraph("image/item.png");
	if (itemImage == -1)
	{
		AST();
		rtnFlag = false;
	}
	// �ްѵ��ް��݂̔w�i
	GameOverImage = LoadGraph("image/Qb.png");
	if (GameOverImage == -1)
	{
		AST();
		rtnFlag = false;
	}

	// �ǂݍ���
	if (LoadDivGraph("image/tensu.png", 10, 10, 1, CntsizeX, CntsizeY, cntImage) == -1)
	{
		AST();
		rtnFlag = false;
	}

	return rtnFlag;
}
