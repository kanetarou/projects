#include "DxLib.h"
#include "main.h"
#include "Init.h"

// ---------------------------------------------�ۑ��o���@7��12���܂�-----------------------------------

SCN_ID scnID;						// ���ID
SCN_ID scnIdOld;					// ���ID(1�ڰёO)

Pos chipPos;						// ���߂̍��W

int flamCnt;						// ���̼�݂ɂȂ��Ă���̌o���ڰ�

bool keyFlagSp;						// ��߰����̉����׸�
bool keyFlagSpOld;					// ��߰����̉����׸�

int titleImage;						// ���ى��
int titleHImage;					// ���ق̔w�i�摜

int GameOverImage;					// �ްѵ��ް��݂̉摜

// �Ұ�ޗp
int gameBgImage;					// �ްђ��̔w�i
int chipImage;						// ��Ͻ�̉摜
CHAR_IMAGE charImage[CHAR_ID_MAX];	// ��ײҰ��
int blockImage1[BLOCK_PTN_MAX];		// �ɶ����ۯ��p
int blockImage2[BLOCK_PTN_MAX];		// �Զ����ۯ��p
int blockImage3[BLOCK_PTN_MAX];		// �Ђ���ۯ��p
int blockImage4[BLOCK_PTN_MAX];		// ��������ۯ��p
int blockImage5[BLOCK_PTN_MAX];		// ��ׂ���ۯ��p

int charSelImage;					// ��׸���̑I���摜

// �ްїp
Player player[PLAYER_MAX];		// ��׸��


// GameOverScene�p
int winnerID;					// ����������ID
int winImage[CHAR_ID_MAX];		// ���������̉摜
int standImage;					// �����摜

int faceBright;					// �籲�݂̖��邳

// ���ėp
int startImage[START_MAX];

// ����
int cntImage[10];				// �����摜�o�^
int CntsizeX;					// 1�ς̉�����
int CntsizeY;					// 1�ς̏c����
int NumLen;						// ����̌���


// �ړ����̷�ؽ�
const int KeyList[PLAYER_MAX][DIR_MAX] = {
	// ��			�E					��				��
	{KEY_INPUT_W,	KEY_INPUT_D,		KEY_INPUT_S,	KEY_INPUT_A},		// ��ڲ԰�P

	{KEY_INPUT_UP,	KEY_INPUT_RIGHT,	KEY_INPUT_DOWN,	KEY_INPUT_LEFT},		// ��ڲ԰�Q
};

int mapData[MAP_CHIP_CNT_Y][MAP_CHIP_CNT_X];		// ��ۯ��̔z�u�p
 
// Ҳ�
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	
	SysInit();
	GameInit();
	
	if (!SysInit())
	{
		return -1;
	}
	
	while (ProcessMessage() == 0 && CheckHitKey(KEY_INPUT_ESCAPE) == 0)
	{
		if (scnIdOld != scnID)
		{
			flamCnt = 0;
		}

		scnIdOld = scnID;

		GetKeyState();
		switch (scnID)
		{
		case SCN_ID_TITLE:
			TitleScene();
			break;
		case SCN_ID_CHAR_SEL:
			CharSelScene();
			break;
		case SCN_ID_GAME:
			GameScene();
			break;
		case SCN_ID_GAMEOVER:
			GameOverScene();
			break;
		case SCN_ID_NEXTSTAGE:
			NextScene();
			break;
		default:
			AST();
			break;
		}
		flamCnt++;
	}
	return 0;
}

// ���ьn������

// �����̎擾
void GetKeyState(void)
{
	keyFlagSpOld = keyFlagSp;

	keyFlagSp = CheckHitKey(KEY_INPUT_SPACE);		// ����

	for (int no = 0; no < PLAYER_MAX; no++)
	{
		for (DIR dir = DIR_UP;dir < DIR_MAX;dir = (DIR)(dir + 1))
		{
			player[no].keyDataOld[dir] = player[no].keyData[dir];
			player[no].keyData[dir] = CheckHitKey(KeyList[no][dir]);
		}
	}
}

// ����
bool TitleInit(void)
{
	bool rtnFlag = true;
	flamCnt++;
	return  rtnFlag;
}

// ���ى�ʏ���
void TitleScene(void)
{
	if (keyFlagSp && !keyFlagSpOld)
	{
		PlaySoundFile("koukaon.wav", DX_PLAYTYPE_BACK);
		while (CheckSoundFile() == 1)
		{
			if (ProcessMessage() == -1)
			{
				break;
			}
		}
		CharSelInit();
	}
	
	TitleDraw();
}

// ���ټ�݂̕`��
void TitleDraw(void)
{
	ClsDrawScreen();

	DrawGraph(0, 0, titleHImage, true);
	// ���ټ�݂�÷��ү����
	DrawGraph((SCREEN_SIZE_X - TITLE_SIZE_X) / 2 + 40, (SCREEN_SIZE_Y  - TITLE_SIZE_Y) / 2 + 50, titleImage, true);
	if (((flamCnt / 30) % 2) == 0)
	{
		DrawString(270, TITLE_SIZE_Y + GAME_SCREEN_SIZE_Y / 2 - 50, 
			"�o�k�d�r�d�@�f�r�o�`�b�d�@�f�@�j�d�x", GetColor(0, 0, 0));
	}
	
	ScreenFlip();
}

// ��בI���̏�����
bool CharSelInit(void)
{
	
	bool rtnFlag = true;
	for (int y = 0; y < PLAYER_MAX; y++)
	{
		player[y].state = PL_ST_NON;
		player[y].animCnt = 0;
		player[y].scrCnt = 0;
		player[y].speed = PLAYER_DEF_SPEED;
	}
	player[0].charID = CHAR_ID_HOMURA;
	player[0].pos.x = MAP_CHIP_SIZE_X * 5;
	player[0].pos.y = MAP_CHIP_SIZE_Y * 5;
	player[0].dir = DIR_RIGHT;


	player[1].charID = CHAR_ID_MADOKA;
	player[1].pos.x = (MAP_CHIP_CNT_X - 5) * MAP_CHIP_SIZE_X;
	player[1].pos.y = MAP_CHIP_SIZE_Y * 5;
	player[1].dir = DIR_LEFT;

	InitMapID();
	faceBright = 200;
	scnID = SCN_ID_CHAR_SEL;
	return rtnFlag;
}
// ��בI���
void CharSelScene(void)
{
	CharSelDraw();
	
	//DrawGraph((SCREEN_SIZE_X - START_IMAGE_SIZE_X) / 2, (SCREEN_SIZE_Y - START_IMAGE_SIZE_Y) / 2, startImage[1], true);
		
	if (player[0].state == PL_ST_ALIVE && player[1].state == PL_ST_ALIVE)
	{
		GameInit();
	}
	
}
// ��בI���̕`��
void CharSelDraw(void)
{
	ClsDrawScreen();
	DrawGameObject();
	for (int no = 0; no < PLAYER_MAX; no = no + 1)
	{
		for (int x = 0; x < IMAGE_TYPE_MAX; x = x + 1)
		{
			if (player[no].keyData[DIR_LEFT] && !player[no].keyDataOld[DIR_LEFT])
			{
				if (player[no].charID > CHAR_ID_MADOKA)
				{
					player[no].charID = (CHAR_ID)(player[no].charID - 1);
				}
				else
				{
					player[no].charID = CHAR_ID_HOMURA;
				}
			}

			if (player[no].keyData[DIR_RIGHT] && !player[no].keyDataOld[DIR_RIGHT])
			{
				if (player[no].charID < CHAR_ID_HOMURA)
				{
					player[no].charID = (CHAR_ID)(player[no].charID + 1);
				}
				else
				{
					player[no].charID = CHAR_ID_MADOKA;
				}


			}
			if (player[no].keyData[DIR_UP] && !player[no].keyDataOld[DIR_UP])
			{
				player[no].state = PL_ST_ALIVE;
			}

			/*if (player[no].state == PL_ST_ALIVE)
			{
				!player[no].keyData[DIR_LEFT];
				!player[no].keyData[DIR_RIGHT];
			}*/
			
			if (player[no].keyData[DIR_DOWN] && !player[no].keyDataOld[DIR_DOWN])
			{
				player[no].state = PL_ST_NON;
			}
			if (player[0].charID ==  player[1].charID)
			{
				player[no].state = PL_ST_NON;
			}
		}
		DrawGraph((SCREEN_SIZE_X - CHAR_SEL_IMAGE_SIZE_X) / 2, 0, charSelImage, true);
	}
	ScreenFlip();
}


// �ްѼ�݂̏�����
bool GameInit(void)
{
	bool rtnFlag = true;
	
	faceBright = 60;

	scnID = SCN_ID_GAME;
	
	return rtnFlag;
}


// �ްѼ��
void GameScene(void)
{
	int aliveCnt = 0;
	UpdateMap();
	if (flamCnt > 130)
	{
		for (int y = 0; y < PLAYER_MAX; y++)
		{
			PlayerCtl(y);
			if (player[y].state == PL_ST_ALIVE)
			{
				aliveCnt++;
			}
		}
	}
		GameDraw();
		
	
		//��ڲ԰�����񂾂�ްѵ��ް���
	for (int y = 0; y < PLAYER_MAX; y++)
	{
		if (player[y].state == PL_ST_DETH)
		{
			GameOverInit();
			break;
		}
	}
	for (int s = 0; s < PLAYER_MAX; s++)
	{
		if (player[s].state == PL_ST_ALIVE && CheckHitKey(KEY_INPUT_Q) || CheckHitKey(KEY_INPUT_1))
		{
			if (player[s].charID == CHAR_ID_MADOKA)
			{
					
			}

			if (player[s].charID == CHAR_ID_SAYAKA)
			{
				player[s].speed = 3;
			}

			if (player[s].charID == CHAR_ID_MAMI)
			{
				player[s].speed = 3;
			}
			if (player[s].charID == CHAR_ID_KYOKO)
			{
				player[s].speed = 3;
			}
			if (player[s].charID == CHAR_ID_HOMURA)
			{
				player[s].speed = 3;
			}
			
		}
	}
	
}
// �ްѼ�݂̕`��
void GameDraw(void)
{
	ClsDrawScreen();
	
	
	DrawGameObject();
	

	if (flamCnt < 60)
	{
		// ��[��
		DrawGraph((SCREEN_SIZE_X - START_IMAGE_SIZE_X) / 2, (SCREEN_SIZE_Y - START_IMAGE_SIZE_Y) / 2, startImage[0], true);
	}
	else if (flamCnt < 120)
	{
		// ����
		DrawGraph((SCREEN_SIZE_X - START_IMAGE_SIZE_X) / 2, (SCREEN_SIZE_Y - START_IMAGE_SIZE_Y) / 2, startImage[1], true);
	}
	else
	{
		// �����N���Ȃ�

	}

	
	/*DrawFormatString(GAME_SCREEN_X + GAME_SCREEN_SIZE_X + 100 - drawLengh, 120, GetColor(0,0,0),
		"%d", drawScr);*/
	

	ScreenFlip();
}

// �ްѵ��ް��݂̏�����
bool GameOverInit(void)
{
	bool rtnFlag = true;

	winnerID = -1;

	for (int y = 0; y < PLAYER_MAX; y++)
	{
		if (player[y].state == PL_ST_ALIVE)
		{
			if (winnerID == -1)
			{
				winnerID = y;
			}
			else
			{ 
				AST();
				rtnFlag = -1;
				winnerID = -1;
			}
		}
	}
	scnID = SCN_ID_GAMEOVER;

	return rtnFlag;
}
// �ްѵ��ް���
void GameOverScene(void)
{
	GameOverDraw();
	// ��߰��������������ى�ʂɈڍs
	if (keyFlagSp && !keyFlagSpOld)
	{
		scnID = SCN_ID_TITLE;
	}
	// ��ķ��������đ��ð�ނɈڍs
	if (CheckHitKey(KEY_INPUT_LSHIFT))
	{
		scnID = SCN_ID_NEXTSTAGE;
	}
}
//  �ްѵ��ް
void GameOverDraw(void)
{
	ClsDrawScreen();
	DrawGameObject();

	//�w�i�摜
	DrawGraph(0, 0, GameOverImage, true);
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 128);
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, GetColor(0, 0, 0), true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
	
	// ���҂̕`��
	if ((winnerID >= 0) && (winnerID < PLAYER_MAX))
	{
		DrawGraph(SCREEN_SIZE_X / 2 - STAND_IMAGE_SIZE_X / 2, SCREEN_SIZE_Y / 2 - STAND_IMAGE_SIZE_Y / 2,
			charImage[player[winnerID].charID].standImage, true);

		DrawGraph(SCREEN_SIZE_X / 2 - WIN_IMAGE_SIZE_X / 2, SCREEN_SIZE_Y / 2 - WIN_IMAGE_SIZE_Y / 2,
			winImage[player[winnerID].charID], true);
		//DrawGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, Image, true);
	}
	// ���������̏ꍇ
	else
	{
		DrawGraph(SCREEN_SIZE_X / 2 - WIN_IMAGE_SIZE_X / 2, SCREEN_SIZE_Y / 2 - WIN_IMAGE_SIZE_Y /2,
			winImage[CHAR_ID_QB], true);
		DrawGraph(SCREEN_SIZE_X / 2 - STAND_IMAGE_SIZE_X / 2, SCREEN_SIZE_Y / 2 - STAND_IMAGE_SIZE_Y / 2,
			charImage[player[CHAR_ID_QB].charID].standImage, true); 
	}
	if (((flamCnt / 30) % 2) == 0)
	{
		DrawString(270, 20, "�o�k�d�r�d�@�@�f�r�o�`�b�d�f�@�j�d�x", GetColor(60, 255, 85));
	}
	//DrawString(270, 500, "���X�e�[�W�ւ����܂����H", GetColor(0, 0, 0));
	/*if (CheckHitKey(KEY_INPUT_LSHIFT))
	{
		scnID = SCN_ID_NEXTSTAGE;
	}*/

	ScreenFlip();
}
// ���ð��
bool NextStageInit(void)
{
	bool rtnFlag = true;
	for (int y = 0; y < PLAYER_MAX; y++)
	{
		player[y].state = PL_ST_NON;
		player[y].animCnt = 0;
		player[y].scrCnt = 0;
		player[y].speed = PLAYER_DEF_SPEED;
	}
	player[0].charID = CHAR_ID_HOMURA;
	player[0].pos.x = MAP_CHIP_SIZE_X * 5;
	player[0].pos.y = MAP_CHIP_SIZE_Y * 5;
	player[0].dir = DIR_LEFT;


	player[1].charID = CHAR_ID_MAMI;
	player[1].pos.x = (MAP_CHIP_CNT_X - 5) * MAP_CHIP_SIZE_X;
	player[1].pos.y = MAP_CHIP_SIZE_Y * 5;
	player[1].dir = DIR_LEFT;

	InitMapID();
	faceBright = 200;
	
	
	scnID = SCN_ID_NEXTSTAGE;

	return rtnFlag;
}
// ���ð�ނ̼��
void NextScene(void)
{
	CharSelDraw();
	NextDraw();
	if (CheckHitKey(KEY_INPUT_LSHIFT))
	{
		CharSelInit();
	}
	if (player[0].state == PL_ST_ALIVE && player[1].state == PL_ST_ALIVE)
	{
		NextStageInit();
	}
}
// ���ð�ނ̕`��
void NextDraw(void)
{
	ClsDrawScreen();

	NextGameObj();

	if (CheckHitKey(KEY_INPUT_SPACE))
	{
		if (flamCnt < 60)
		{
			// ��[��
			DrawGraph((SCREEN_SIZE_X - START_IMAGE_SIZE_X) / 2, (SCREEN_SIZE_Y - START_IMAGE_SIZE_Y) / 2, startImage[0], true);
		}
		else if (flamCnt < 120)
		{
			// ����
			DrawGraph((SCREEN_SIZE_X - START_IMAGE_SIZE_X) / 2, (SCREEN_SIZE_Y - START_IMAGE_SIZE_Y) / 2, startImage[1], true);
		}
		else
		{
			// �����N���Ȃ�

		}
	}

	ScreenFlip();
}
// ���ð�ނ�obj
void NextGameObj(void)
{
	DrawGraph(0, 0, gameBgImage, true);

	for (int y = 0; y < MAP_CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < MAP_CHIP_CNT_X; x++)
		{
			if (mapData[y][x] > 0)
			{
				int mapID = (mapData[y][x] / BLOCK_CNT_INV);

				if (mapID > (BLOCK_PTN_MAX - 1))
				{
					AST();
				}

				// �O�����Z�q
				//mapID = mapID > BLOCK_PTN_MAX - 1;
				if (mapID)
					DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
						GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
						blockImage1[mapID], true);
			}
		}
	}
	// Ĺނ̐ݒu


	// ��ڲ԰�̱�Ұ���
	for (int y = 0; y < PLAYER_MAX; y++)
	{
		if (player[y].state == PL_ST_ALIVE)
		{
			player[y].animCnt++;
		}
		int tmpAnimID = (player[y].animCnt / ANIM_SPEED) % 2;

		DrawGraph(GAME_SCREEN_X + player[y].pos.x,
			GAME_SCREEN_Y + player[y].pos.y - MAP_CHIP_SIZE_Y / 3,
			charImage[player[y].charID].chipImage[player[y].dir][tmpAnimID], true);

		if (player[y].state != PL_ST_ALIVE)
			SetDrawBright(faceBright, faceBright, faceBright);
		DrawGraph((GAME_SCREEN_SIZE_X / 2) - 300 * (1 - (2 * y)), 0,
			charImage[player[y].charID].faceImage, true);
		SetDrawBright(255, 255, 255);
	}
}

// �ްђ��̷�Я�
void DrawGameObject(void)
{
	DrawGraph(0, 0, gameBgImage, true);

	for (int y = 0; y < MAP_CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < MAP_CHIP_CNT_X; x++)
		{
			if (mapData[y][x] > 0)
			{
				int mapID = (mapData[y][x] / BLOCK_CNT_INV);

				if (mapID > (BLOCK_PTN_MAX - 1))
				{
					AST();
				}

				if (mapID)
					DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
						GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
						blockImage1[mapID], true);
				/*if (player[y].charID == CHAR_ID_SAYAKA)
				{
					if (mapID)
						DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
							GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
							blockImage2[mapID], true);
				}
				if (player[y].charID == CHAR_ID_MAMI)
				{
					if (mapID)
						DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
							GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
							blockImage3[mapID], true);
				}
				if (player[y].charID == CHAR_ID_KYOKO)
				{
					if (mapID)
						DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
							GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
							blockImage4[mapID], true);
				}
				if (player[y].charID == CHAR_ID_HOMURA)
				{
					if (mapID)
						DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
							GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
							blockImage5[mapID], true);
				}*/
			}
		}
		}
	

	/*for (int y = 0; y < MAP_CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < MAP_CHIP_CNT_X; x++)
		{
			if (player[y].state == PL_ST_ALIVE)
			{
				if (player[y].charID == CHAR_ID_KYOKO)
				{
					if (mapData[y][x] > 0)
					{
						int mapID = (mapData[y][x] / BLOCK_CNT_INV);

						if (mapID > (BLOCK_PTN_MAX - 1))
						{
							AST();
						}
						if (mapID)
							DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
								GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
								blockImage[mapID], true);
					}
				}
			}
		}
	}*/

	/*for (int y = 0; y < MAP_CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < MAP_CHIP_CNT_X; x++)
		{
			if (player[y].state == PL_ST_ALIVE)
			{
				if (player[y].charID == CHAR_ID_SAYAKA)
				{
					if (mapData[y][x] > 0)
					{
						int mapID = (mapData[y][x] / BLOCK_CNT_INV);

						if (mapID > (BLOCK_PTN_MAX - 1))
						{
							AST();
						}
						if (mapID)
							DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
								GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
								blockImage3[mapID], true);
					}
				}
			}
		}
	}*/

	/*for (int y = 0; y < MAP_CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < MAP_CHIP_CNT_X; x++)
		{
			if (player[y].state == PL_ST_ALIVE)
			{
				if (player[y].charID == CHAR_ID_MADOKA)
				{
					if (mapData[y][x] > 0)
					{
						int mapID = (mapData[y][x] / BLOCK_CNT_INV);

						if (mapID > (BLOCK_PTN_MAX - 1))
						{
							AST();
						}
						if (mapID)
							DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
								GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
								blockImage4[mapID], true);
					}
				}
			}
		}
	}*/

	/*for (int y = 0; y < MAP_CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < MAP_CHIP_CNT_X; x++)
		{
			if (player[y].state == PL_ST_ALIVE)
			{
				if (player[y].charID == CHAR_ID_HOMURA)
				{
					if (mapData[y][x] > 0)
					{
						int mapID = (mapData[y][x] / BLOCK_CNT_INV);

						if (mapID > (BLOCK_PTN_MAX - 1))
						{
							AST();
						}
						if (mapID)
							DrawGraph(GAME_SCREEN_X + x * MAP_CHIP_SIZE_X,
								GAME_SCREEN_Y + y * MAP_CHIP_SIZE_Y,
								blockImage5[mapID], true);
					}
				}
			}
		}
	}*/
	// ��ڲ԰�̱�Ұ���
	for (int y = 0; y < PLAYER_MAX; y++)
	{
		if (player[y].state == PL_ST_ALIVE)
		{
			player[y].animCnt++;
		}
		int tmpAnimID = (player[y].animCnt / ANIM_SPEED) % 2;

		DrawGraph(GAME_SCREEN_X + player[y].pos.x,
			GAME_SCREEN_Y + player[y].pos.y - MAP_CHIP_SIZE_Y / 3,
			charImage[player[y].charID].chipImage[player[y].dir][tmpAnimID], true);

		if(player[y].state != PL_ST_ALIVE)
		SetDrawBright(faceBright, faceBright, faceBright);
		DrawGraph((GAME_SCREEN_SIZE_X / 2) - 300 * (1 - (2 * y)) , 0,
			charImage[player[y].charID].faceImage, true);
		SetDrawBright(255, 255, 255);
	}
}

// �ړ������̐؂�ւ�
void PlayerCtl(int no)
{
	if (player[no].state == PL_ST_DETH)// false���
	{
		return;
	}
	// �}�X�ڂ҂�����Ɉړ�
	if ((player[no].pos.x % MAP_CHIP_SIZE_X) == 0 && (player[no].pos.y % MAP_CHIP_SIZE_Y) == 0)
	{
		if (isHitBlock(player[no].pos))
		{
			// �ő剻������ۯ��ɓ���������
			player[no].state  = PL_ST_DETH;
			return;
		}
		SetMapBlock(player[no].pos);
		for (DIR y = (DIR)0; y < DIR_MAX; y = (DIR)(y + 1))
		{
			// �ړ�
			if (CheckHitKey(KeyList[no][y]))
			{
				player[no].dir = y;
			}
		}           
	}
	// ������Z
	player[no].scrCnt += SetMapBlock(player[no].pos);

	// �w������̈ړ�
	switch (player[no].dir)
	{
	case DIR_UP:
		player[no].pos.y -= player[no].speed;
		break;
	case DIR_RIGHT:
		player[no].pos.x += player[no].speed;
		break;
	case DIR_DOWN:
		player[no].pos.y += player[no].speed;
		break;
	case DIR_LEFT:
		player[no].pos.x -= player[no].speed;
		break;
	default:
		player[no].dir = DIR_RIGHT;
		AST();
		break;
	};
}

// map�̏�����
void InitMapID(void)
{
	for (int y = 0; y < MAP_CHIP_SIZE_Y; y++)
	{
		for (int x = 0; x < MAP_CHIP_SIZE_X; x++)
		{
			mapData[y][x] = 0;
		}
	}
}

// �w����W��ϯ�߂�Ͻ�ڂɕϊ����āA��ۯ���z�u
int SetMapBlock(Pos pos)
{
	chipPos.x = pos.x / MAP_CHIP_SIZE_X;
	chipPos.y = pos.y / MAP_CHIP_SIZE_Y;
	// �͈͊O���ǂ�������
	if ((chipPos.x < 0 )||
		(chipPos.x >= MAP_CHIP_CNT_X) ||
		(chipPos.y < 0)||
		(chipPos.y >= MAP_CHIP_CNT_Y))
	{
		// �͈͊O�̏ꍇ�A�������܂���0��Ԃ�
		return 0;
	}
	if (mapData[chipPos.y][chipPos.x] == 0)
	{
		mapData[chipPos.y][chipPos.x] = 1;
	}
	return mapData[chipPos.y][chipPos.x];
}

// �w����W��ϯ�߂�Ͻ�ڂɕϊ�������ۯ��̏�Ԃ�Ԃ�
int GetMapBlock(Pos pos)
{
	Pos chipPos;

	chipPos.x = pos.x / MAP_CHIP_SIZE_X;
	chipPos.y = pos.y / MAP_CHIP_SIZE_Y;
	// 
	if ((chipPos.x < 0) ||
		(chipPos.x >= MAP_CHIP_CNT_X) ||
		(chipPos.y < 0) ||
		(chipPos.y >= MAP_CHIP_CNT_Y))
	{
		// �͈͊O�̏ꍇ�A������ۯ���Ԃ�
		return BLOCK_MAX_SIZE_CNT;
	}
	
	return mapData[chipPos.y][chipPos.x];
}

// ��������ۯ��̓����蔻��
bool isHitBlock(Pos pos)
{
	if (GetMapBlock(pos) >= BLOCK_MAX_SIZE_CNT)
	{
		return true;
	}
	return false;
}

// �ݒu�ς݂���ۯ��̏�Ԃ��X�V����
void UpdateMap(void)
{
	for (int y = 0; y < MAP_CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < MAP_CHIP_CNT_X; x++)
		{
			if ((mapData[y][x] > 0) &&
				(mapData[y][x] < BLOCK_MAX_SIZE_CNT))
			{
				mapData[y][x]++;
			}
		}
	}
}




